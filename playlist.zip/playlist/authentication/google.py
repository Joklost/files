"""Authenticate with Google"""
import flask
import google.oauth2.credentials
import google_auth_oauthlib.flow
import requests

SECRETS_FILE = r"C:\Users\Jonas\Desktop\playlist\authentication\client_secrets.json"
SCOPES = ["https://www.googleapis.com/auth/youtube.readonly"]


def __get_flow(state=None):
    return google_auth_oauthlib.flow.Flow.from_client_secrets_file(
        SECRETS_FILE,
        SCOPES,
        state=state
    )

def __credentials_to_dict(credentials):
    return {
        'token': credentials.token,
        'refresh_token': credentials.refresh_token,
        'token_uri': credentials.token_uri,
        'client_id': credentials.client_id,
        'client_secret': credentials.client_secret,
        'scopes': credentials.scopes
    }

def authorize():
    """First part of authenticate with the Google API"""
    flow = __get_flow()
    flow.redirect_uri = flask.url_for("auth_google_callback", _external=True)
    auth_url, state = flow.authorization_url(
        access_type="offline",
        include_granted_scopes="true"
    )

    return auth_url, state


def get_credentials(state, response_url):
    """Second part of authenticate with the Google API"""
    flow = __get_flow(state=state)
    flow.redirect_uri = flask.url_for("auth_google_callback", _external=True)
    flow.fetch_token(authorization_response=response_url)
    return __credentials_to_dict(flow.credentials)


def revoke(credentials):
    """Revoke refresh token"""
    creds = google.oauth2.credentials.Credentials(**credentials)
    response = requests.post("https://accounts.google.com/o/oauth2/revoke",
                             params={"token": creds.token},
                             headers={"content-type": "application/x-www-form-urlencoded"})

    if response.status_code == 200:
        return True

    return False
