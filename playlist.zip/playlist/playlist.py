"""
Python web server for synchronizing playlists
between Youtube and Spotify

Requires:
    pip install --user google-api-python-client google-auth google-auth-oauthlib
                       google-auth-httplib2 flask requests
"""
import os
import json
import flask
import authentication.google

app = flask.Flask(__name__)


@app.route("/")
def index():
    """Index page"""
    # if "google_credentials" not in flask.session:
        # return flask.redirect("auth/google")

    return flask.render_template("index.html")


@app.route("/auth/google")
def auth_google():
    """Authenticate with Google"""
    auth_url, state = authentication.google.authorize()
    flask.session["state"] = state

    return flask.redirect(auth_url)


@app.route("/auth/google/callback", methods=["GET"])
def auth_google_callback():
    """Authenticate with Google callback"""
    state = flask.session["state"]
    credentials = authentication.google.get_credentials(state, flask.request.url)
    flask.session["google_credentials"] = credentials

    return flask.redirect("/")


@app.route("/auth/google/revoke")
def auth_google_revoke():
    """Delete Google credentials"""
    if "google_credentials" not in flask.session:
        return flask.redirect("/")

    if authentication.google.revoke(flask.session["google_credentials"]):
        del flask.session["google_credentials"]
        return flask.redirect("/")
    else:
        raise Exception("Failed to revoke Google credentials!")


if __name__ == "__main__":
    os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'
    app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'  ## keep this as an environment variable
    app.run(debug=True)
