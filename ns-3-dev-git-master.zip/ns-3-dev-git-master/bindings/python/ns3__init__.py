
from _ns3 import *

import atexit
atexit.register(Simulator.Destroy)
del atexit

