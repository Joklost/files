/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/log.h>

#include <ns3/propagation-module.h>

#include "ble-helper.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleHelper");

///**
// * @brief Output an ascii line representing the Transmit event (with context)
// * @param stream the output stream
// * @param context the context
// * @param p the packet
// */
//static void
//AsciiBleLinkLayerTransmitSinkWithContext (
//  Ptr<OutputStreamWrapper> stream,
//  std::string context,
//  Ptr<const Packet> p)
//{
//  *stream->GetStream () << "t " << Simulator::Now ().GetSeconds () << " " << context << " " << *p << std::endl;
//}
//
///**
// * @brief Output an ascii line representing the Transmit event (without context)
// * @param stream the output stream
// * @param p the packet
// */
//static void
//AsciiBleLinkLayerTransmitSinkWithoutContext (
//  Ptr<OutputStreamWrapper> stream,
//  Ptr<const Packet> p)
//{
//  *stream->GetStream () << "t " << Simulator::Now ().GetSeconds () << " " << *p << std::endl;
//}

BleHelper::BleHelper (void)
{
  NS_LOG_FUNCTION (this);
  m_channel = CreateObject<SingleModelSpectrumChannel> ();
  Ptr<LogDistancePropagationLossModel> lossModel = CreateObject<LogDistancePropagationLossModel> ();
  m_channel->AddPropagationLossModel (lossModel);

  Ptr<ConstantSpeedPropagationDelayModel> delayModel = CreateObject<ConstantSpeedPropagationDelayModel> ();
  m_channel->SetPropagationDelayModel (delayModel);
}

BleHelper::~BleHelper (void)
{
  NS_LOG_FUNCTION (this);
  m_channel->Dispose ();
  m_channel = 0;
}

void
BleHelper::SetChannel (Ptr<SpectrumChannel> channel)
{
  NS_LOG_FUNCTION (this);
  m_channel = channel;
}

Ptr<SpectrumChannel>
BleHelper::GetChannel (void)
{
  NS_LOG_FUNCTION (this);
  return m_channel;
}

void
BleHelper::EnableLogComponents (void)
{
  LogComponentEnableAll (LOG_PREFIX_TIME);
  LogComponentEnableAll (LOG_PREFIX_FUNC);
  LogComponentEnable ("BlePhy", LOG_LEVEL_ALL);
  LogComponentEnable ("BleSpectrumSignalParameters", LOG_LEVEL_ALL);
  LogComponentEnable ("BleInterferenceHelper", LOG_LEVEL_ALL);
  LogComponentEnable ("BleLinkLayer", LOG_LEVEL_ALL);
  LogComponentEnable ("BleNetDevice", LOG_LEVEL_ALL);
  LogComponentEnable ("BleSpectrumValueHelper", LOG_LEVEL_ALL);
}

std::string
BleHelper::BlePhyStatePrinter (BlePhy::BlePhyState e)
{
  switch (e)
    {
    case BlePhy::OFF:
      return std::string ("OFF");
    case BlePhy::IDLE:
      return std::string ("IDLE");
    case BlePhy::LISTEN:
      return std::string ("LISTEN");
    case BlePhy::BUSY_RX:
      return std::string ("BUSY_RX");
    case BlePhy::TRANS:
      return std::string ("TRANS");
    case BlePhy::BUSY_TX:
      return std::string ("BUSY_TX");
    default:
      return std::string ("Invalid");
    }
}

std::string
BleHelper::BleLinkLayerRolePrinter (BleLinkLayer::BleLinkLayerRole e)
{
  switch (e)
    {
    case BleLinkLayer::STANDBY:
      return std::string ("STAND_BY");
    case BleLinkLayer::ADVERTISER:
      return std::string ("ADVERTISER");
    case BleLinkLayer::SCANNER_ACT:
      return std::string ("SCANNER_ACT");
    case BleLinkLayer::SCANNER_PASS:
      return std::string ("SCANNER_PASS");
    case BleLinkLayer::CONN_MASTER:
      return std::string ("CONN_MASTER");
    case BleLinkLayer::CONN_SLAVE:
      return std::string ("CONN_SLAVE");
    default:
      return std::string ("INVALID");
    }
}

void
BleHelper::AddMobility (Ptr<BlePhy> phy, Ptr<MobilityModel> m)
{
  phy->SetMobility (m);
}

NetDeviceContainer
BleHelper::Install (NodeContainer c, BleLinkLayer::BleLinkLayerDeviceTypes type)
{
  NetDeviceContainer devices;

  uint32_t count = 0;
  for (NodeContainer::Iterator i = c.Begin ();
                               i != c.End ();
                               i++)
    {
      Ptr<BleNetDevice> netDevice = CreateObject<BleNetDevice> ();
      Ptr<BlePhy> phy = CreateObject<BlePhy> ();
      phy->SetTxPower (0); // Default TxPower
      phy->SetRxSensitivity (-97); // Default RxSensitivity

      Ptr<BleLinkLayer> ll = CreateObject<BleLinkLayer> (type);

      netDevice->SetPhy (phy);
      netDevice->SetNode (*i);
      netDevice->SetLinkLayer (ll);
      netDevice->SetChannel (m_channel);

      netDevice->CompleteConfig ();

//      Ptr<BleApplication> app = CreateObject<BleApplication> ();
//      Ptr<BleSensorApplication> app = CreateObject<BleSensorApplication> ();
      Ptr<BlePoissonApplication> app = CreateObject<BlePoissonApplication> ();
      app->ChangeState ((type == BleLinkLayer::CENTRAL) ? BlePoissonApplication::SCANNING:BlePoissonApplication::IDLE);
      app->SetLinkLayer (ll);
//      char data[31];
//      for (uint8_t j = 0; j < 5; j++)
//        data[j] = "Node "[j];
//      sprintf (&data[5], "%02d", count);
//      data[7] = ' ';
//      for (uint8_t j = 8; j < 31; j++)
//        data[j] = 65 + ((j-8) % 26);
//      app->SetAdvString (data);
//
//      char conn[100];
//      for (uint8_t j = 0; j < 5; j++)
//        conn[j] = "Node "[j];
//      sprintf (&conn[5], "%02d", count);
//      conn[7] = ' ';
//      for (uint8_t j = 8; j < 100; j++)
//        conn[j] = 97 + ((j-8) % 26);
//      app->SetConnString (conn);

      (*i)->AddApplication (app);

      (*i)->AddDevice (netDevice);
      devices.Add (netDevice);
      count++;
    }
  return devices;
}

void
BleHelper::AllocateAddress (NetDeviceContainer c, Mac48Address addr)
{
  NS_LOG_FUNCTION (this);
  for (NetDeviceContainer::Iterator i = c.Begin ();
                                    i != c.End ();
                                    i++)
    {
      Ptr<BleNetDevice> nd = (*i)->GetObject<BleNetDevice> ();
      nd->SetMacAddress (addr.Allocate ());
    }
}

/**
 * @brief Output an ascii line representing the Transmit event (with context)
 * @param stream the output stream
 * @param context the context
 * @param p the packet
 */
static void
AsciiBleLinkLayerTransmitSinkWithContext (
  Ptr<OutputStreamWrapper> stream,
  std::string context,
  Ptr<const Packet> p)
{
  *stream->GetStream () << "t " << Simulator::Now ().GetSeconds () << " " << context << " " << *p << std::endl;
}

/**
 * @brief Output an ascii line representing the Transmit event (without context)
 * @param stream the output stream
 * @param p the packet
 */
static void
AsciiBleLinkLayerTransmitSinkWithoutContext (
  Ptr<OutputStreamWrapper> stream,
  Ptr<const Packet> p)
{
  *stream->GetStream () << "t " << Simulator::Now ().GetSeconds () << " " << *p << std::endl;
}


void
BleHelper::EnableAsciiInternal (
    Ptr<OutputStreamWrapper> stream,
    std::string prefix,
    Ptr<NetDevice> nd,
    bool explicitFilename)
{
  NS_LOG_FUNCTION (this);
  uint32_t nodeid = nd->GetNode ()->GetId ();
  uint32_t deviceid = nd->GetIfIndex ();
  std::ostringstream oss;

  Ptr<BleNetDevice> device = nd->GetObject<BleNetDevice> ();
  if (device == 0)
    {
      NS_LOG_INFO ("BleHelper::EnableAsciiInternal(): Device " << device << " not of type ns3::BleNetDevice");
      return;
    }

  Packet::EnablePrinting ();

  if (stream == 0)
    {
      //
      // Set up an output stream object to deal with private ofstream copy
      // constructor and lifetime issues.  Let the helper decide the actual
      // name of the file given the prefix.
      //
      AsciiTraceHelper asciiTraceHelper;

      std::string filename;
      if (explicitFilename)
        {
          filename = prefix;
        }
      else
        {
          filename = asciiTraceHelper.GetFilenameFromDevice (prefix, device);
        }

      Ptr<OutputStreamWrapper> theStream = asciiTraceHelper.CreateFileStream (filename);

      // Ascii traces typically have "+", '-", "d", "r", and sometimes "t"
      // The Mac and Phy objects have the trace sources for these
      //

      asciiTraceHelper.HookDefaultReceiveSinkWithoutContext<BleLinkLayer> (device->GetLinkLayer (), "LinkLayerRxFromPhy", theStream);

      device->GetLinkLayer ()->TraceConnectWithoutContext ("LinkLayerTxFromPhy", MakeBoundCallback (&AsciiBleLinkLayerTransmitSinkWithoutContext, theStream));

      asciiTraceHelper.HookDefaultDropSinkWithoutContext<BleLinkLayer> (device->GetLinkLayer (), "LinkLayerRxFromPhyDrop", theStream);

      return;
    }

  //
  // If we are provided an OutputStreamWrapper, we are expected to use it, and
  // to provide a context.  We are free to come up with our own context if we
  // want, and use the AsciiTraceHelper Hook*WithContext functions, but for
  // compatibility and simplicity, we just use Config::Connect and let it deal
  // with the context.
  //
  // Note that we are going to use the default trace sinks provided by the
  // ascii trace helper.  There is actually no AsciiTraceHelper in sight here,
  // but the default trace sinks are actually publicly available static
  // functions that are always there waiting for just such a case.
  //
  oss.str ("");
  oss << "/NodeList/" << nodeid << "/DeviceList/" << deviceid << "/$ns3::BleNetDevice/LinkLayer/LinkLayerRxFromPhy";
  device->GetLinkLayer ()->TraceConnect ("LinkLayerRxFromPhy", oss.str (), MakeBoundCallback (&AsciiTraceHelper::DefaultReceiveSinkWithContext, stream));

  oss.str ("");
  oss << "/NodeList/" << nodeid << "/DeviceList/" << deviceid << "/$ns3::BleNetDevice/LinkLayer/LinkLayerTxToPhy";
  device->GetLinkLayer ()->TraceConnect ("LinkLayerTxToPhy", oss.str (), MakeBoundCallback (&AsciiBleLinkLayerTransmitSinkWithContext, stream));

  oss.str ("");
  oss << "/NodeList/" << nodeid << "/DeviceList/" << deviceid << "/$ns3::BleNetDevice/LinkLayer/LinkLayerRxFromPhyDrop";
  device->GetLinkLayer ()->TraceConnect ("LinkLayerRxFromPhyDrop", oss.str (), MakeBoundCallback (&AsciiTraceHelper::DefaultDropSinkWithContext, stream));

}

/**
 * @brief Write a packet in a PCAP file
 * @param file the output file
 * @param packet the packet
 */
static void
PcapSniffBle (Ptr<PcapFileWrapper> file, Ptr<const Packet> packet)
{
  file->Write (Simulator::Now (), packet);
}

void
BleHelper::EnablePcapInternal (std::string prefix, Ptr<NetDevice> nd, bool promiscuous, bool explicitFilename)
{
  NS_LOG_FUNCTION (this << prefix << nd << promiscuous);
  //
  // All of the Pcap enable functions vector through here including the ones
  // that are wandering through all of devices on perhaps all of the nodes in
  // the system.  We can only deal with devices of type PointToPointNetDevice.
  //
  Ptr<BleNetDevice> device = nd->GetObject<BleNetDevice> ();
  if (device == 0)
    {
      NS_LOG_INFO ("BleHelper::EnablePcapInternal(): Device " << device << " not of type ns3::BleNetDevice");
      return;
    }

  PcapHelper pcapHelper;

  std::string filename;
  if (explicitFilename)
    {
      filename = prefix;
    }
  else
    {
      filename = pcapHelper.GetFilenameFromDevice (prefix, device);
    }

  Ptr<PcapFileWrapper> file = pcapHelper.CreateFile (filename, std::ios::out,
                                                     PcapHelper::DLT_BLUETOOTH_LE_LL);

  device->TraceConnectWithoutContext ("LinkLayerRxFromPhy", MakeBoundCallback (&PcapSniffBle, file));
}

} // namespace ns3
