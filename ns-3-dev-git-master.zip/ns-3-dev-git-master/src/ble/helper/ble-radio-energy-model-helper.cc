/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */
#include "ble-radio-energy-model-helper.h"
#include "ns3/basic-energy-source-helper.h"
#include "ns3/ble-phy.h"
#include "ns3/ble-netdevice.h"
#include "ns3/ble-sensor-application.h"
#include "ns3/config.h"
#include "ns3/names.h"

namespace ns3 {

BleRadioEnergyModelHelper::BleRadioEnergyModelHelper ()
{
  m_radioEnergy.SetTypeId ("ns3::BleRadioEnergyModel");
  m_depletionCallback.Nullify ();
  m_rechargedCallback.Nullify ();
}

BleRadioEnergyModelHelper::~BleRadioEnergyModelHelper ()
{
}

void
BleRadioEnergyModelHelper::Set (std::string name, const AttributeValue &v)
{
  m_radioEnergy.Set (name, v);
}

void
BleRadioEnergyModelHelper::SetDepletionCallback (
  BleRadioEnergyModel::BleRadioEnergyDepletionCallback callback)
{
  m_depletionCallback = callback;
}

void
BleRadioEnergyModelHelper::SetRechargedCallback (
  BleRadioEnergyModel::BleRadioEnergyRechargedCallback callback)
{
  m_rechargedCallback = callback;
}

Ptr<DeviceEnergyModel>
BleRadioEnergyModelHelper::DoInstall (Ptr<NetDevice> device,
                                      Ptr<EnergySource> source) const
{
  NS_ASSERT (device != NULL);
  NS_ASSERT (source != NULL);
  // check if device is BleNetDevice
  std::string deviceName = device->GetInstanceTypeId ().GetName ();
  if (deviceName.compare ("ns3::BleNetDevice") != 0)
    {
      NS_FATAL_ERROR ("NetDevice type is not BleNetDevice!");
    }
  Ptr<BleRadioEnergyModel> model = m_radioEnergy.Create ()->GetObject<BleRadioEnergyModel> ();
  NS_ASSERT (model != NULL);
  // set energy source pointer
  model->SetEnergySource (source);
  // set energy depletion callback
  // if none is specified, make a callback to BlePhy::SetSleepMode
  Ptr<BleNetDevice> bleDevice = DynamicCast<BleNetDevice> (device);
  Ptr<BlePhy> blePhy = bleDevice->GetPhy ();
  if (m_depletionCallback.IsNull ())
    {
      Ptr<Application> app = device->GetNode ()->GetApplication (0);
      Ptr<BleSensorApplication> appSense = app->GetObject<BleSensorApplication> ();
      NS_ASSERT (appSense != 0);
      model->SetEnergyDepletionCallback (MakeCallback (&BleSensorApplication::PauseApplication, appSense));
    }
  else
    {
      model->SetEnergyDepletionCallback (m_depletionCallback);
    }
  // set energy recharged callback
  if (m_rechargedCallback.IsNull ())
    {
      Ptr<Application> app = device->GetNode ()->GetApplication (0);
      Ptr<BleSensorApplication> appSense = app->GetObject<BleSensorApplication> ();
      NS_ASSERT (appSense != 0);
      model->SetEnergyRechargedCallback (MakeCallback (&BleSensorApplication::ResumeApplication, appSense));
    }
  else
    {
      model->SetEnergyRechargedCallback (m_rechargedCallback);
    }
  // add model to device model list in energy source
  source->AppendDeviceEnergyModel (model);

  model->SetPhy (blePhy);
  void (BleRadioEnergyModel::*fp) (BlePhy::BlePhyState oldState, BlePhy::BlePhyState newState) = &BleRadioEnergyModel::ChangeState;
  blePhy->TraceConnectWithoutContext ("PhyStateValue",
                                      MakeCallback (fp, model));

  return model;
}

} // namespace ns3
