/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_HELPER_H
#define BLE_HELPER_H

#include <ns3/trace-helper.h>

#include <ns3/spectrum-module.h>
#include <ns3/ble-phy.h>
#include <ns3/ble-netdevice.h>
//#include <ns3/ble-sensor-application.h>
#include <ns3/ble-poisson-application.h>

namespace ns3 {

//TODO: Change BLE Helper for generalised BleApplication

/**
 * \ingroup ble
 *
 * \brief helps to manage and create BLE NetDevice objects and work with a group of device at once.
 * This class can help to create BLE NetDevice objects and
 * configure their attributes during the creation. It also
 * contains additional helper functions that can be used by user.
 */
class BleHelper : public PcapHelperForDevice,
                  public AsciiTraceHelperForDevice
{
public:
  /**
   * \brief Create a Ble Helper in an empty state. By default, a
   * SingleModelSpectrumChannel is created with a log distance propagation loss model and a ConstantPositionPropagationDelayModel.
   * To change the channel models, loss models, or delay model,the Get/Set Channel methods may be used.
   */
  BleHelper (void);

  virtual ~BleHelper (void);
  /**
   * \brief Set the channel associated to this helper
   * \param channel Pointer to SpectrumChannel object
   */
  void SetChannel (Ptr<SpectrumChannel> channel);
  /**
   * \brief Get the channel associated to this helper
   * \return Pointer to the SpectrumChannel object
   */
  Ptr<SpectrumChannel> GetChannel (void);

  /**
   * \brief Add MobilityModel to a physical device
   * \param phy the physical device
   * \param m the mobility model
   */
  void AddMobility (Ptr<BlePhy> phy, Ptr<MobilityModel> m);

  /**
   * \brief Install a BleNetdevice and the assocuiated structures (e.g. channel, LinkLayer, PhyDevices in the nodes.
   * \param c a set of nodes
   * \param type Type of device
   * \returns A container of the added net devices
   */
  NetDeviceContainer Install (NodeContainer c, BleLinkLayer::BleLinkLayerDeviceTypes type);
  /**
   * \brief Allocate address to all Nodes
   * \param c NetDevice Container
   * \param addr Object of Mac48Address class
   * User same addr object to allocate addresses on same system.
   */
  void AllocateAddress (NetDeviceContainer c, Mac48Address addr);
  /**
   * \brief Helper to enable all BLE log components with one statement
   */
  void EnableLogComponents (void);
  /**
   * \brief Transform the BlePhy States into a printable strings.
   * \param e the BlePhyState
   * \return the string
   */
  static std::string BlePhyStatePrinter (BlePhy::BlePhyState e);
  /*
   * \brief Transform the LinkLayer Role into a printable string.
   * \param e the BleLinkLayerState
   * \return a string
   */
  static std::string BleLinkLayerRolePrinter (BleLinkLayer::BleLinkLayerRole e);

private:
  // Disable implicit constructors
  /**
   * \brief Copy Constructor - defined and not implemented.
   */
  BleHelper (BleHelper const &);
  /**
   * \brief Copy Constructor - defined and not implemented
   * \returns
   */
  BleHelper& operator= (BleHelper const &);
  /**
   * \brief Enable pcap output on the indicated netdevice
   *
   * NetDevice-specific implementation mechanism for hooking the trace and writing to the trace file.
   *
   * \param prefix Filename prefix to use for pcap files.
   * \param nd NetDevice for which you want to use for pcap files.
   * \param promiscous If tru capture all possible packets available at the device.
   */
  virtual void EnablePcapInternal (std::string prefix, Ptr<NetDevice> nd, bool promiscous, bool explicitFilename);
  /**
   * \brief Enable ascii trace output on the indicated net device.
   * Net Device specific implementation mechanism for hooking the trace and
   * writing to the trace file.
   *
   * \param stream The output stream object to use when logging ascii traces.
   * \param prefix Filename prefix to use for ascii trace files.
   * \param nd Net device for which you want to enable tracing
   */
  virtual void EnableAsciiInternal (Ptr<OutputStreamWrapper> stream,
                                    std::string prefix,
                                    Ptr<NetDevice> nd,
                                    bool explicitFilename);
  Ptr<SpectrumChannel> m_channel; //!< channel to be used for the devices
};

} // namespace ns3

#endif /* BLE_HELPER_H */

