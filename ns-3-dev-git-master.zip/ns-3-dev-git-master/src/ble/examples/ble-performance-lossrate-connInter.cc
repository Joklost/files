/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/nstime.h>
#include <ns3/core-module.h>
#include <ns3/network-module.h>

#include <ns3/stats-module.h>
#include <ns3/propagation-module.h>
#include <ns3/mobility-module.h>
#include <ns3/spectrum-module.h>
#include <ns3/energy-module.h>
#include <ns3/ble-module.h>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("BleLinkLayerSourceExample");

int
main (int argc, char *argv[])
{
  Packet::EnablePrinting ();
  double distanceToRx = 0.5;
  int CENTRAL_DEVICE_COUNT = 1;
  int PERIPHERAL_DEVICE_COUNT = 4;
  LogComponentEnable ("BleSensorApplication", LOG_LEVEL_DEBUG);
//  LogComponentEnable ("BleApplication", LOG_LEVEL_DEBUG);
//  LogComponentEnable ("BleLinkLayer", LOG_LEVEL_DEBUG);
//  LogComponentEnable ("BlePhy", LOG_LEVEL_INFO);
//  LogComponentEnable ("SingleModelSpectrumChannel", LOG_LEVEL_INFO);
  // Simulation Logic begins
  std::string fileNameWithNoExtension = "plot-2d";
  std::string graphicsFileName        = fileNameWithNoExtension + ".png";
  std::string plotFileName            = fileNameWithNoExtension + ".plt";
  std::string plotTitle               = "LossRate vs. Connection Interval";
  std::string dataTitle               = "LossRate vs. Connection Interval";
  
  // Instantiate the plot and set its title.
  Gnuplot plot (graphicsFileName);
  plot.SetTitle (plotTitle);
  
  // Make the graphics file, which the plot file will create when it
  // is used with Gnuplot, be a PNG file.
  plot.SetTerminal ("png");
  
  // Set the labels for each axis.
  plot.SetLegend ("X Values", "Y Values");
  
  // Set the range for the x axis.
  plot.AppendExtra ("set xrange [0:320]");
  
  // Instantiate the dataset, set its title, and make the points be
  // plotted along with connecting lines.
  Gnuplot2dDataset dataset;
  dataset.SetTitle (dataTitle);
  dataset.SetStyle (Gnuplot2dDataset::LINES_POINTS);

  int M = 100;
  int slaveLatency = 7;
  for (int connInter = 5; connInter < 255; connInter += 20)
    {
      double sumOfLossRatio = 0;
      for (int ii = 0; ii < M; ii++)
        {
          // System Setup - Start 
          NodeContainer bleCentral;
          bleCentral.Create (CENTRAL_DEVICE_COUNT);
          NodeContainer blePeripheral;
          blePeripheral.Create (PERIPHERAL_DEVICE_COUNT);

          MobilityHelper mobility;
          Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator> ();
          positionAlloc->Add (Vector (0.0, 0.0, 0.0));
          mobility.SetPositionAllocator (positionAlloc);
          mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
          mobility.Install (bleCentral);

          MobilityHelper mobilityPeri;
          Ptr<ListPositionAllocator> positionAllocPeri = CreateObject<ListPositionAllocator> ();
          positionAllocPeri->Add (Vector (distanceToRx, 0.0, 0.0));
          mobilityPeri.SetPositionAllocator (positionAllocPeri);
          mobilityPeri.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
          mobilityPeri.Install (blePeripheral);

          BleHelper bleHelper;
          Ptr<SingleModelSpectrumChannel> ch = CreateObject<SingleModelSpectrumChannel> ();

          Ptr<ConstantSpeedPropagationDelayModel> pdm = CreateObject<ConstantSpeedPropagationDelayModel> ();
          (*ch).SetPropagationDelayModel (pdm);

          Ptr<LogDistancePropagationLossModel> plm = CreateObject<LogDistancePropagationLossModel> ();
          plm->SetPathLossExponent (3);
          plm->SetReference (0.1, 20.041);
          (*ch).AddPropagationLossModel (plm);

          bleHelper.SetChannel (ch);

          NetDeviceContainer centDevice = bleHelper.Install (bleCentral, BleLinkLayer::CENTRAL);
          NetDeviceContainer periDevice = bleHelper.Install (blePeripheral, BleLinkLayer::PERIPHERAL);

          Mac48Address addr;
          bleHelper.AllocateAddress (centDevice, addr);
          bleHelper.AllocateAddress (periDevice, addr);

          BasicEnergySourceHelper basicSourceHelper;
          basicSourceHelper.Set("BasicEnergySourceInitialEnergyJ", DoubleValue (1000000));
          //basicSourceHelper.Set ("PeriodicEnergyUpdateInterval",
          //                        TimeValue (Time ("1s")));

          EnergySourceContainer sourcesCent = basicSourceHelper.Install (bleCentral);
          basicSourceHelper.Set("BasicEnergySourceInitialEnergyJ", DoubleValue (1.0e-9));
          basicSourceHelper.Set("BasicEnergyLowBatteryThreshold", DoubleValue (3.0e4));
          basicSourceHelper.Set("BasicEnergyHighBatteryThreshold", DoubleValue (8.0e4));
          EnergySourceContainer sourcesPeri = basicSourceHelper.Install (blePeripheral);

          BasicEnergyHarvesterHelper basicHarvesterHelper;
          basicHarvesterHelper.Set ("PeriodicHarvestedPowerUpdateInterval",
                                    TimeValue (Time ("1ms")));
          basicHarvesterHelper.Set ("HarvestablePower", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=0.000007]"));
          EnergyHarvesterContainer harvesterPeri = basicHarvesterHelper.Install (sourcesPeri);

          // device energy model helper
          BleRadioEnergyModelHelper radioEnergyHelper;
          // set energy depletion callback

          DeviceEnergyModelContainer deviceModelsCent = radioEnergyHelper.Install (centDevice, sourcesCent);
          DeviceEnergyModelContainer deviceModelsPeri = radioEnergyHelper.Install (periDevice, sourcesPeri);

//          bleHelper.EnableAsciiAll ("Ble");
          
          for (NetDeviceContainer::Iterator i = periDevice.Begin ();
                                            i != periDevice.End ();
                                            i++)
            {
              (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvInterval (Time("100ms"));
              (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRole (BleLinkLayer::ADVERTISER);
              (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvMode (BleLinkLayer::GENERAL_ADV);
              (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRxDeviceAddress ((*centDevice.Begin ())->GetObject<BleNetDevice> ()->GetMacAddress ());
            }

          for (NetDeviceContainer::Iterator i = centDevice.Begin ();
                                            i != centDevice.End ();
                                            i++)
            {
                (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvInterval (Time("100ms"));
                (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvListenWindow (Time("70ms"));
                (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRole (BleLinkLayer::SCANNER_ACT);
                (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetTxWindowOffset (8);
            }
          // System Setup Ends
          for (NetDeviceContainer::Iterator i = centDevice.Begin ();
                                            i != centDevice.End ();
                                            i++)
            {
                (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetTxWindowSize ((uint8_t)(connInter*0.1));
                (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetConnectionInterval (connInter);
                (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetSlaveLatency (slaveLatency);
                (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetSupervisionTimeout ((connInter*1.25*(slaveLatency+6)/10));
            }
        
        
          Simulator::Stop(Time("1h"));
          Simulator::Run();
 
          int count = 0;
          for (DeviceEnergyModelContainer::Iterator i = deviceModelsCent.Begin ();
                                                    i != deviceModelsCent.End ();
                                                    i++)
            {
              double r = (*i)->GetTotalEnergyConsumption ();
              std::cout << "Consumed Energy of Central Node " << count++ << " is " << r << "J" << std::endl;
            }
          count = 0;
          for (DeviceEnergyModelContainer::Iterator i = deviceModelsPeri.Begin ();
                                               i != deviceModelsPeri.End ();
                                               i++)
            {
              double r = (*i)->GetTotalEnergyConsumption ();
              std::cout << "Consumed Energy of Peripheral Node " << count << " is " << r << "J" << std::endl;
              count++;
            }
          count = 0;
          for (EnergyHarvesterContainer::Iterator i = harvesterPeri.Begin ();
                                               i != harvesterPeri.End ();
                                               i++)
            {
              double r = (*i)->GetObject<BasicEnergyHarvester> ()->GetTotalHarvestedEnergy ();
              std::cout << "Harvested Energy of Peripheral Node " << count << " is " << r << "J" << std::endl;
              count++;
            }
          int totalSense = 0;
          for (NodeContainer::Iterator i = blePeripheral.Begin ();
                                       i != blePeripheral.End ();
                                       i++)
            {
              Ptr<Application> r = (*i)->GetApplication (0);
              Ptr<BleSensorApplication> app = r->GetObject<BleSensorApplication> ();
              totalSense += app->GetSenseRxCount ();
            }
          std::cout << "Total Sensed Count = " << totalSense << std::endl;

          int totalRx = (*bleCentral.Begin ())->GetApplication (0)->GetObject<BleSensorApplication> ()->GetSenseRxCount ();
          std::cout << "Total Rx Count = " << totalRx << std::endl;
        
          sumOfLossRatio += 1 - (double)totalRx/totalSense;
          std::cout << "Loss Ratio = " << 1 - (double)totalRx/totalSense << std::endl;

          Simulator::Destroy ();
        }
      double avgLossRatio = sumOfLossRatio/M;
      dataset.Add (connInter*1.25, avgLossRatio);
    }

    // Add the dataset to the plot.
    plot.AddDataset (dataset);
    
    // Open the plot file.
    std::ofstream plotFile (plotFileName.c_str());
    
    // Write the plot file.
    plot.GenerateOutput (plotFile);
    
    // Close the plot file.
    plotFile.close ();
}
