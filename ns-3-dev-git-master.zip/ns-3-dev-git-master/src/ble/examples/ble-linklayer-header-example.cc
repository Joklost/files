/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/core-module.h>
#include <ns3/network-module.h>
#include <ns3/ble-linklayer-header.h>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("BleLinkLayerHeaderExample");

int
main (void)
{
  Ptr<Packet> pkt = Create<Packet> (10);
  BleLinkLayerHeader hdr;
  hdr.SetType (BleLinkLayerHeader::ADV);
  hdr.SetAdvPktType (BleLinkLayerHeader::ADV_DIRECT_IND);
  hdr.SetTxAddrType (BleLinkLayerHeader::TX_ADDR_PUBLIC);
  hdr.SetRxAddrType (BleLinkLayerHeader::RX_ADDR_PUBLIC);
  hdr.SetLength (0);
  Mac48Address addr;
  hdr.SetMacAddress (addr.Allocate ());
  hdr.SetRxMacAddress (addr.Allocate ());
  hdr.Print (std::cout);
  std::cout << std::endl;

  pkt->AddHeader (hdr);


  BleLinkLayerHeader hdr2;
  hdr2.SetType (BleLinkLayerHeader::ADV);

  uint32_t des = pkt->PeekHeader (hdr2);

  std::cout << "Size of Header = " << des << " Bytes" << std::endl;
  hdr2.Print (std::cout);
  std::cout << std::endl;

  return 0;
}
