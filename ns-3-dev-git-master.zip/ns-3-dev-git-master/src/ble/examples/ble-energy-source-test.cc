/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/nstime.h>
#include <ns3/core-module.h>
#include <ns3/network-module.h>

#include <ns3/propagation-module.h>
#include <ns3/mobility-module.h>
#include <ns3/spectrum-module.h>
#include <ns3/energy-module.h>
#include <ns3/ble-module.h>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("BleLinkLayerSourceExample");

void DepletionHandler (void);
void RechargeHandler (void);
int
main (int argc, char *argv[])
{
  Packet::EnablePrinting ();
  double distanceToRx = 0.5;
  int CENTRAL_DEVICE_COUNT = 1;
  int PERIPHERAL_DEVICE_COUNT = 1;
  LogComponentEnable ("BleSensorApplication", LOG_LEVEL_DEBUG);
//  LogComponentEnable ("BleApplication", LOG_LEVEL_DEBUG);
//  LogComponentEnable ("BleLinkLayer", LOG_LEVEL_DEBUG);
//  LogComponentEnable ("BlePhy", LOG_LEVEL_INFO);
//  LogComponentEnable ("SingleModelSpectrumChannel", LOG_LEVEL_INFO);

  NodeContainer bleCentral;
  bleCentral.Create (CENTRAL_DEVICE_COUNT);
  NodeContainer blePeripheral;
  blePeripheral.Create (PERIPHERAL_DEVICE_COUNT);

  MobilityHelper mobility;
  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator> ();
  positionAlloc->Add (Vector (0.0, 0.0, 0.0));
  mobility.SetPositionAllocator (positionAlloc);
  mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
  mobility.Install (bleCentral);

  MobilityHelper mobilityPeri;
  Ptr<ListPositionAllocator> positionAllocPeri = CreateObject<ListPositionAllocator> ();
  positionAllocPeri->Add (Vector (distanceToRx, 0.0, 0.0));
  mobilityPeri.SetPositionAllocator (positionAllocPeri);
  mobilityPeri.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
  mobilityPeri.Install (blePeripheral);

  BleHelper bleHelper;
  Ptr<SingleModelSpectrumChannel> ch = CreateObject<SingleModelSpectrumChannel> ();

  Ptr<ConstantSpeedPropagationDelayModel> pdm = CreateObject<ConstantSpeedPropagationDelayModel> ();
  (*ch).SetPropagationDelayModel (pdm);

  Ptr<LogDistancePropagationLossModel> plm = CreateObject<LogDistancePropagationLossModel> ();
  plm->SetPathLossExponent (3);
  plm->SetReference (0.1, 20.041);
  (*ch).AddPropagationLossModel (plm);


  bleHelper.SetChannel (ch);

  NetDeviceContainer centDevice = bleHelper.Install (bleCentral, BleLinkLayer::CENTRAL);
  NetDeviceContainer periDevice = bleHelper.Install (blePeripheral, BleLinkLayer::PERIPHERAL);

  Mac48Address addr;
  bleHelper.AllocateAddress (centDevice, addr);
  bleHelper.AllocateAddress (periDevice, addr);

  for (NetDeviceContainer::Iterator i = periDevice.Begin ();
                                    i != periDevice.End ();
                                    i++)
    {
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvInterval (Time("32s"));
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRole (BleLinkLayer::ADVERTISER);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvMode (BleLinkLayer::GENERAL_ADV);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRxDeviceAddress ((*centDevice.Begin ())->GetObject<BleNetDevice> ()->GetMacAddress ());
    }

  for (NetDeviceContainer::Iterator i = centDevice.Begin ();
                                    i != centDevice.End ();
                                    i++)
    {
        (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvInterval (Time("32s"));
        (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvListenWindow (Time("30s"));
        (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRole (BleLinkLayer::SCANNER_ACT);
        (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetTxWindowSize (20);
        (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetTxWindowOffset (10);
        (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetConnectionInterval (200);
        (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetSlaveLatency (7);
        (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetSupervisionTimeout (3200);
    }

  BasicEnergySourceHelper basicSourceHelper;
  basicSourceHelper.Set("BasicEnergySourceInitialEnergyJ", DoubleValue (1000000));
  basicSourceHelper.Set ("PeriodicEnergyUpdateInterval",
                          TimeValue (Time::FromInteger (10, static_cast<Time::Unit> (0))));

  EnergySourceContainer sourcesCent = basicSourceHelper.Install (bleCentral);
  basicSourceHelper.Set("BasicEnergySourceInitialEnergyJ", DoubleValue (1490));
  EnergySourceContainer sourcesPeri = basicSourceHelper.Install (blePeripheral);

  // device energy model helper
  BleRadioEnergyModelHelper radioEnergyHelper;
  // set energy depletion callback
  BleRadioEnergyModel::BleRadioEnergyDepletionCallback callback =
    MakeCallback (&DepletionHandler);
  radioEnergyHelper.SetDepletionCallback (callback);

  BleRadioEnergyModel::BleRadioEnergyRechargedCallback callbackRec =
    MakeCallback (&RechargeHandler);
  radioEnergyHelper.SetRechargedCallback (callbackRec);

  DeviceEnergyModelContainer deviceModelsCent = radioEnergyHelper.Install (centDevice, sourcesCent);
  DeviceEnergyModelContainer deviceModelsPeri = radioEnergyHelper.Install (periDevice, sourcesPeri);

  bleHelper.EnableAsciiAll ("Ble");

  Simulator::Stop(Time("1y"));
  Simulator::Run();

  int count = 0;
  for (DeviceEnergyModelContainer::Iterator i = deviceModelsCent.Begin ();
                                            i != deviceModelsCent.End ();
                                            i++)
    {
      double r = (*i)->GetTotalEnergyConsumption ();
      std::cout << "Consumed Energy of Central Node " << count++ << " is " << r << "J" << std::endl;
    }
  count = 0;
  for (DeviceEnergyModelContainer::Iterator i = deviceModelsPeri.Begin ();
                                       i != deviceModelsPeri.End ();
                                       i++)
    {
      double r = (*i)->GetTotalEnergyConsumption ();
      std::cout << "Consumed Energy of Peripheral Node " << count << " is " << r << "J" << std::endl;
      count++;
    }
}

void
RechargeHandler (void)
{
  std::cout << "Recharge" << std::endl;
}

void
DepletionHandler (void)
{
  std::cout << "Depletion " << Simulator::Now () << std::endl;
}
