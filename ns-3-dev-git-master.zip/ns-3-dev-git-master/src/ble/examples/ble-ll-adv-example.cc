/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/nstime.h>
#include <ns3/core-module.h>
#include <ns3/network-module.h>

#include <ns3/spectrum-module.h>
#include <ns3/ble-module.h>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("BleLinkLayerAdvExample");

int
main (int argc, char *argv[])
{
  Packet::EnablePrinting ();
  LogComponentEnable ("BleApplication", LOG_LEVEL_DEBUG);
  LogComponentEnable ("BleLinkLayer", LOG_LEVEL_DEBUG);
//  LogComponentEnable ("BlePhy", LOG_LEVEL_DEBUG);

  NodeContainer bleNodes;
  bleNodes.Create (2);

  Ptr<BlePhy> phy0 = CreateObject<BlePhy> ();
  Ptr<BlePhy> phy1 = CreateObject<BlePhy> ();

  phy0->SetTxPower (10);
  phy1->SetRxSensitivity (-80);

  Ptr<SingleModelSpectrumChannel> ch = CreateObject<SingleModelSpectrumChannel> ();

  phy0->SetChannel (ch);
  phy1->SetChannel (ch);

  Ptr<BleNetDevice> bleDevice0 = Create<BleNetDevice> ();
  Ptr<BleNetDevice> bleDevice1 = Create<BleNetDevice> ();

  Ptr<BleLinkLayer> perLL = CreateObject<BleLinkLayer> (BleLinkLayer::PERIPHERAL);
  Ptr<BleLinkLayer> centLL = CreateObject<BleLinkLayer> (BleLinkLayer::CENTRAL);

  bleDevice0->SetPhy (phy0);
  bleDevice1->SetPhy (phy1);
  bleDevice0->SetNode (bleNodes.Get (0));
  bleDevice1->SetNode (bleNodes.Get (1));

  bleDevice0->SetLinkLayer(perLL);
  bleDevice1->SetLinkLayer (centLL);
  perLL->SetPhy (phy0);
  centLL->SetPhy (phy1);


  bleDevice0->CompleteConfig ();
  bleDevice1->CompleteConfig ();
  Mac48Address addr;
  bleDevice0->SetMacAddress (addr.Allocate ());
  bleDevice1->SetMacAddress (addr.Allocate ());

  Ptr<BleApplication> app0 = CreateObject<BleApplication> ();
  Ptr<BleApplication> app1 = CreateObject<BleApplication> ();
  app0->ChangeState (BleApplication::ADVERTISE);
  app1->ChangeState (BleApplication::SCANNING);
  app0->SetLinkLayer (perLL);
  app1->SetLinkLayer (centLL);

  char data[31];
  for (int i = 0; i < 31; i++)
    data[i] = 65 + (i%26);
  app0 -> SetAdvString (data);
  for (int i = 0; i < 31; i++)
    data[i] = 91 - (i%26);
  app1 -> SetAdvString (data);

  char connData[100];
  for (int i = 0; i < 100; i++)
    connData[i] = 97 + (i%26);
  app0->SetConnString (connData);
  for (int i = 0; i < 100; i++)
    connData[i] = 122 - (i%26);
  app1 -> SetConnString (connData);

  Ptr<Packet> pkt = Create<Packet> (6);
  perLL->SetAdvInterval (Time("100ms"));
  centLL->SetAdvInterval (Time("100ms"));
  centLL->SetAdvListenWindow (Time("90ms"));
  centLL->SetRole (BleLinkLayer::SCANNER_ACT);
  perLL->SetRole (BleLinkLayer::ADVERTISER);
  perLL->SetAdvMode (BleLinkLayer::DISC_ADV);
  perLL->SetRxDeviceAddress (centLL->GetMacAddress ());
  centLL->SetTxWindowSize (8);
  centLL->SetTxWindowOffset (10);
  centLL->SetConnectionInterval (8);
  centLL->SetSlaveLatency (100);
  centLL->SetSupervisionTimeout (100);

  perLL->RxFromL2cap (pkt);
  perLL->TxToPhy ();

  Simulator::Stop(Time("500ms"));
  Simulator::Run();
}
