/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/core-module.h>
#include <ns3/network-module.h>
#include <ns3/mobility-module.h>
#include <ns3/propagation-module.h>
#include <ns3/spectrum-module.h>

#include <ns3/ble-phy.h>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("BlePhyExample");

static void GenerateTraffic (Ptr<BlePhy> sender, uint32_t pktSize,
                             uint32_t pktCount, Time pktInterval)
{
  if (pktCount > 0)
    {
      sender->RxPacketFromLinkLayer (Create<Packet> (pktSize));
      sender->ChangeState(BlePhy::TRANS);
      sender->StartTx ();
      Simulator::Schedule (pktInterval, &GenerateTraffic,
                           sender, pktSize, pktCount-1, pktInterval);
    }
}

void SendOnePacket (Ptr<BlePhy> sender, Ptr<BlePhy> receiver)
{
  uint32_t n = 10;
  Ptr<Packet> pkt = Create<Packet> (n);
  sender->RxPacketFromLinkLayer (pkt);
  sender->ChangeState(BlePhy::TRANS);
  receiver->ChangeState(BlePhy::LISTEN);

  sender->StartTx ();
}

int
main (int argc, char *argv[])
{
  double distanceToRx = 1;

  LogComponentEnable ("BlePhy", LOG_LEVEL_DEBUG);

  NodeContainer bleNodes;
  bleNodes.Create (4);

  Ptr<BlePhy> phy0 = CreateObject<BlePhy> ();
  Ptr<BlePhy> phy1 = CreateObject<BlePhy> ();
  Ptr<BlePhy> phy2 = CreateObject<BlePhy> ();
  Ptr<BlePhy> phy3 = CreateObject<BlePhy> ();

  phy0->SetChannelNo (1);
  phy0->SetTxPower (10); // Set txPower = 10dBm
  phy1->SetChannelNo (1);
  phy1->SetRxSensitivity (-80); // Set rxSense = -80dBm
  phy2->SetChannelNo (1);
  phy2->SetTxPower (10); // Set txPower = 10dBm
  phy3->SetChannelNo (1);
  phy3->SetTxPower (10); // Set txPower = 10dBm

  MobilityHelper mobility;
  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator> ();
  positionAlloc->Add (Vector (distanceToRx, 0.0, 0.0));
  positionAlloc->Add (Vector (0.0, 0.0, 0.0));
  positionAlloc->Add (Vector (-distanceToRx, 0.0, 0.0));
  positionAlloc->Add (Vector (0.0, -distanceToRx, 0.0));
  mobility.SetPositionAllocator (positionAlloc);
  mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
  mobility.Install (bleNodes);

  phy0->SetMobility (bleNodes.Get (0)->GetObject<MobilityModel> ());
  phy1->SetMobility (bleNodes.Get (1)->GetObject<MobilityModel> ());
  phy2->SetMobility (bleNodes.Get (2)->GetObject<MobilityModel> ());
  phy3->SetMobility (bleNodes.Get (3)->GetObject<MobilityModel> ());

  Ptr<ShannonSpectrumErrorModel> shannonError = Create<ShannonSpectrumErrorModel> ();
  phy0->SetErrorModel (shannonError);
  phy1->SetErrorModel (shannonError);
  phy2->SetErrorModel (shannonError);
  phy3->SetErrorModel (shannonError);

  Ptr<SingleModelSpectrumChannel> ch = CreateObject<SingleModelSpectrumChannel> ();

  Ptr<ConstantSpeedPropagationDelayModel> pdm = CreateObject<ConstantSpeedPropagationDelayModel> ();
  (*ch).SetPropagationDelayModel (pdm);

  Ptr<PropagationLossModel> plm = CreateObject<LogDistancePropagationLossModel> ();
  (*ch).AddPropagationLossModel (plm);

  phy0->SetChannel (ch);
  phy1->SetChannel (ch);
  phy2->SetChannel (ch);
  phy3->SetChannel (ch);

  phy1->ChangeState(BlePhy::LISTEN);

  Simulator::Schedule (Seconds (0.0), &GenerateTraffic, phy0, 10, 1, Time(81000));
  Simulator::Schedule (Time (1000), &GenerateTraffic, phy2, 10, 5, Time(160000));
  Simulator::Schedule (Time (1001), &GenerateTraffic, phy3, 10, 5, Time(160000));

  Simulator::Run();
  Simulator::Stop(Time(1e5));

  return 0;

}
