/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/nstime.h>
#include <ns3/core-module.h>
#include <ns3/network-module.h>

#include <ns3/spectrum-module.h>
#include <ns3/ble-module.h>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("BleLinkLayerConnExample");

int
main (int argc, char *argv[])
{
  Packet::EnablePrinting ();
  LogComponentEnable ("BleApplication", LOG_LEVEL_DEBUG);
  LogComponentEnable ("BleLinkLayer", LOG_LEVEL_DEBUG);
//  LogComponentEnable ("BlePhy", LOG_LEVEL_DEBUG);

  NodeContainer bleCentral;
  bleCentral.Create (1);
  NodeContainer blePeripheral;
  blePeripheral.Create (10);

  BleHelper bleHelper;
  Ptr<SingleModelSpectrumChannel> ch = CreateObject<SingleModelSpectrumChannel> ();

  bleHelper.SetChannel (ch);

  NetDeviceContainer centDevice = bleHelper.Install (bleCentral, BleLinkLayer::CENTRAL);
  NetDeviceContainer periDevice = bleHelper.Install (blePeripheral, BleLinkLayer::PERIPHERAL);

  Mac48Address addr;
  bleHelper.AllocateAddress (centDevice, addr);
  bleHelper.AllocateAddress (periDevice, addr);

  for (NetDeviceContainer::Iterator i = periDevice.Begin ();
                                    i != periDevice.End ();
                                    i++)
    {
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvInterval (Time("100ms"));
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRole (BleLinkLayer::ADVERTISER);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvMode (BleLinkLayer::GENERAL_ADV);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRxDeviceAddress ((*centDevice.Begin ())->GetObject<BleNetDevice> ()->GetMacAddress ());
    }

  for (NetDeviceContainer::Iterator i = centDevice.Begin ();
                                    i != centDevice.End ();
                                    i++)
    {
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvInterval (Time("100ms"));
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetAdvListenWindow (Time("90ms"));
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetRole (BleLinkLayer::SCANNER_ACT);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetTxWindowSize (8);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetTxWindowOffset (10);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetConnectionInterval (16);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetSlaveLatency (3);
      (*i)->GetObject<BleNetDevice> ()->GetLinkLayer ()->SetSupervisionTimeout (50);
    }
  bleHelper.EnableAsciiAll ("Ble");

  Simulator::Stop(Time("4s"));
  Simulator::Run();
}
