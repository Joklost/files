/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/packet.h>

#include "ble-linklayer-trailer.h"

namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (BleLinkLayerTrailer);

BleLinkLayerTrailer::BleLinkLayerTrailer (void)
  : m_crcInitVal (0)
{
}

TypeId
BleLinkLayerTrailer::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BleLinkLayerTrailer")
    .SetParent<Trailer> ()
    .SetGroupName ("Ble")
    .AddConstructor<BleLinkLayerTrailer> ()
  ;
  return tid;
}

TypeId
BleLinkLayerTrailer::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

void
BleLinkLayerTrailer::Print (std::ostream &os) const
{
  os << " CRC = " << m_crcVal;
}

uint32_t
BleLinkLayerTrailer::GetSerializedSize (void) const
{
  return 3; // 24-bit CRC
}

void
BleLinkLayerTrailer::Serialize (Buffer::Iterator start) const
{
  start.Prev (3);
  uint32_t crc = m_crcVal;
  start.WriteU8 (crc & 0xff);
  crc >>= 8;
  start.WriteU8 (crc & 0xff);
  crc >>= 8;
  start.WriteU8 (crc & 0xff);
}

uint32_t
BleLinkLayerTrailer::Deserialize (Buffer::Iterator start)
{
  start.Prev (3);
  uint8_t byte0 = start.ReadU8 ();
  uint8_t byte1 = start.ReadU8 ();
  uint8_t byte2 = start.ReadU8 ();
  uint32_t crc = byte2;
  crc <<= 8;
  crc |= byte1;
  crc <<= 8;
  crc |= byte0;
  m_crcVal = crc;

  return 3;
}

uint32_t
BleLinkLayerTrailer::GetCrc24 (void) const
{
  return m_crcVal;
}

void
BleLinkLayerTrailer::SetCrc24 (Ptr<const Packet> p)
{
  // Make sure that this packet does not contain Trailer. Also, ensure that it contains Header. No condition check about this.
  uint32_t size = p->GetSize ();
  uint8_t *serial_packet = new uint8_t[size];
  p->CopyData (serial_packet, size);
  // Calculate CRC for Header, Length and Payload only.
  uint8_t *serial_packet_without_accAddr = new uint8_t[size-5];
  for (uint32_t i = 0; i < size-5; i++)
    serial_packet_without_accAddr[i] = serial_packet[i+5];

  m_crcVal = GenerateCrc24 (serial_packet_without_accAddr, size-5);
  delete[] serial_packet;
  delete[] serial_packet_without_accAddr;
}

bool
BleLinkLayerTrailer::CheckCrc24 (Ptr<const Packet> p)
{
  // Make sure that this packet does not contain Trailer. Also, ensure that it contains Header. No condition check about this.
  // To check pkt, remove trailer. And pass the remaining packet to CheckCrc24 function of removed header.
  uint32_t checkCrc;
  uint32_t size = p->GetSize ();
  uint8_t *serial_packet = new uint8_t[size];
  p->CopyData (serial_packet, size);
  // Calculate CRC for Header, Length and Payload only.
  uint8_t *serial_packet_without_accAddr = new uint8_t[size-5];
  for (uint32_t i = 0; i < size-5; i++)
    serial_packet_without_accAddr[i] = serial_packet[i+5];

  checkCrc = GenerateCrc24 (serial_packet_without_accAddr, size-5);
  delete[] serial_packet;
  delete[] serial_packet_without_accAddr;
  return (m_crcVal == checkCrc);
}

uint32_t
BleLinkLayerTrailer::GenerateCrc24 (uint8_t *data, int length)
{
  uint32_t crc = 0;
  // TODO: Calculate CRC24
  return crc;
}

void
BleLinkLayerTrailer::SetCrcInit (uint32_t initVal)
{
  NS_ASSERT_MSG (initVal < 2e24, "Init Value for CRC calculation must be 24-bit.");
  m_crcInitVal = initVal;
}


} // namespace ns3
