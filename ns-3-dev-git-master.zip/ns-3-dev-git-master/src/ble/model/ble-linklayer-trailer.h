/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

/*
 * Following class implements the BLE LinkLayer Trailer
 * Trailer contains CRC value of packet
 */

#ifndef BLE_LL_TRAILER_H
#define BLE_LL_TRAILER_H

#include <ns3/trailer.h>

namespace ns3 {

/**
 * \ingroup ble
 * Represents the LinkLayer Trailer
 */
class BleLinkLayerTrailer : public Trailer
{
public:
  /**
   * Get the type ID.
   *
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);

  /**
   * \breif Default Constructor
   *
   */
  BleLinkLayerTrailer (void);

  // Inherited from the Trailer class.
  virtual TypeId GetInstanceTypeId (void) const;
  virtual void Print (std::ostream &os) const;
  virtual uint32_t GetSerializedSize (void) const;
  virtual void Serialize (Buffer::Iterator start) const;
  virtual uint32_t Deserialize (Buffer::Iterator start);

  /**
   * Get this trailer CRC value.
   * \return CTC value
   */
  uint32_t GetCrc24 (void) const;

  /**
   * Set initial CRC value for CRC calculation.
   * \param 24 bit integer
   */
  void SetCrcInit (uint32_t initVal);

  /**
   * Calculate 24 bit CRC value for Packet.
   * \param Pointer to packet
   */
  void SetCrc24 (Ptr<const Packet> p);

  /**
   * Check CRC of received packet with the trailer of the packet.
   * The packet in the param includes the trailer of the packet.
   */
  bool CheckCrc24 (Ptr<const Packet> p);

private:
  /**
   * Calculate the 24-bit CRC value.
   * Generator Polynomial = ^24 + ^10 + ^9 + ^6 + ^4 + ^3 + ^1 + ^0
   * Initial value = m_crcInitVal
   * \param data the checksum will be calculate over this data
   * \param length the length of the data
   * \return the checksum
   */
  uint32_t GenerateCrc24 (uint8_t *data, int length);

  /**
   * Initial value of CRC. Will be decided by Master LL. Before creating a trailer, this must be set.
   */
  uint32_t m_crcInitVal;

  /**
   * Value of generated CRC. This value will be serialized in Trailer
   */
  uint32_t m_crcVal;
};

} // namespace ns3

#endif // BLE_LL_TRAILER_H
