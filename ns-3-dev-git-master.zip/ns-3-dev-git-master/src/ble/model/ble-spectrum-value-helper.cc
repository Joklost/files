/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <cmath>

#include <ns3/log.h>

#include <ns3/spectrum-value.h>

#include "ns3/ble-spectrum-value-helper.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleSpectrumValueHelper");

Ptr<SpectrumModel> g_BleSpectrumModel; //!< Global object used to initialize the BleSpectrumModel

/**
 * \ingroup ble
 * \brief Helper class used to automatically initialize the Ble Spectrum Model Objects
 */
class BleSpectrumModelInitializer
{
public:
  BleSpectrumModelInitializer (void)
  {
    Bands bands;

    for (int i = 0; i<40; i++)
      {
        BandInfo bi;
        if (i < 11)
        {
          bi.fc = 2404.00e6 + i*2.00e6;
        }
        else if (i < 37)
        {
          bi.fc = 2428.00e6 + (i-11)*2.00e6;
        }
        else if (i == 37)
        {
          bi.fc = 2401.00e6;
        }
        else if (i == 38)
        {
          bi.fc = 2426.00e6;
        }
        else if (i == 39)
        {
          bi.fc = 2480.00e6;
        }
        bi.fl = bi.fc - 1.00e6;
        bi.fh = bi.fc + 1.00e6;
        bands.push_back (bi);
      }

    g_BleSpectrumModel =  Create<SpectrumModel> (bands);
  }
} g_BleSPectrumModelInitializerInstance; //~< Global object used to initialize the BleSpectrumModel


BleSpectrumValueHelper::BleSpectrumValueHelper (void)
{
  NS_LOG_FUNCTION (this);
  m_noiseFactor = 1.0;
}

BleSpectrumValueHelper::BleSpectrumValueHelper (double noiseFactor): m_noiseFactor (abs(noiseFactor))
{
}

BleSpectrumValueHelper::~BleSpectrumValueHelper (void)
{
  NS_LOG_FUNCTION (this);
}

Ptr<SpectrumValue>
BleSpectrumValueHelper::CreateTxPowerSpectralDensity(double txPower, uint32_t channel)
{
  NS_LOG_FUNCTION (this);
  Ptr<SpectrumValue> txPsd = Create<SpectrumValue> (g_BleSpectrumModel);

  // txPower is in dBm. Convert to Watt
  txPower = pow (10.0, (txPower - 30)/10);

  // The bandwidth of signal having power txPower is 2 MHz.
  double txPowerDensity = txPower / 2.00e6;

  NS_ASSERT_MSG ((channel < 40 && channel >= 0), "Invalid Channel Numbers");
  (*txPsd)[channel] = txPowerDensity;

  return txPsd;
}

Ptr<SpectrumValue>
BleSpectrumValueHelper::CreateNoisePowerSpectralDensity(uint32_t channel)
{
  NS_LOG_FUNCTION (this);
  Ptr<SpectrumValue> noisePsd = Create <SpectrumValue> (g_BleSpectrumModel);

  static const double BOLTZMANN = 1.3803e-23;
  double roomTemp = 290.0; // in K
  double noisePowerDensity = m_noiseFactor * BOLTZMANN * roomTemp;

  NS_ASSERT_MSG ((channel < 40 && channel >= 0), "Invalid Channel Numbers");

  (*noisePsd)[channel] = noisePowerDensity;

  return noisePsd;
}

Ptr<SpectrumValue>
BleSpectrumValueHelper::CreateNoisePowerSpectralDensity(void)
{
  NS_LOG_FUNCTION (this);
  Ptr<SpectrumValue> noisePsd = Create <SpectrumValue> (g_BleSpectrumModel);

  static const double BOLTZMANN = 1.3803e-23;
  double roomTemp = 290.0; // in K
  double noisePowerDensity = m_noiseFactor * BOLTZMANN * roomTemp;

  for (int i = 0; i < 40; i++)
    (*noisePsd)[i] = noisePowerDensity;

  return noisePsd;
}

double
BleSpectrumValueHelper::TotalAvgPower (Ptr<const SpectrumValue> psd, uint32_t channel)
{
  NS_LOG_FUNCTION (psd);
  double totalAvgPower = 0.0;

  NS_ASSERT (psd->GetSpectrumModel () == g_BleSpectrumModel);

  totalAvgPower += (*psd)[channel];
  totalAvgPower *= 2.0e6;
  return totalAvgPower;
}

} // namespace ns3
