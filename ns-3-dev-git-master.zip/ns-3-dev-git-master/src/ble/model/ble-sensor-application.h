/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_SENSOR_APPLICATION_H
#define BLE_SENSOR_APPLICATION_H

#include <ns3/ptr.h>
#include <ns3/packet.h>
#include <ns3/application.h>
#include "ble-linklayer.h"

namespace ns3 {

struct BleTimeStamp {
  uint16_t year;
  uint8_t month;
  uint8_t day;
  uint8_t hours;
  uint8_t minute;
  uint8_t second;
};

/**
 * \ingroup ble
 * \brief Implementation of senssor application
 */
class BleSensorApplication : public Application
{
public:

typedef enum {
  CONNECTION_SLAVE,
  CONNECTION_MASTER,
  ADVERTISE,
  SCANNING,
  IDLE,
  PAUSED
} BleApplicationState;

public:
  /**
   * \brief Get the type ID
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);
  /**
   * \brief Default Constructor
   */
  BleSensorApplication (void);
  virtual ~BleSensorApplication (void);

  /**
   * \brief Get LinkLayer
   * \return Pointer to BleLinkLayer
   */
  Ptr<BleLinkLayer> GetLinkLayer (void) const;
  /**
   * \brief Set LinkLayer
   * \param ll Pointer to BleLinkLayer
   */
  void SetLinkLayer (Ptr<BleLinkLayer> ll);

  /**
   * \brief Received packet from LinkLayer
   * \param p Received packet
   * \param int1 Integer parameter 1
   * \param int2 Integer parameter 2
   *
   * When Application is in SCANNING mode,
   * int1 = 0 => Connection request not Allowed
   * int1 = 1 => Conenction request allowed
   * int1 = 2 => Only Connection request is allowed
   *
   * int2 = 0 => Scan Request not allowed
   * int2 = 1 => Scan Request allowed
   *
   * When Application is in ADVERTISE mode,
   * int2 = 0 => Received packet is Connection Request
   * int2 = 1 => Received packet is Scan Request
   *
   * When Application is in CONNECTION_SLAVE mode,
   * int1 = int2 = 1 => Connection is closed. Change state to Advertise
   *
   * When Application is in CONNECTION_MASTER mode,
   * int1 = int2 = 1 => Connection closed
   * int1 = 1 and int2 = 0 => ConnectionEvent restart
   */
  void RxFromLinkLayer (Ptr<Packet> p, uint8_t int1, uint8_t int2);
  /**
   * \brief Change state of application
   * \param s new state of application
   */
  void ChangeState (BleApplicationState s);
  /**
   * \brief Create and Send AdvPacket
   */
  void SendAdvPacket (void);
  /**
   * \brief Send request packet to LinkLayer
   * \param b Whether it is first request of connection
   */
  void SendRequestPacket (bool b);
  /**
   * \brief Create and Send Scan Request
   */
  void SendScanResponse (Ptr<Packet> p);
  /**
   * \brief Send Response Packet to LinkLayer
   * \param p Request packet
   */
  void SendResponsePacket (Ptr<Packet> p);
  /**
   * \brief Analyse Scan Response Packet
   * \param p Recevied Scan Response Packet
   */
  void AnalyseScanResponsePacket (Ptr<Packet> p);
  /**
   * \brief Analyse Response Packet and send ACK
   * \param p Recevied Response Packet
   */
  void AnalyseResponsePacket (Ptr<Packet> p);
  // Transmission related functions
  // Sensing events
  /**
   * Called at every 1 hr. If sensed then record time.
   */
  void SensingEvent (void);
  // Sensing Events done
  // Pause and start events - Battery drain handle
  /**
   * \brief Call to pause the application.
   * \note it will not stop the sensing. Sensing will be continued
   */
  void PauseApplication (void);
  /**
   * \brief Call to resume the application
   * \note it will just resume the transmission part
   */
  void ResumeApplication (void);
  // End of pause and resume events
  uint64_t GetSenseRxCount (void);
  // Inherited from Application Class
  void SetStartTime (Time start);
  void SetNode (Ptr<Node> node);
  Ptr<Node> GetNode () const;
protected:
  /**
   * \brief Call to start application by starting an advertisement
   */
  virtual void StartApplication (void);
private:
  /**
   * Time to TimeStamp Converter
   */
  BleTimeStamp TimetoTimeStamp (Time t);
  /**
   * ConnData
   */
  std::queue<std::pair<BleTimeStamp, bool> > m_data;
  /**
   * MoreData remaining?
   */
  bool isMoreData;
  /**
   * Current state of Application
   */
  BleApplicationState m_state;
  /**
   * LinkLayer connected to this application
   */
  Ptr<BleLinkLayer> m_linkLayer;
  /**
   * Random stream for sensing event -- Number of sensing events per day
   */
  Ptr<UniformRandomVariable> m_random; // TODO: Check the distribution
  /**
   * Open/Close
   */
  bool m_isOpen;
  /**
   * Sensing count
   */
  uint64_t m_senseCount;
  /**
   * Receive count
   */
  uint64_t m_rxCount;
  // Inherited from Application
  virtual void DoDispose (void);
  virtual void DoInitialize (void);

  Ptr<Node>       m_node;   //!< The node that this application is installed on
  Time m_startTime;         //!< The simulation time that the application will start
  Time m_stopTime;          //!< The simulation time that the application will end
  EventId m_startEvent;     //!< The event that will fire at m_startTime to start the application
  EventId m_stopEvent;      //!< The event that will fire at m_stopTime to end the application

};

} // namespace ns3

#endif
