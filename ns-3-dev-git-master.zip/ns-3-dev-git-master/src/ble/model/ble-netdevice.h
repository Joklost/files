/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_NET_DEVICE_H
#define BLE_NET_DEVICE_H

#include <ns3/ptr.h>

#include <ns3/node.h>
#include <ns3/net-device.h>
#include <ns3/address.h>

#include <ns3/spectrum-channel.h>

#include <ns3/ble-phy.h>
#include <ns3/ble-linklayer.h>

namespace ns3 {

/**
 * \ingroup ble
 *
 * \brief Link Layer to device interface
 * The ns3::NetDevice includes IP-specefic API which does not map well with the BLE protocol.
 * So, this class provides the basic design to provide a connection between Node, PHY, Channel and NetDevice.
 * There is as such no use of this class in the module but it is possible that  some inherited function needs a Net Device
 * class as parameter. Other possible requirement is when using other
 * modules like wifi etc. along with BLE. This class can get along with
 * classes with base class NetDevice.
 */
class BleNetDevice : public NetDevice
{
public:
  /**
   * Get the type ID.
   *
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);

  BleNetDevice (void);
  virtual ~BleNetDevice (void);

  /**
   * Set the LinkLayer to be used by this NetDevice.
   *
   * \param ll the pointer to Link Layer to be used.
   */
  void SetLinkLayer (Ptr<BleLinkLayer> ll);

  /**
   * Get the LinkLayer used by this Net Device.
   *
   * \return the Pointer to Link Layer
   */
  Ptr<BleLinkLayer> GetLinkLayer (void) const;

  /**
   * Set PHY to be used by the Link Layer and this NetDevice.
   *
   * \param phy the PHY to be used.
   */
  void SetPhy (Ptr<BlePhy> phy);

  /**
   * Get PHY to be used by the link layer and this Net Device.
   *
   * \return Pointer to PHY
   */
  Ptr<BlePhy> GetPhy (void) const;

  /**
   * Set Channel to which the Net Device, and therefore the PHY, should be
   * attached to.
   *
   * \param channel the channel to be used
   */
  void SetChannel (Ptr<SpectrumChannel> channel);

  /**
   * Get Addresses in Mac48Address Type
   */
  virtual void SetMacAddress (Mac48Address address);
  virtual Mac48Address GetMacAddress (void) const;

  /**
   * Complete all configurations
   * By using this function, linklayer, PHY, Channel and NetDevice are interconnected.
   * Set functions of all these components are used
   */
  void CompleteConfig (void);

  // Inherited from NetDevice
  virtual void SetIfIndex (const uint32_t index);
  virtual uint32_t GetIfIndex (void) const;
  virtual Ptr<Channel> GetChannel (void) const;
  virtual Ptr<Node> GetNode (void) const;
  virtual void SetNode (Ptr<Node> node);
  virtual void SetAddress (Address address);
  virtual Address GetAddress (void) const;
  virtual bool SetMtu (const uint16_t mtu);
  virtual uint16_t GetMtu (void) const;
  virtual bool IsLinkUp (void) const;
  // Inherited from NetDevice but more or less unused/unuseful
  virtual void AddLinkChangeCallback (Callback<void> callback);
  virtual bool IsBroadcast (void) const;
  virtual Address GetBroadcast (void) const;
  virtual bool IsMulticast (void) const;
  virtual Address GetMulticast (Ipv4Address multicastGroup) const;
  virtual Address GetMulticast (Ipv6Address addr) const;
  virtual bool IsBridge (void) const;
  virtual bool IsPointToPoint (void) const;
  virtual bool Send (Ptr<Packet> packet, const Address& dest, uint16_t protocolNumber);
  virtual bool SendFrom (Ptr<Packet> packet, const Address& source, const Address& dest, uint16_t protocolNumber);
  virtual bool NeedsArp (void) const;

  virtual void SetReceiveCallback (NetDevice::ReceiveCallback cb);
  virtual void SetPromiscReceiveCallback (PromiscReceiveCallback cb);
  virtual bool SupportsSendFrom (void) const;

private:
  // Inherited from Object
  virtual void DoDispose (void);
  virtual void DoInitialize (void);
  /**
   * Attribute accessor method for the "Channel" attribute.
   *
   * \return the channel to which this NetDevice is attached
   */
  Ptr<SpectrumChannel> DoGetChannel (void) const;

  /**
   * The Link Layer for this NetDevice
   */
  Ptr<BleLinkLayer> m_linkLayer;

  /**
   * The PHY for this NetDevice
   */
  Ptr<BlePhy> m_phy;

  /**
   * Node associated with the NetDevice
   */
  Ptr<Node> m_node;

  /**
   * Whether the configuration is complete or not
   */
  bool m_completeConfig;

  /**
   *
   */
  uint32_t m_ifIndex;

  /**
   * BDA Address of this device. It changes with every connection
   */
  Address m_addr;

  /**
   * BDA address with Mac48Address format
   */
  Mac48Address m_macAddr;

  /**
   * Is LinkUp?
   */
  bool m_linkUp;
};

} // namespace ns3

#endif // BLE_NET_DEVICE_H //
