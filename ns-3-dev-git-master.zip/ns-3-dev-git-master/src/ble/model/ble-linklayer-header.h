/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

/*
 * The following class implements the BLE LinkLayer Header.
 * THere are 2 types of BLE LinkLayer Header frames, and they have these fields
 *
 *   Header Frames : Fields
 *   -----------------------------------------------------------------------------------------------------------------
 *   ADV           : Preamble, Access Header, Adv Pkt Type, Reserved, Tx Addr Type, Rx Addr Type, Length, Payload, CRC
     DATA          : Preamble, Data Access Header, LLID, NESN, SN, MD, Reserved, Length, Payload, CRC
 *
 *   Access Header - For ADV: 0x8E89BED6
 *                   For DATA: Random 4 Byte Address at each connection
 *
 *   DATA and ADV are distinguished by ChannelNo.
 */

#ifndef BLE_LL_HEADER_H
#define BLE_LL_HEADER_H

#include <ns3/header.h>

#include "ble-access-address.h"

namespace ns3 {

/**
 * \ingroup ble
 * Represent the LinkLayer Header
 */
class BleLinkLayerHeader : public Header
{
public:
  /**
   * The possible Preamble types
   */
  enum BlePreamble
  {
    PREAMBLE_END_0 = 0xaa, //!< Preamble 10101010b
    PREAMBLE_END_1 = 0x55, //!< Preamble 01010101b
  };

  enum BlePacketType
  {
    ADV = 0,
    DATA = 1
  };

  enum AdvPacketType // 7 types of advertisement pkt
  {
    ADV_IND = 0,
    ADV_DIRECT_IND = 1,
    ADV_NONCONN_IND = 2,
    SCAN_REQ = 3,
    SCAN_RESP = 4,
    CONNECT_REQ = 5,
    ADV_SCAN_IND = 6
  };

  enum TxAddrType // For Advertisement packet header
  {
    TX_ADDR_PUBLIC = 0, //!< When the address is fix.
    TX_ADDR_RANDOM = 1  //!< When the address is changing at each connection
  };

  enum RxAddrType // For Advertisement packet header
  {
    RX_ADDR_PUBLIC = 0, //!< When the address is fix
    RX_ADDR_RANDOM = 1  //!< When the address is changing at each connection
  };

  enum LinkLayerId     // For DATA Packet - Link Layer Identifier
  {
    LL_CONTROL_PKT = 3, // Used for managing the connection
    LL_START_PKT = 2,   // Start of higher layer pkt or Complete Pkt
    LL_CONT_PKT = 1     // Continutaion of Higher Layer Pkt
  };

public:
  /*
   * Default constructor
   */
  BleLinkLayerHeader (void);
  /*
   * Default destructor
   */
  ~BleLinkLayerHeader (void);
  /**
   * \brief Get the type ID
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);
  virtual TypeId GetInstanceTypeId (void) const;
  void Print (std::ostream &os) const;
  uint32_t GetSerializedSize (void) const;
  void Serialize (Buffer::Iterator start) const;
  uint32_t Deserialize (Buffer::Iterator start);
  /**
   * Set LinkLayerDevice Address
   * \param ll Mac48Address
   */
  void SetMacAddress (Mac48Address addr);
  /**
   * Get LinkLayer Device Address
   * \return Mac48Address
   */
  Mac48Address GetMacAddress (void) const;
  /**
   * Set LinkLayerDevice Address of RxDevice. Used in DirectAdv
   * \param ll Mac48Address
   */
  void SetRxMacAddress (Mac48Address addr);
  /**
   * Get LinkLayer Device Address of RxDevice. Used in DirectAdv
   * \return Mac48Address
   */
  Mac48Address GetRxMacAddress (void) const;
  /**
   * Set accessAddress
   * \param addr Object of BleAccessAddress
   */
  void SetAccessAddress (BleAccessAddress addr);
  /**
   * Get accessAddress
   * \return object of BleAccessAddress
   */
  BleAccessAddress GetAccessAddress (void) const;
  /*
   * Set the header type
   * \param 1 for DATA type and 0 for ADV type
   */
  void SetType (BlePacketType t);
  /*
   * Get the header type
   * \return 1 for DATA type and 0 for ADV type
   */
  enum BlePacketType GetType (void) const;
  /*
   * Set ADV Packet Type
   * \param type AdvPacketType enum
   */
  void SetAdvPktType (AdvPacketType type);
  /*
   * Get ADV Packet Type
   * \return ADV Packet Type
   */
  AdvPacketType GetAdvPktType (void) const;
  /*
   * Set TxAddressType (1 for random, 0 for public)
   * \param type Either 1 or 0 for random and public address
   */
  void SetTxAddrType (TxAddrType type);
  /*
   * Get TxAddressType (1 for random, 0 for public)
   * \return 1 or 0 for random and public address respectively
   */
  TxAddrType GetTxAddrType (void) const;
  /*
   * Set RxAddressType (1 for random, 0 for public)
   * \param type Either 1 or 0 for random and public address
   */
  void SetRxAddrType (RxAddrType type);
  /*
   * Get RxAddressType (1 for random, 0 for public)
   * \return 1 or 0 for random and public address respectively
   */
  RxAddrType GetRxAddrType (void) const;
  /*
   * Set LinkLayer Identifier
   * \param llid LinkLayer Identifier
   */
  void SetLinkLayerId (LinkLayerId llid);
  /*
   * Get LinkLayer Identifier
   * \param llid LinkLayer Identifier
   */
  LinkLayerId GetLinkLayerId (void) const;
  /*
   * Set Next Sequence No
   * \param nesn true for 1 and false for 0
   */
  void SetNextSequenceNo (bool nesn);
  /*
   * Get Next Sequence No
   * \return true for 1 and false for 0
   */
  bool GetNextSequenceNo (void) const;
  /*
   * Set Sequence No
   * \param sn true for 1 and false for 0
   */
  void SetSequenceNo (bool sn);
  /*
   * Get Sequence No
   * \return true for 1 and false for 0
   */
  bool GetSequenceNo (void) const;
  /*
   * Set More Data bit
   * \param md true for 1 and false for 0
   */
  void SetMoreData (bool md);
  /*
   * Get More Data bit
   * \return true for 1 and false for 0
   */
  bool GetMoreData (void) const;
  /*
   * Set Length of Payload in Bytes
   * \param len Length of payload
   */
  void SetLength (uint8_t len);
  /*
   * Get Length of Payload in Bytes
   * \return Length of payload
   */
  uint8_t GetLength (void) const;

private:
  BlePacketType m_type;     //!< Type of packet. 1 for DATA and 0 for ADV
  /* Preamble */
  BlePreamble m_preamble;    //!< One of 2 preamble (1 Octet)

  /* Addressing Field */
  BleAccessAddress m_accessAddr;  //!< Access Address (4 Octets)

  /* Advertisement specific */
  AdvPacketType m_advType;  //!< ADV Packet type (2 bits)
  TxAddrType m_txAddrType;  //!< Tx Address Type (1 bit)
  RxAddrType m_rxAddrType;  //!< Rx Address Type (1 bit)
  Mac48Address m_macAddress; //!< LinkLayer address for ADV Packets
  Mac48Address m_rxMacAddress; //!< Receiver LinkLayer address for ADV Packets

  /* Data specific */
  LinkLayerId m_linkLayerId;  //!< LinkLayerIdentifier (2 bits)
  bool m_nextSeqNo;           //!< Next Sequence #     (1 bit)
  bool m_seqNo;               //!< Sequence #          (1 bit)
  bool m_moreData;            //!< More Data           (1 bit)

  uint8_t m_length; //!< Length of Data
};

} // namespace ns3

#endif // BLE_LL_HEADER_H
