/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_PHY_H
#define BLE_PHY_H

#include <ns3/traced-callback.h>
#include <ns3/traced-value.h>
#include <ns3/ptr.h>

#include <ns3/packet.h>
#include <ns3/net-device.h>
#include <ns3/mobility-model.h>

#include <ns3/antenna-model.h>

#include <ns3/spectrum-channel.h>
#include <ns3/spectrum-phy.h>
#include <ns3/spectrum-error-model.h>

#include "ble-interference-helper.h"
#include "ble-spectrum-signal-parameters.h"

namespace ns3 {

class Packet;
class UniformRandomVariable;
/**
 * \defgroup ble Bluetooth Low Energy
 *
 * This module contains stack of Bluetooth Low Energy Protocol
 */

/**
 * \ingroup ble
 *
 * \brief Implementation of PhyLayer of BLE protocol
 */
class BlePhy : public SpectrumPhy {
public:
typedef enum
{
  OFF,
  IDLE,
  LISTEN,
  BUSY_RX,
  TRANS,
  BUSY_TX
} BlePhyState;


public:
  /*
   * Default Constructor
   */
  BlePhy (void); //Set state, default rx_sense, channelNo (0), txPower

  /*
   * Default Destructor
   */
  virtual ~BlePhy (void);

  /**
   * \brief Get the type ID.
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);

  /*
   * Receive Packet from LinkLayer to transmit. Called by LinkLayer.
   * Basically set the m_txPkt.
   *
   * /param pkt the Packet instance
   */
  void RxPacketFromLinkLayer (Ptr<Packet> pkt);

  /*
   * Called by Link Layer to start transmission.
   * Change state of PhyLayer. Convert Pkt to SpectrumSignalParameters
   * and add in the Channel object. Call EndTx after a delay
   * of Length of Pkt/Data rate.
   *
   */
  void StartTx (void);

  /*
   * Called by StartTx method. Change the state to IDLE or LISTEN.
   */
  void EndTx (void);

  /*
   * Called by StartTx to get the duration of packet
   *
   * \param packet Packet which is being transmitted
   * \return time required for transmission at given datarate
   */
  Time CalculateTxTime (Ptr<const Packet> packet);

  /*
   * Called by Channel to all connectd PhyInstance to start Rx.
   *
   * /param SpectrumSignalParameter instance corresponding to received signal
   */
  virtual void StartRx (Ptr<SpectrumSignalParameters> params);

  /**
   * Finish the reception of a Packet. This is called at the end of a packet
   * reception, applying possibly pending PHY state changes and fireing the
   * appropriate trace sources and indication callbacks to the LinkLayer. A packet
   * destroyed by noise/interference is dropped here, but not during reception.
   * This method is also called for every packet which only contributes to
   * interference.
   *
   * \param params signal parameters of the packet
   */
  void EndRx (Ptr<SpectrumSignalParameters> params);

  /*
   * Send Received Packet to Link Layer. Basically calls RxPktFromPhy function of Link Layer
   */
  void SendPktToLinkLayer (Ptr<Packet> p, uint8_t channnelNo);

  /*
   * Set txPower of PHY. Called by Link Layer
   *
   * \param txPower transmitted power in dBm
   *
   */
  void SetTxPower (double txPower);

  /*
   * Get txPower of PHY
   *
   * \return m_txPower
   */
  double GetTxPower (void);

  /*
   * Set Channel Number of BLE Spectrum Model. Called by Link Layer.
   *
   * \param channel_no Channel Number from 0-39
   */
  void SetChannelNo (uint32_t channel_no);

  /*
   * Get Channel Number of BLE Spectrum Model
   *
   * \return m_channel
   */
  uint32_t GetChannelNo (void);

  /*
   * Set Rx Sensitivity of PHY
   *
   * \param rxSensitivity
   */
  void SetRxSensitivity (double rxSensitivity);

  /*
   * Get Rx Sensitivity of PHY
   *
   * \return m_rxSensitivity
   */
  double GetRxSensitivity (void);

  /**
   * set the error model to use
   *
   * @param e pointer to SpectrumErrorModel to use
   */
  void SetErrorModel (Ptr<SpectrumErrorModel> e);

  /**
   * get the error model in use
   *
   * @return pointer to SpectrumErrorModel in use
   */
  Ptr<SpectrumErrorModel> GetErrorModel (void) const;

  /**
   * Set the noise power spectral density.
   *
   * \param noisePsd the Noise Power Spectral Density in power units
   * (Watt, Pascal...) per Hz.
   */
  void SetNoisePowerSpectralDensity (Ptr<const SpectrumValue> noisePsd);

  /**
   * Get the noise power spectral density.
   *
   * \return the Noise Power Spectral Density
   */
  Ptr<const SpectrumValue> GetNoisePowerSpectralDensity (void);

  /*
   * Get state of PhyLayer. Sometimes called by LinkLayer
   *
   * \return current state of PHY
   */
  BlePhyState GetState (void) const;
  /*
   * Set next Pending State of PhyLayer. Sometimes called by LinkLayer
   *
   * \param state set next pending state of PHY
   */
  void SetNextPendingState (BlePhyState state);
  /*
   * Change state of PhyLayer to Next Pending state. Mostly Used internally. Sometimes called by LinkLayer
   */
  void ChangeState ();
  /*
   * Change state of PhyLayer. Mostly Used internally. Sometimes called by LinkLayer
   *
   * \param new_state the state is changed to
   */
  void ChangeState (BlePhyState new_state);
  /*
   * Set mode to IDLE
   */
  void SetIdleState ();
  //Inherited from SpectrumPhy
  virtual void SetDevice (Ptr<NetDevice> d);
  virtual Ptr<NetDevice> GetDevice (void) const;
  virtual void SetMobility (Ptr<MobilityModel> m);
  virtual Ptr<MobilityModel> GetMobility ();
  virtual void SetChannel (Ptr<SpectrumChannel> c);
  virtual Ptr<SpectrumChannel> GetChannel ();
  virtual Ptr<const SpectrumModel> GetRxSpectrumModel () const;
  virtual void SetRxAntenna (Ptr<AntennaModel> a);
  virtual Ptr<AntennaModel> GetRxAntenna ();

private:

  /*
   * Check Interference effect on received packet. Used in StartRx.
   */
  void CheckInterference (void);
  /*
   * Current state of Phy
   */
  TracedValue<BlePhyState> m_state;
  /*
   * Next pending state of Phy
   */
  BlePhyState m_nextPendingState;
  /*
   * Interrupt during state changed
   * May be because of energy depletion
   */
  public:
    bool m_interrupt;
private:
  /*
   * Datarate of BLE in bps
   */
  static constexpr double g_dataRate = 1.00e6; // bps

  /*
   * Rx Sensitivity in dBm
   */
  double m_rxSensitivity;

  /*
   * ChannelNo of operation. Between 0-39
   */
  uint32_t m_channelNo;

  /*
   * Transmission Power in dBm
   */
  double m_txPower;

  /**
   * The transmit power spectral density.
   */
  Ptr<SpectrumValue> m_txPsd;

  /**
   * The accumulated signals currently received by the transceiver, including
   * the signal of a possibly received packet, as well as all signals
   * considered noise.
   */
  Ptr<BleInterferenceHelper> m_signal;

  /**
   * The spectral density for for the noise.
   */
  Ptr<const SpectrumValue> m_noise;

  /**
   * The error model describing the bit and packet error rates.
   */
  Ptr<SpectrumErrorModel> m_errorModel;

  /*
   * SpectrumSignalParameter instance to be transmitted in next StartTx
   * call. Boolean value is the state whether the packet has been
   * transmitted or not.
   */
  std::pair<Ptr<BleSpectrumSignalParameters>, bool> m_currentTxParam;

  /*
   * Last received packet with status whether it is corrupted or not.
   */
  std::pair<Ptr<BleSpectrumSignalParameters>, bool>  m_currentRxParam;

  // Inherited from SpectrumPhy
  Ptr<MobilityModel> m_mobility;
  Ptr<SpectrumChannel> m_channel;
  Ptr<AntennaModel> m_antenna;
  Ptr<NetDevice> m_netDevice;

  // Trace sources
  /**
   * The trace source fired when a packet transmitted to LinkLayer
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<Packet>,uint8_t> m_txToLLTrace;
  /**
   * The trace source fired when a packet begins the transmission process on
   * the medium.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_phyTxBeginTrace;

  /**
   * The trace source fired when a packet ends the transmission process on
   * the medium.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_phyTxEndTrace;

  /**
   * The trace source fired when the phy layer drops a packet as it tries
   * to transmit it.
  *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_phyTxDropTrace;

  /**
   * The trace source fired when a packet begins the reception process from
   * the medium.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_phyRxBeginTrace;

  /**
   * The trace source fired when a packet ends the reception process from
   * the medium.  Second quantity is received SINR.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet>, double > m_phyRxEndTrace;

  /**
   * The trace source fired when the phy layer drops a packet it has received.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_phyRxDropTrace;

  /**
   * Uniform random variable stream.
   */
  Ptr<UniformRandomVariable> m_random;

  /**
   * Timestamp of the most recently received signal. Hence, the slot when maximum
   * interference occurred at receiving antenna.
   */
  Time m_recentSignalRx;
};

namespace TracedValueCallback
{
/**
 * \ingroup ble
 * TracedValue callback signature for BlePhyState.
 *
 * \param [in] oldValue original value of the traced variable
 * \param [in] newValue new value of the traced variable
 */
  typedef void (* BlePhyState)(BlePhy::BlePhyState oldValue, BlePhy::BlePhyState newValue);
}  // namespace TracedValueCallback

} // namespace ns3

#endif /* BLE_PHY_H */
