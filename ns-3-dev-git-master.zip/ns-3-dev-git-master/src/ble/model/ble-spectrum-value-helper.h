/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_SPECTRUM_VALUE_HELPER_H
#define BLE_SPECTRUM_VALUE_HELPER_H

#include <ns3/simple-ref-count.h>
#include <ns3/ptr.h>

#include <ns3/spectrum-model.h>

namespace ns3 {

class SpectrumValue;

/**
 * \ingroup ble
 *
 * \brief This class defines all functions to create spectrum value for spectrum model for BLE
 */
class BleSpectrumValueHelper : public SimpleRefCount<BleSpectrumValueHelper>
{
public:
  BleSpectrumValueHelper (void);
  BleSpectrumValueHelper (double);
  virtual ~BleSpectrumValueHelper (void);

  /**
   * \brief create spectrum value
   * To create a spectrum value object with given txPower in given channel.   *
   * \param txPower the power transmission in dBm
   * \param channel the channel number of BLE channels
   * \return a Ptr to a newly created SpectrumValue instance
   */
  Ptr<SpectrumValue> CreateTxPowerSpectralDensity (double txPower, uint32_t channel);

  /**
   * \brief create a noise in channel
   * The noise power spectral density will be calculated from noise factor
   * \param channel (Default all Channels i.e. white noise spectrum values)
   * \return a Ptr to a newly created SpectrumValue instance
   */
  Ptr<SpectrumValue> CreateNoisePowerSpectralDensity (uint32_t channel);
  Ptr<SpectrumValue> CreateNoisePowerSpectralDensity (void);

  /**
   * \brief total average power of the signal is the integral of the PSD using
   * the limits of the given channel
   * \param psd spectral density
   * \param channel the channel number as per BLE specifications
   * \return total power (using composite trap. rule to numerally integrate)
   */
  static double TotalAvgPower (Ptr<const SpectrumValue> psd, uint32_t channel);

private:
  /**
   * A scaling factor for the noise power
   */
  double m_noiseFactor;
};

}; // namespace ns3

#endif /*  BLE_SPECTRUM_VALUE_HELPER_H */
