/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_RADIO_ENERGY_MODEL_H
#define BLE_RADIO_ENERGY_MODEL_H

#include "ns3/device-energy-model.h"
#include "ns3/nstime.h"
#include "ns3/event-id.h"
#include "ns3/traced-value.h"
#include "ns3/ble-phy.h"

namespace ns3 {

/**
 * \ingroup energy
 * \brief A BLE radio energy model
 *
 * 4 states are defined for the radio: BUSY_TX, BUSY_RX, IDLE. Default state is IDLE.
 *
 * Energy calculation: For each transaction, this model notifies EnergySource
 * object. The EnergySource object will query this model for the total current.
 * Then the EnergySource object uses the total current to calculate energy.
 *
 * Specifications of
 * 1. NRF51822:
 *  \f$ I_{tx} = 0.01 \f$
 *  \f$ I_{rx} = 0.0097 \f$
 *  RxSensitivity = -93 dBm
 *  TxPower = 0 dBm
 * 2. CC2650: -- Default values
 *  \f$ I_{tx} = 0.0061 \f$
 *  \f$ I_{rx} = 0.0059 \f$
 *  RxSensitivity = -97 dBm
 *  TxPower = 0 dBm
 */
class BleRadioEnergyModel : public DeviceEnergyModel
{
public:
  /**
   * Callback type for energy depletion handling
   */
  typedef Callback <void> BleRadioEnergyDepletionCallback;
  /**
   * Callback for energy recharged handling
   */
  typedef Callback<void> BleRadioEnergyRechargedCallback;

  static TypeId GetTypeId (void);
  BleRadioEnergyModel ();
  virtual ~BleRadioEnergyModel ();
  /**
   * \brief Sets pointer to PHY on node.
   *
   * \param phy Pointer to PHY installed on node.
   */
  virtual void SetPhy (Ptr<BlePhy> phy);
  /**
   * \brief Sets pointer to Energy Source instaleld on node
   *
   * \param source Pointer to Energy Source installed on node.
   * Implements DeviceEnergyModel::SetEnergySource
   */
  virtual void SetEnergySource (Ptr<EnergySource> source);
  /**
   * \returns Total energy consumption of the wifi device
   * Implements DeviceEnergyModel::GetTotalEnergyConsumption
   */
  virtual double GetTotalEnergyConsumption (void) const;
  // Setter & Getters for state power consumption
  double GetOffCurrentA (void) const;
  void SetOffCurrentA (double offCurrentA);
  double GetIdleCurrentA (void) const;
  void SetIdleCurrentA (double idleCurrentA);
  double GetTxCurrentA (void) const;
  void SetTxCurrentA (double txCurrentA);
  double GetRxCurrentA (void) const;
  void SetRxCurrentA (double rxCurrentA);
  /**
   * \return Current state
   */
  BlePhy::BlePhyState GetCurrentState (void) const;
  /**
   * \param callback Callback function
   * Sets callback for energy depletion handling
   */
  void SetEnergyDepletionCallback (BleRadioEnergyDepletionCallback callback);

  /**
   * \param callback Callback function.
   *
   * Sets callback for energy recharged handling.
   */
  void SetEnergyRechargedCallback (BleRadioEnergyRechargedCallback callback);
  /**
   * \brief Changes state of the BleRadioEnergyMode.
   *
   * \param newState New state the ble radio is in.
   *
   * Implements DeviceEnergyModel::ChangeState.
   */
  virtual void ChangeState (int newState);
  /*
   * \brief Function calls other ChangeState internally. Used to make an appropriate callback
   * \param oldState OldState of BlePHY
   * \param newState newState of BlePhy
   */
  void ChangeState (BlePhy::BlePhyState oldState, BlePhy::BlePhyState newState);

  /**
   * \brief Handles energy depletion.
   *
   * Implements DeviceEnergyModel::HandleEnergyDepletion
   */
  virtual void HandleEnergyDepletion (void);

  /**
   * \brief Handles energy recharged.
   *
   * Implements DeviceEnergyModel::HandleEnergyRecharged
   */
  virtual void HandleEnergyRecharged (void);

private:
  void DoDispose (void);

  /**
   * \returns Current draw of device, at current state.
   *
   * Implements DeviceEnergyModel::GetCurrentA.
   */
  virtual double DoGetCurrentA (void) const;

  /**
   * \param state New state the radio device is currently in.
   *
   * Sets current state. This function is private so that only the energy model
   * can change its own state.
   */
  void SetBleRadioState (const BlePhy::BlePhyState state);

private:
  Ptr<EnergySource> m_source;

  // Member variables for current draw in different radio modes.
  double m_txCurrentA;
  double m_rxCurrentA;
  double m_offCurrentA;
  double m_idleCurrentA;

  // This variable keeps track of the total energy consumed by this model.
  TracedValue<double> m_totalEnergyConsumption;

  // State variables.
  BlePhy::BlePhyState m_currentState;  // current state the radio is in
  Time m_lastUpdateTime;          // time stamp of previous energy update

  uint8_t m_nPendingChangeState;
  bool m_isSupersededChangeState;

  // Energy depletion callback
  BleRadioEnergyDepletionCallback m_energyDepletionCallback;

  // Energy recharged callback
  BleRadioEnergyRechargedCallback m_energyRechargedCallback;

  // Connected PhyLayer
  Ptr<BlePhy> m_phy;
};

} // namespace ns3

#endif /* BLE_RADIO_ENERGY_MODEL_H */
