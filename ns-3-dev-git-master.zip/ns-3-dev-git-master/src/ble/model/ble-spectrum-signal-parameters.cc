/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/log.h>

#include "ble-spectrum-signal-parameters.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleSpectrumSignalParameters");

BleSpectrumSignalParameters::BleSpectrumSignalParameters (void)
{
  NS_LOG_FUNCTION (this);
}

BleSpectrumSignalParameters::~BleSpectrumSignalParameters (void)
{
  NS_LOG_FUNCTION (this);
}

BleSpectrumSignalParameters::BleSpectrumSignalParameters (const BleSpectrumSignalParameters& p)
  : SpectrumSignalParameters (p)
{
  NS_LOG_FUNCTION (this << &p);
  packet = p.packet->Copy ();
}

Ptr<SpectrumSignalParameters>
BleSpectrumSignalParameters::Copy (void)
{
  NS_LOG_FUNCTION (this);
  return Create<BleSpectrumSignalParameters> (*this);
}

} // namespace ns3
