/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/log.h>
#include <ns3/pointer.h>
#include <ns3/abort.h>

#include <ns3/spectrum-channel.h>

#include <ns3/ble-netdevice.h>
#include <ns3/ble-phy.h>
namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleNetDevice");
NS_OBJECT_ENSURE_REGISTERED (BleNetDevice);

TypeId
BleNetDevice::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BleNetDevice")
    .SetParent<NetDevice> ()
    .SetGroupName ("Ble")
    .AddConstructor<BleNetDevice> ()
    .AddAttribute ("Channel", "The channel attached to this device",
                   PointerValue (),
                   MakePointerAccessor (&BleNetDevice::DoGetChannel),
                   MakePointerChecker<SpectrumChannel> ())
    .AddAttribute ("Phy", "The PHY layer attached to this device.",
                   PointerValue(),
                   MakePointerAccessor (&BleNetDevice::GetPhy,
                                        &BleNetDevice::SetPhy),
                   MakePointerChecker<BlePhy> ())
    .AddAttribute ("LinkLayer", "The Link Layer attached to this device",
                   PointerValue(),
                   MakePointerAccessor (&BleNetDevice::GetLinkLayer,
                                        &BleNetDevice::SetLinkLayer),
                   MakePointerChecker<BleLinkLayer> ())
  ;
  return tid;
}

BleNetDevice::BleNetDevice()
{
  NS_LOG_FUNCTION (this);
  m_completeConfig = false;
}

BleNetDevice::~BleNetDevice ()
{
  NS_LOG_FUNCTION (this);
}

void
BleNetDevice::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  m_linkLayer->Dispose ();
  m_phy->Dispose ();
  m_phy = 0;
  m_linkLayer = 0;
  m_node = 0;
  NetDevice::DoDispose ();
}

void
BleNetDevice::DoInitialize (void)
{
  NS_LOG_FUNCTION (this);
  m_phy->Initialize ();
  m_linkLayer->Initialize ();
  NetDevice::DoInitialize ();
}

void
BleNetDevice::CompleteConfig (void)
{
  NS_LOG_FUNCTION (this);
  if (m_phy == 0
      || m_linkLayer == 0
      || m_node == 0
      || m_completeConfig)
    {
      return;
    }
  m_linkLayer->SetPhy (m_phy);

  Ptr<MobilityModel> mobility = m_node->GetObject<MobilityModel> ();
  if (!mobility)
    {
      NS_LOG_WARN ("BleNetDeviceL no Mobility found on the node, probably it's not a good idea.");
    }
  m_phy->SetMobility (mobility);
  m_phy->SetDevice (this);

  m_completeConfig = true;
}

void
BleNetDevice::SetLinkLayer (Ptr<BleLinkLayer> ll)
{
  NS_LOG_FUNCTION (this);
  m_linkLayer = ll;
}

Ptr<BleLinkLayer>
BleNetDevice::GetLinkLayer (void) const
{
  NS_LOG_FUNCTION (this);
  return m_linkLayer;
}

void
BleNetDevice::SetPhy (Ptr<BlePhy> phy)
{
  NS_LOG_FUNCTION (this);
  m_phy = phy;
}

Ptr<BlePhy>
BleNetDevice::GetPhy (void) const
{
  NS_LOG_FUNCTION (this);
  return m_phy;
}

void
BleNetDevice::SetChannel (Ptr<SpectrumChannel> channel)
{
  NS_LOG_FUNCTION (this << channel);
  m_phy->SetChannel (channel);
}

void
BleNetDevice::SetIfIndex (const uint32_t index)
{
  NS_LOG_FUNCTION (this << index);
  m_ifIndex = index;
}

uint32_t
BleNetDevice::GetIfIndex (void) const
{
  NS_LOG_FUNCTION (this);
  return m_ifIndex;
}

Ptr<Channel>
BleNetDevice::GetChannel (void) const
{
  NS_LOG_FUNCTION (this);
  return m_phy->GetChannel ();
}

Ptr<SpectrumChannel>
BleNetDevice::DoGetChannel (void) const
{
  NS_LOG_FUNCTION (this);
  return m_phy->GetChannel ();
}

Ptr<Node>
BleNetDevice::GetNode (void) const
{
  NS_LOG_FUNCTION (this);
  return m_node;
}

void
BleNetDevice::SetNode (Ptr<Node> node)
{
  NS_LOG_FUNCTION (this);
  m_node = node;
}

void
BleNetDevice::SetMacAddress (Mac48Address address)
{
  NS_LOG_FUNCTION (this);
  m_macAddr = address;
  m_linkLayer->SetMacAddress (address);
  m_addr = static_cast<Address> (address);
}

Mac48Address
BleNetDevice::GetMacAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_macAddr;
}

void
BleNetDevice::SetAddress (Address address)
{
  NS_LOG_FUNCTION (this);
  m_addr = address;
}

Address
BleNetDevice::GetAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_addr;
}

bool
BleNetDevice::SetMtu (const uint16_t mtu)
{
  NS_ABORT_MSG ("Can not set maximum payload size: It is 37");
  return false;
}

uint16_t
BleNetDevice::GetMtu (void) const
{
  NS_LOG_FUNCTION (this);
  return 37; // 37 bytes is maximum payload. With this 10 bytes added as header and trailer.
}

bool
BleNetDevice::IsLinkUp (void) const
{
  NS_LOG_FUNCTION (this);
  return m_phy !=0 && m_linkUp;
}

void
BleNetDevice::AddLinkChangeCallback (Callback<void> callback)
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
}

bool
BleNetDevice::IsBroadcast (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
}

Address
BleNetDevice::GetBroadcast (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
  return m_addr; // Fake return
}

bool
BleNetDevice::IsMulticast (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
}

Address
BleNetDevice::GetMulticast (Ipv4Address multicastGroup) const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
  return m_addr; // Fake return
}

Address
BleNetDevice::GetMulticast (Ipv6Address addr) const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
  return m_addr; // Fake return
}

bool
BleNetDevice::IsBridge (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
  return false;
}

bool
BleNetDevice::IsPointToPoint (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
  return false;
}

bool
BleNetDevice::Send (Ptr<Packet> packet, const Address& dest, uint16_t protocolNumber)
{
  NS_LOG_FUNCTION (this);
  // TODO: Redirect packet to LinkLayer once it is implemented
  return false;
}

bool
BleNetDevice::SendFrom (Ptr<Packet> packet, const Address& source, const Address& dest, uint16_t protocolNumber)
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
  return false;
}

bool
BleNetDevice::NeedsArp (void)  const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Irrelavant call");
  return false;
}

void
BleNetDevice::SetReceiveCallback (NetDevice::ReceiveCallback cb)
{
  NS_LOG_FUNCTION (this);
  // Do nothing. This is never used.
}

void
BleNetDevice::SetPromiscReceiveCallback (PromiscReceiveCallback cb)
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Use BleLinkLayer API instead");
}

bool
BleNetDevice::SupportsSendFrom (void) const
{
  NS_LOG_FUNCTION (this);
  return false;
}


} // namespace ns3
