/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <iomanip>
#include <iostream>
#include <cstring>

#include <ns3/log.h>
#include <ns3/assert.h>

#include <ns3/address.h>

#include "ble-access-address.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleAccessAddress");

ATTRIBUTE_HELPER_CPP (BleAccessAddress);

#define ASCII_a (0x41)
#define ASCII_z (0x5a)
#define ASCII_A (0x61)
#define ASCII_Z (0x7a)
#define ASCII_COLON (0x3a)
#define ASCII_ZERO (0x30)


/**
 * Converts a char to lower case.
 * \param c the char
 * \returns the lower case
 */
static char
AsciiToLowCase (char c)
{
  if (c >= ASCII_a && c <= ASCII_z) {
      return c;
    } else if (c >= ASCII_A && c <= ASCII_Z) {
      return c + (ASCII_a - ASCII_A);
    } else {
      return c;
    }
}

Ptr<UniformRandomVariable> BleAccessAddress::m_random = CreateObject<UniformRandomVariable> ();

BleAccessAddress::BleAccessAddress ()
{
  NS_LOG_FUNCTION (this);
  memset (m_address, 0, 2);
}

BleAccessAddress::BleAccessAddress (const char *str)
{
  NS_LOG_FUNCTION (this << str);
  int i = 0;
  while (*str != 0 && i < 4)
    {
      uint8_t byte = 0;
      while (*str != ASCII_COLON && *str != 0)
        {
          byte <<= 4;
          char low = AsciiToLowCase (*str);
          if (low >= ASCII_a)
            {
              byte |= low - ASCII_a + 10;
            }
          else
            {
              byte |= low - ASCII_ZERO;
            }
          str++;
        }
      m_address[i] = byte;
      i++;
      if (*str == 0)
        {
          break;
        }
      str++;
    }
  NS_ASSERT (i==4);
}

void
BleAccessAddress::CopyFrom (const uint8_t buffer[4])
{
  NS_LOG_FUNCTION (this << &buffer);
  memcpy (m_address, buffer, 4);
}

void
BleAccessAddress::CopyTo (uint8_t buffer[4]) const
{
  NS_LOG_FUNCTION (this << &buffer);
  memcpy (buffer, m_address, 4);
}

bool
BleAccessAddress::IsMatchingType (const Address &address)
{
  NS_LOG_FUNCTION (&address);
  return address.CheckCompatible (GetType (), 4); //Check this number
}

BleAccessAddress::operator Address () const
{
  return ConvertTo ();
}

BleAccessAddress
BleAccessAddress::ConvertFrom (const Address &address)
{
  NS_LOG_FUNCTION (address);
  NS_ASSERT (IsMatchingType (address));
  BleAccessAddress retval;
  address.CopyTo (retval.m_address);
  return retval;
}

Address
BleAccessAddress::ConvertTo (void) const
{
  NS_LOG_FUNCTION (this);
  return Address (GetType(), m_address, 4);
}

BleAccessAddress
BleAccessAddress::Allocate (void)
{
  NS_LOG_FUNCTION_NOARGS ();
  // TODO: Check whether the address is appropriate or not.
  // Spec Reference: 2.1.2
  uint32_t id = (m_random->GetValue (0.0,pow(2,32)));
  while (id == 0)
    {
      id = (m_random->GetValue (0.0,pow(2,32)));
    }
  BleAccessAddress address;
  address.m_address[0] = (id >> 24) & 0xff;
  address.m_address[1] = (id >> 16) & 0xff;
  address.m_address[2] = (id >> 8) & 0xff;
  address.m_address[3] = (id >> 0) & 0xff;
  return address;
}

uint8_t
BleAccessAddress::GetType (void)
{
  NS_LOG_FUNCTION_NOARGS ();
  static uint8_t type = Address::Register ();
  return type;
}

std::ostream & operator<< (std::ostream& os, const BleAccessAddress & address)
{
  uint8_t ad[4];
  address.CopyTo (ad);

  os.setf (std::ios::hex, std::ios::basefield);
  os.fill ('0');

  for (uint8_t i = 0; i < 3; i++)
    {
      os << std::setw (2) << (uint32_t)ad[i] << ":";
    }
  //Final byte not suffixed by ":"
  os << std::setw (2) << (uint32_t)ad[3];
  os.setf (std::ios::dec, std::ios::basefield);
  os.fill (' ');
  return os;
}

std::istream& operator>> (std::istream& is, BleAccessAddress & address)
{
  std::string v;
  is >> v;

  std::string::size_type col = 0;
  for (uint8_t i = 0; i < 4; ++i)
    {
      std::string tmp;
      std::string::size_type next;
      next = v.find (":", col);
      if (next == std::string::npos)
        {
          tmp = v.substr (col, v.size ()-col);
          address.m_address[i] = strtoul (tmp.c_str(), 0, 16);
          break;
        }
      else
        {
          tmp = v.substr (col, next-col);
          address.m_address[i] = strtoul (tmp.c_str(), 0, 16);
          col = next + 1;
        }
    }
  return is;
}

} // namespace ns3
