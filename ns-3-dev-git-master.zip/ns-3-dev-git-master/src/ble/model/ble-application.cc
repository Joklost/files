/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/ble-linklayer.h>
#include <ns3/ble-application.h>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleApplication");

TypeId
BleApplication::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BleApplication")
    .SetParent<Application> ()
    .SetGroupName ("Ble")
    .AddAttribute ("AppStartTime", "Time at which the application will start",
                   TimeValue (Seconds (0.0)),
                   MakeTimeAccessor (&BleApplication::m_startTime),
                   MakeTimeChecker ())
    ;
  return tid;
}

BleApplication::BleApplication (void)
{
  NS_LOG_FUNCTION (this);
}

BleApplication::~BleApplication (void)
{
  NS_LOG_FUNCTION (this);
}

void
BleApplication::SetConnString (char data[100])
{
  NS_LOG_FUNCTION (this);
  for (int i = 0; i < 100; i++)
    m_connData[i] = data[i];
}

void
BleApplication::SetAdvString (char data[31])
{
  NS_LOG_FUNCTION (this);
  for (int i = 0; i < 31; i++)
    m_advData[i] = data[i];
}

void
BleApplication::SetLinkLayer (Ptr<BleLinkLayer> ll)
{
  NS_LOG_FUNCTION (this);
  m_linkLayer = ll;
  m_linkLayer -> TraceConnectWithoutContext ("LinkLayerTxToL2cap", MakeCallback (&BleApplication::RxFromLinkLayer, this));
}

Ptr<BleLinkLayer>
BleApplication::GetLinkLayer (void) const
{
  NS_LOG_FUNCTION (this);
  return m_linkLayer;
}

void
BleApplication::ChangeState (BleApplicationState newval)
{
  NS_LOG_FUNCTION (this);
  m_state = newval;
}

void
BleApplication::SetStartTime (Time start)
{
  NS_LOG_FUNCTION (this << start);
  m_startTime = start;
  m_startEvent = Simulator::Schedule (m_startTime, &BleApplication::StartApplication, this);
}

void
BleApplication::RxFromLinkLayer (Ptr<Packet> p, uint8_t int1, uint8_t int2)
{
  NS_LOG_FUNCTION (this);
  if (m_state == SCANNING)
    {
      // int1 = 0 = COnnection not allowed
      // int1 = 1 = Connection Allowed
      // int1 = 2 = Connection Compulsory or simply drop
      uint8_t connectionLevel = int1;
      // int2 = 0 = Scan Req not allowed
      // int2 = 1 = Scan Req allowed
      uint8_t scanLevel = int2;

      NS_LOG_DEBUG (this << " " << Simulator::Now ().GetMicroSeconds () << "us" << " " << "Packet #" << p->GetUid () << " Received. With CONN Request permission = " << (int)int1 << " and SCAN Request permission = " << (int)int2);
      // If available connect
      if (connectionLevel != 0)
        {
          m_state = CONNECTION_MASTER;
          NS_LOG_DEBUG (this<< " " << Simulator::Now ().GetMicroSeconds () << "us "<< "Application set as CONNECTION_MASTER");
          m_linkLayer -> SetAdvMode (BleLinkLayer::CONN_REQ);
          Simulator::ScheduleNow (&BleLinkLayer::CreateConnection, m_linkLayer);
          Simulator::Schedule (Time("1.25ms")+m_linkLayer->GetTxWindowOffset (), &BleApplication::SendRequestPacket, this, true);
          return;
        }
      else if (scanLevel != 0)
        {
          Ptr<Packet> returnPacket;
          uint8_t data[p->GetSize ()];
          p->CopyData (data, p->GetSize ());
          uint8_t first = data[0];
          uint8_t i;
          for (i = 0; i < p->GetSize ()-1; i++)
            data[i+1] = data[i];
          data[i] = first;
          returnPacket = Create<Packet> (data, p->GetSize ());
          m_linkLayer->SetAdvMode (BleLinkLayer::SCANNER_REQ);
          m_linkLayer->RxFromL2cap (returnPacket);
          Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
          Simulator::Schedule (Time("150us"), &BleLinkLayer::BleLLChangeState, m_linkLayer, BleLinkLayer::LL_ADV_RX_ON);
        }
    }
  else if (m_state == ADVERTISE)
    {
      // int1 = 0 = No connection from Advertiser side
      // int2 = 0 = Connection Request received
      // int2 = 1 = Scan Request Received
      uint8_t isScanRq = int2;
      if (isScanRq)
        {
          Ptr<Packet> returnPacket = Create<Packet> (m_advData, 31);
          m_linkLayer->SetAdvMode (BleLinkLayer::SCANNER_RESP);
          m_linkLayer->RxFromL2cap (returnPacket);
          Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
        }
      else
        {
          m_state = CONNECTION_SLAVE;
          NS_LOG_DEBUG (this<< " " << Simulator::Now ().GetMicroSeconds () << "us "<< "Application set as CONNECTION_SLAVE");
          m_linkLayer->SetRole (BleLinkLayer::CONN_SLAVE);
          Simulator::Schedule (Time("150us"), &BleLinkLayer::BleLLChangeState, m_linkLayer, BleLinkLayer::LL_CONN_RX_ON);
        }
      return;
    }
  if (m_state == CONNECTION_MASTER)
    {
      // int1 == int2 == 1 = Connection Closed
      // int1 = 1 and int2 = 0 = ConnectionEvent Restart
      if (int1 == int2 && int1 == 1)
        {
          m_state = SCANNING;
          return;
        }

      if (int1 == 1 && int2 == 0)
        {
          SendRequestPacket (false);
          return;
        }
      NS_LOG_DEBUG (this << " "
                    << Simulator::Now ().GetMicroSeconds () << "us "
                    << "Data Packet #" << p->GetUid () << " Received by Master.");

      uint8_t data[p->GetSize ()];
      p->CopyData (data, p->GetSize ());
      uint8_t i;
      for (i = 0; i < p->GetSize (); i++)
        std::cout << (char)data[i];
      std::cout<<std::endl;
      Ptr<Packet> returnPacket = Create<Packet> ();
      m_linkLayer->RxFromL2cap (returnPacket);
      Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
    }
  if (m_state == CONNECTION_SLAVE)
    {
      // int1 == int2 == 1 = Connection Closed
      if (int1 == int2 && int1 == 1)
        {
          m_state = ADVERTISE;
          return;
        }
      NS_LOG_DEBUG (this << " "
                    << Simulator::Now ().GetMicroSeconds () << "us "
                    << "Data Packet #" << p->GetUid () << " Received by Slave.");
      Ptr<Packet> returnPacket = CreateResponsePacket (p);
      m_linkLayer->RxFromL2cap (returnPacket);
      Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
    }
}

void
BleApplication::SendRequestPacket (bool isFirstRequest)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_state == CONNECTION_MASTER);

  m_pkt = Create<Packet> (m_connData, 100);

  if (isFirstRequest)
    m_linkLayer->GetPhy ()->SetChannelNo (m_linkLayer->GetInitChannelNo ());

  m_linkLayer->RxFromL2cap (m_pkt);
  Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
}

Ptr<Packet>
BleApplication::CreateResponsePacket (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);
  uint32_t size = p->GetSize ();

  uint8_t data[size];
  uint8_t new_data[size];

  p->CopyData (data, size);

  new_data[0] = data[size];
  for (uint8_t i = 0; i < size-1; i++)
    new_data[i+1] = data[i];

  Ptr<Packet> returnPacket = Create<Packet> (new_data, size);

  return returnPacket;
}

void
BleApplication::StartApplication (void)
{
  NS_LOG_FUNCTION (this);
  if (m_state == ADVERTISE)
    {
      m_pkt = Create<Packet> (m_advData, 31);
      m_linkLayer->RxFromL2cap (m_pkt);
      m_linkLayer->SetRole (BleLinkLayer::ADVERTISER);
      Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
    }
  else if (m_state == SCANNING)
    {
      m_linkLayer->BleLLChangeState (BleLinkLayer::LL_ADV_RX_ON);
    }
}

void
BleApplication::DoInitialize (void)
{
  NS_LOG_FUNCTION (this);
  m_startEvent = Simulator::Schedule (m_startTime, &BleApplication::StartApplication, this);
  Object::DoInitialize ();
}

void
BleApplication::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  m_node = 0;
  m_linkLayer = 0;
  m_startEvent.Cancel ();
  m_stopEvent.Cancel ();
  Object::DoDispose ();
}

} // namespace ns3
