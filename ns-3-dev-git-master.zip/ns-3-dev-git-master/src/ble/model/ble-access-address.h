/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_ADDRESS_H
#define BLE_ADDRESS_H

#include <stdint.h>
#include <ostream>
#include <cstring>

#include <ns3/core-module.h>
#include <ns3/address.h>

namespace ns3 {

/**
 * \ingroup address
 *
 * This class can contain 32 bit access addresses for BLE Devices
 *
 */
class BleAccessAddress
{
public:
  BleAccessAddress ();
  /*
   * \param str a string represnting the new BLE Access Address
   *
   */
  BleAccessAddress (const char *str);

  /*
   * \param buffer address in network order
   *
   * Copy the input address to our internal buffer.
   */
  void CopyFrom (const uint8_t buffer[4]);

  /*
   * \param buffer address in network order
   *
   * Copy the internal address to the input buffer.
   */
  void CopyTo (uint8_t buffer[4]) const;

  /*
   * \returns a new Address instance
   *
   * Convert an instance of this class to a polymorphic Address instance.
   */
  operator Address () const;

  /**
   * \param address  a polymorphic address
   * \returns a new BleAccessAddress from the polymorphic address
   *
   * This function performs a type check and asserts if the
   * type of the input address is not compatible with an BLE Access
   * Address.
   */
  static BleAccessAddress ConvertFrom (const Address &address);
  /**
   * \param address address to test
   * \return true if the address matches, false otherwise
   */
  static bool IsMatchingType (const Address &address);
  /**
   * Allocate a new BleAccessAddress
   * \returns newly allocated BleAccessAddress
   */
  static BleAccessAddress Allocate (void);

private:
  /*
   * random stream Access Address. Will be used in allocation
   */
  static Ptr<UniformRandomVariable> m_random;

  /*
   * \returns a new Address instance
   *
   * Convert an instance of this class to a polymorphic Address instance.
   */
  Address ConvertTo (void) const;

  /*
   * \brief Return the Type of address
   * \return type of address
   */
  static uint8_t GetType (void);

  /**
   * \brief Equal to operator.
   *
   * \param a the first operand
   * \param b the first operand
   * \returns true if the operands are equal
   */
  friend bool operator == (const BleAccessAddress &a, const BleAccessAddress &b);

  /**
   * \brief Not equal to operator.
   *
   * \param a the first operand
   * \param b the first operand
   * \returns true if the operands are not equal
   */
  friend bool operator != (const BleAccessAddress &a, const BleAccessAddress &b);

  /**
   * \brief Less than operator.
   *
   * \param a the first operand
   * \param b the first operand
   * \returns true if the operand a is less than operand b
   */
  friend bool operator < (const BleAccessAddress &a, const BleAccessAddress &b);

  /**
   * \brief Stream insertion operator.
   *
   * \param os the stream
   * \param address the address
   * \returns a reference to the stream
   */
  friend std::ostream& operator<< (std::ostream& os, const BleAccessAddress & address);

  /**
   * \brief Stream extraction operator.
   *
   * \param is the stream
   * \param address the address
   * \returns a reference to the stream
   */
  friend std::istream& operator>> (std::istream& is, BleAccessAddress & address);

  uint8_t m_address[4]; //!< address value
};

ATTRIBUTE_HELPER_HEADER (BleAccessAddress);

inline bool operator == (const BleAccessAddress &a, const BleAccessAddress &b)
{
  return memcmp (a.m_address, b.m_address, 4) == 0;
}
inline bool operator != (const BleAccessAddress &a, const BleAccessAddress &b)
{
  return memcmp (a.m_address, b.m_address, 4) != 0;
}
inline bool operator < (const BleAccessAddress &a, const BleAccessAddress &b)
{
  return memcmp (a.m_address, b.m_address, 4) < 0;
}

std::ostream& operator<< (std::ostream& os, const BleAccessAddress & address);
std::istream& operator>> (std::istream& is, BleAccessAddress & address);

} // namespace ns3

#endif
