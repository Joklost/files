/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_LINKLAYER_H
#define BLE_LINKLAYER_H

#include <queue>

#include <ns3/core-module.h>
#include <ns3/traced-callback.h>
#include <ns3/traced-value.h>
#include <ns3/ptr.h>

#include <ns3/packet.h>
#include <ns3/mac48-address.h>

#include "ns3/ble-phy.h"
#include "ns3/ble-access-address.h"
#include "ns3/ble-linklayer-trailer.h"
#include "ns3/ble-linklayer-header.h"

namespace ns3 {

/**
 * \ingroup ble
 *
 * \brief Implementation of LinkLayer of BLE protocol
 */
class BleLinkLayer : public Object
{
public:

typedef enum {
  CENTRAL,
  PERIPHERAL
} BleLinkLayerDeviceTypes;

typedef enum {
  STANDBY,
  ADVERTISER,
  SCANNER_ACT,
  SCANNER_PASS,
  CONN_MASTER,
  CONN_SLAVE,
} BleLinkLayerRole;

typedef enum {
  GENERAL_ADV,
  DIRECT_ADV,
  NON_CONN_ADV,
  DISC_ADV,
  SCANNER_RESP, // Incase of SCANNER_ACT
  SCANNER_REQ, // Incase of SCANNER_ACT
  CONN_REQ // When device sent CONN_REQ Pkt
} BleAdvMode;

typedef enum {
  LL_IDLE,
  LL_ADV_TX_ON,
  LL_ADV_RX_ON,
  LL_CONN_RX_ON,
  LL_CONN_TX_ON,
} BleLLState;

typedef enum {
  LL_CONNECTION_UPDATE_REQ = 0x00,
  LL_CHANNEL_MAP_REQ =       0x01,
  LL_TERMINATE_IND =         0x02,
  LL_ENC_REQ =               0x03,
  LL_ENC_RSP =               0x04,
  LL_START_ENC_REQ =         0x05,
  LL_START_ENC_RSP =         0x06,
  LL_UNKNOWN_RSP =           0x07,
  LL_FEATURE_REQ =           0x08,
  LL_FEATURE_RSP =           0x09,
  LL_PAUSE_ENC_REQ =         0x0A,
  LL_PAUSE_ENC_RSP =         0x0B,
  LL_VERSION_IND =           0x0C,
  LL_REJECT_IND =            0x0D,
  LL_SLAVE_FEATURE_REQ =     0x0E,
  LL_CONNECTION_PARAM_REQ =  0x0F,
  LL_CONNECTION_PARAM_RSP =  0x10,
  LL_REJECT_IND_EXT =        0x11,
  LL_PING_REQ =              0x12,
  LL_PING_RSP =              0x13,
  LL_LENGTH_REQ =            0x14,
  LL_LENGTH_RSP =            0x15
} BLE_LL_CONTROL_PDU;

public:
  /**
   * Get the type ID.
   *
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);
  /**
   * Default Constructor
   */
  BleLinkLayer (void);
  BleLinkLayer (BleLinkLayerDeviceTypes type);
  virtual ~BleLinkLayer (void);

  /**
   * Get Device Type
   */
  BleLinkLayerDeviceTypes GetDeviceType (void) const;
  /**
   * Set Address
   * \param addr Mac48Address
   */
  void SetMacAddress (Mac48Address addr);
  /**
   * Get Address
   * \return Mac48Address
   */
  Mac48Address GetMacAddress (void) const;
  /**
   * Change BLE LL Role
   * \param r Type BleLinkLayerRole
   */
  void SetRole (BleLinkLayerRole r);
  /**
   * Change BLE LL State
   * \param s Type BleLLState
   */
  void BleLLChangeState (BleLLState s);

  /**
   * Set PHY Layer
   * \param phy Pointer to BlePhy
   */
  void SetPhy (Ptr<BlePhy> p);

  /**
   * Get PHY Layer
   * \return Pointer to PHY connected to LL
   */
  Ptr<BlePhy> GetPhy (void) const;
  /**
   * Set Random Adv Channel
   */
  void SetAdvChannelNo (Ptr<Packet const> p);

  /**
   * Set Rx Device Address -- Used in Direct Adv
   * \param addr Mac48Address instance
   */
  void SetRxDeviceAddress (Mac48Address addr);
  /**
   * Get Rx Device Addr -- Used in Direct Adv
   * \return Mac48Address instance of device address
   */
  Mac48Address GetRxDeviceAddress (void) const;


  // Whole Connection Process Starts
  /*
   * \brief Packet received from L2CAP Layer
   * Packet will be either Data or management packet.
   * If it is Data packet then fragment if needed.
   * //TODO: If management packet then call appropriate Set method to set the parameter.
   *
   * \param p Pointer to packet
   */
  void RxFromL2cap (Ptr<Packet> p);
  /*
   * \brief Start connection event at every interval
   * Scheduled call by EventId m_connEvent
   * \param Whether the event is first event or not
   */
  void StartConnectionEvent (void);
  /*
   * \brief Create connection packet from Master to Slave. Use TxToPhy to send
   */
  void CreateConnection (void);
  /*
   * \brief Parse connection packet rx from Master to Slave. Set the parameters
   * \param p Pointer to rxPacket
   */
  void ParseConnectionRequestPkt (Ptr<Packet> p);
  /*
   * \brief Stop connection event in a particular interval when other device stops responding
   * Scheduled call by EventId m_stopConnEvent
   */
  void StopConnectionEvent (void);

  /*
   * \brief Create and send a management packet to Slave. Use TxToPhy to send
   * \TODO: Not Implemented.
   * \param param Parameter that was changed
   */
  void CreateManagementPacket (std::string param);
  /*
   * \brief Send packet to PHY Layer.
   * Get m_txPkt. Add Header/Trailer. Pass on to PhyLayer. Assert PHY in IDLE.
   */
  void TxToPhy (void);
  /*
   * \brief Receive packet from PHY
   * Tasks: Check CRC. Get Header. Parse Data.V
   * Check Address if whitelist. Throw if not in whitelist.
   * Parse Header: Send packet to upper layer.
   *
   * \param p Pointer to Packet
   * \param channelNo Channel number on which the packet was received
   */
  void RxFromPhy (Ptr<Packet> p, uint8_t channelNo);
  /*
   * \brief Send recombined packet to L2CAP Layer.
   * \param Pointer to Packet
   */
  void TxToL2cap (Ptr<Packet> p, uint8_t int1, uint8_t int2);
  /**
   * \brief Create and send Scan Request
   */
  void SendScanRequest (void);

  /*
   * On Adv Events: To restart listening at another Advertising Event after going into IDLE.
   */
  void BleNoPacketTimeout (void);

  /*
   * On Adv Events: If no connection request received in AdvInterval time, this function is called
   */
  void BleConnReqTimeout (void);

  /*
   * On CONN Events: If no packet received in 1ms time, this function is called by MASTER or SLAVE.
   */
  void BleNoAckTimeout (void);

  /**
   * Send close connection packet
   * \param init Whether Initializer or not
   * \param reason Whether the reason was SupervisionTimeout or not
   */
  void CloseConnection (bool init, bool reason);
  /**
   * Close connection procedure after receiving ACK
   * \param reason Whether the reason was SupervisionTimeout or not
   */
  void CloseConnectionAck (bool reason);
  // Whole Connection Process Ends

  // Following are Functions to manage LinkLayer Parameters
  /*
   * \brief Enable WhiteList
   * Sets m_isWhiteList to True
   */
  void EnableWhiteList (void);
  /*
   * \brief Disable WhiteList
   * Sets m_isWhiteList to Fal
   */
  void DisableWhiteList (void);
  /*
   * \brief Add address in WhiteList
   * WARNING: If m_isWhiteList not enabled
   * \param addr Mac48Address which will be added in WhiteList
   */
  void AddWhiteList (Mac48Address addr);
  /*
   * \brief Remove address from WhiteList
   * WARNING: If m_isWhiteList not enabled
   * \param addr MAC48Address which will be removed
   * \return true if successful. false if unsuccessful
   */
  bool RemoveWhiteList (Mac48Address addr);
  /*
   * \brief If addr in WhiteList
   * \param addr MAC48Address which will be checked from container
   * \return true if Address in Container. Returns true if WhiteList not enabled.
   */
  bool CheckWhiteList (Mac48Address addr);
  /*
   * \brief Whether white list is enabled or not.
   * \return true if WhiteList is enabled
   */
  bool IsWhiteListEnabled (void);

  /*
   * \brief Get Advertising Listen Window
   * \return Advertising Listen Window
   */
  Time GetAdvListenWindow (void) const;
  /*
   * \brief Set Advertising Listen Window
   * \param advListenInt Advertising Window Time instance
   */
  void SetAdvListenWindow (Time advInt);
  /*
   * \brief Get Advertising Interval
   * \return Advertising Interval
   */
  Time GetAdvInterval (void) const;
  /*
   * \brief Set Advertising Interval
   * \param advInt Advertising Interval Time instance
   */
  void SetAdvInterval (Time advInt);

  /**
   * \brief Set Advertising Mode
   * \param m BleAdvMode type
   */
  void SetAdvMode (BleAdvMode m);
  /**
   * \brief Get Advertising Mode
   * \return Advertisement Mode
   */
  BleAdvMode GetAdvMode (void) const;

  /**
   * \brief Set ConnAddress
   * \param addr Mac48Address instance
   */
  void SetConnAddress (Mac48Address addr);

  /**
   * \bried Get Conencted Address
   * \return Mac48Address instance
   */
  Mac48Address GetConnAddress (void) const;

  /**
   * \brief Set Access Address
   * \param addr BleAccessAddress instance
   */
  void SetAccessAddress (BleAccessAddress addr);
  /**
   * \bried Get Access Address
   * \return BleAccessAddress instance
   */
  BleAccessAddress GetAccessAddress (void) const;

  /**
   * \brief Set CRC Initialisation Value
   * \param crcInit 24-bit Integer
   */
  void SetCrcInit (uint32_t crcInit);
  /**
   * \brief Get CRC Initialisation Value
   * \return 24-bit CRC Initialisation Value
   */
  uint32_t GetCrcInit (void) const;

  /**
   * \brief initial channel no
   * \return Channel no 0-36
   */
  uint8_t GetInitChannelNo (void) const;
  /**
   * \brief Set Transmission Window Size
   * \param t Windows size (Time Instance)
   * TxWindowSize will be t*1.25ms
   */
  void SetTxWindowSize (uint8_t t);
  /**
   * \brief Get Transmission Window Size
   * \return Transmission Window Size
   */
  Time GetTxWindowSize (void) const;

  /**
   * \brief Set Transmission Window Offset
   * \param t Window Offset
   * TxWindowOffset will be t*1.25ms
   */
  void SetTxWindowOffset (uint16_t t);
  /**
   * \brief Get Transmission windo offset
   * \return Transmission Window Offset
   */
  Time GetTxWindowOffset (void) const;

  /**
   * \brief Get Connection Interval
   * \return Time instance of Connection Interval
   */
  Time GetConnectionInterval (void) const;
  /**
   * \brief Set Connection Interval
   * \param t Connection Interval
   * ConnectionInterval will be t*1.25ms
   */
  void SetConnectionInterval (uint16_t t);

  /**
   * \brief Set Slace Latency
   * \param sl Slave Latency
   */
  void SetSlaveLatency (uint16_t sl);
  /**
   * \brief Get Slave Latency
   * \return Slave Latency
   */
  uint32_t GetSlaveLatency (void) const;

  /**
   * \brief Get Supervision Timeout
   * \return Supervison Timeout
   */
  Time GetSupervisionTimeout (void) const;
  /**
   * \brief Set Supervision Timeout
   * \param t Supervision Timeout
   */
  void SetSupervisionTimeout (uint16_t t);

  /**
   * \brief Frequency Hop increment at every connection
   * \param hop Hop value
   */
  void SetFreqHop (uint8_t hop);
  /**
   * \brief Get Frequency Hop increment
   * \return hop
   */
  uint8_t GetFreqHop (void) const;

  /**
   * Set LinkLayerId
   * \param id BleLinkLayerId
   */
  void SetLinkLayerId (BleLinkLayerHeader::LinkLayerId id);

  /*
   * Set Next Sequence No
   * \param nesn true for 1 and false for 0
   */
  void SetNextSequenceNo (bool nesn);
  /*
   * Get Next Sequence No
   * \return true for 1 and false for 0
   */
  bool GetNextSequenceNo (void) const;
  /*
   * Set Sequence No
   * \param sn true for 1 and false for 0
   */
  void SetSequenceNo (bool sn);
  /*
   * Get Sequence No
   * \return true for 1 and false for 0
   */
  bool GetSequenceNo (void) const;
  /*
   * Set More Data bit
   * \param md true for 1 and false for 0
   */
  void SetMoreData (bool md);
  /*
   * Get More Data bit
   * \return true for 1 and false for 0
   */
  bool GetMoreData (void) const;

private:
  /**
   * Connected PHY
   */
  Ptr<BlePhy> m_phy;
  /*
   * Mac Address
   */
  Mac48Address m_addr;
  /*
   * Device Type: Central or Peripheral
   */
  const BleLinkLayerDeviceTypes m_deviceType;
  /*
   * Current role
   */
  TracedValue<BleLinkLayerRole> m_role;
  /*
   * Maximum Buffer size for m_rxPktBuffer and m_txPktBuffer. Default value 1 MB
   */
  uint32_t m_maxBufferSize;

  // Parameters for Advertising
  /*
   * Advertising Interval
   */
  Time m_advInterval;
  /*
   * Advertising Listen Window
   */
  Time m_advListenWindow;
  /**
   * Advertising Mode
   */
  BleAdvMode m_advMode;
  /**
   * Keep track of previous Advertising Mode
   */
  BleAdvMode m_prevAdvMode;
  /*
   * Device Address for Receving Device -- Assuming 48 bit MAC Address. Used for DIRECT Advertising
   */
  Mac48Address m_rxDeviceAddr;

  // Parameters for Connection
  /*
   * Is Connected?
   */
  bool m_isConnected;
  /*
   * Is WhiteList Enabled?
   */
  bool m_isWhiteList;
  /**
   * Connected Address
   * MAC Address of device to which this is connected to in case of CONN
   * MAC Address of device to which the SCAN Req is to be sent or was sent.
   */
  Mac48Address m_connAddr;
  /*
   * WhiteList of Device addresses
   */
  std::vector<Mac48Address > m_whiteLists;
  /*
   * Access Address to be used in Connection
   */
  BleAccessAddress m_accessAddr;
  /*
   * CRC Initial value. Set Randomly by Master Link Layer. Set by Slave Link layer on notification
   */
  uint32_t m_crcInitVal;
  /*
   * Tx Window Size
   */
  Time m_txWindowSize;
  /*
   * Tx Window Offset
   */
  Time m_txWindowOffset;
  /*
   * Connection Interval
   */
  Time m_connInterval;
  /*
   * No. of conenction intervals without listening Master
   * Slave must listen at least once every m_slaveLatency connection event.
   */
  uint32_t m_unlistenedConnEvent;

  /*
   * Slave Latency
   */
  uint16_t m_slaveLatency;
  /*
   * Current Supervision Timeout
   */
  Time m_supervisionTimeout;
  /*
   * Expected Supervision Timeout in connection. Will be changed to m_supervisionTimeout after one ACK from Slave
   */
  Time m_expSupervisionTimeout;
  /*
   * Channel Map -- Not Using at present
   */
  /*
   * Initial Channel no to start the connection
   */
  uint8_t m_initChannelNo;
  /*
   * Frequncy Hop at every connection interval
   */
  uint8_t m_freqHop;
  /*
   * Sleep Clock accuracy. Assumed to be 0.
   */
  uint8_t m_sleepClockAcc;
  /**
   * CloseConnection request reason
   */
  bool m_closeConnectionReason;
  /*
   * List of received packets from PHY. Will be accumulated untill MD=0 is not received. Once, received, it will be recombined and passed to L2CAP.
   */
  std::queue<Ptr<Packet> > m_rxPktBuffer;
  /*
   * List of packets to be transmitted. Fragmentation will save list in this variable. One by one, packets will be sent to PHY for transmission
   */
  std::queue<Ptr<Packet> > m_txPktBuffer;
  /*
   * List of packets to be transmitted. Fragmentation will save list in this variable. One by one, packets will be sent to PHY for transmission
   * Duplicate of m_txPktBuffer
   * To check whether selected packet from m_txPktBuffer is first or not.
   */
  std::queue<Ptr<Packet> > m_txPktBuffer_tmp;

  // Parameters for every Request/Response
  /*
   * Packet received from PHY. Parse it. If it is data then put in m_rxPktBuffer
   */
  Ptr<Packet> m_rxPkt;
  /*
   * Packet to be transmitted to PHY. Popped from m_txPktBuffer. Add Header/Trailer and pass to PHY.
   */
  Ptr<Packet> m_txPkt;
  /*
   * Link Layer ID
   */
  BleLinkLayerHeader::LinkLayerId m_linkLayerId;
  /*
   * Next Sequence No
   */
  bool m_nextSeq;
  /*
   * Sequence No
   */
  bool m_seqNo;
  /*
   * More Data
   */
  bool m_moreData;
  /*
   * Number of times retransmission occured in a conenction interval
   * When reaches to 2, stop the conenction event
   */
  uint8_t m_reTxInConnEvent;
  /**
   * Uniform random variable stream.
   */
  Ptr<UniformRandomVariable> m_random;

  // Trace sources
  /**
   * The trace source fired when a packet is received from PHY
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_linkLayerRxFromPhyTrace;
  /**
   * The trace source fired when a received from PHY dropped
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_linkLayerRxFromPhyDropTrace;
  /**
   * The traced source fired when a packet is received from L2CAP
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_linkLayerRxFromL2capTrace;
  /**
   * The traced source fired when a packet is transmitted to PHY
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_linkLayerTxToPhyTrace;
  /**
   * The traces source fired when a packet is transmitted to L2CAP
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<Packet>, uint8_t, uint8_t > m_linkLayerTxToL2capTrace;

  // Events
  /*
   * Scheduled advertising event. Occuring at every Advertisement Interval
   */
  EventId m_advEvent;
  /*
   * Scheduled advertising listent event.
   * Occuring at every Advertisement Interval,
   * stops at the end of Advertising Listen Window
   */
  EventId m_advListenEvent;
  /*
   * Scheduled connection event.
   * Occurs at every connection interval
   */
  EventId m_connEvent;
  /*
   * Stops conenction event
   * Occurs if other device stops responding.
   * i.e. It does not send a ACK reply twice. i.e 2ms without ACK
   */
  EventId m_stopConnEvent;
  /*
   * Schedules retransmission if packet not received in 1ms.
   */
  EventId m_ackPending;
  /*
   * For slave: Schedule to listen to the connection event
   */
  EventId m_connStopListenEvent;
  /*
   * Close Connection after Supervision Timeout if not packet transmissions occurs
   */
  EventId m_closeConnectionEvent;

};

namespace TracedValueCallback
{
/**
 * \ingroup ble
 * TracedValue callback signature for BleLinkLayer::BleLinkLayerRole.
 *
 * \param [in] oldValue original value of the traced variable
 * \param [in] newValue new value of the traced variable
 */
  typedef void (* BleLinkLayerRole)(BleLinkLayer::BleLinkLayerRole oldValue, BleLinkLayer::BleLinkLayerRole newValue);
}  // namespace TracedValueCallback

} // namespace ns3

#endif // BLE_LINKLAYER_H
