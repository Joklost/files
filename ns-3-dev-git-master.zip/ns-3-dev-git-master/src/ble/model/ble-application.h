/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#ifndef BLE_APPLICATION_H
#define BLE_APPLICATION_H

#include <ns3/ptr.h>
#include <ns3/packet.h>
#include <ns3/application.h>
#include "ble-linklayer.h"
namespace ns3 {

/**
 * \ingroup ble
 *
 * \brief Implementation of basic application layer
 * This is used to check basic LinkLayer scheduling procedures
 */
class BleApplication : public Application
{
public:

typedef enum {
  CONNECTION_SLAVE,
  CONNECTION_MASTER,
  ADVERTISE,
  SCANNING
} BleApplicationState;

public:
  /**
   * \brief Get the type ID.
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);
  /**
   * \brief Default Constructor
   */
  BleApplication (void);
  virtual ~BleApplication (void);

  /**
   * \brief Received packet from LinkLayer
   * \param p Received packet
   * \param int1 Integer parameter 1
   * \param int2 Integer parameter 2
   *
   * When Application is in SCANNING mode,
   * int1 = 0 => Connection request not Allowed
   * int1 = 1 => Conenction request allowed
   * int1 = 2 => Only Connection request is allowed
   *
   * int2 = 0 => Scan Request not allowed
   * int2 = 1 => Scan Request allowed
   *
   * When Application is in ADVERTISE mode,
   * int2 = 0 => Received packet is Connection Request
   * int2 = 1 => Received packet is Scan Request
   *
   * When Application is in CONNECTION_SLAVE mode,
   * int1 = int2 = 1 => Connection is closed. Change state to Advertise
   *
   * When Application is in CONNECTION_MASTER mode,
   * int1 = int2 = 1 => Connection closed
   * int1 = 1 and int2 = 0 => ConnectionEvent restart
   *
   */
  void RxFromLinkLayer (Ptr<Packet> p, uint8_t int1, uint8_t int2);
  /**
   * \brief Get LinkLayer
   * \return Pointer to BleLinkLayer
   */
  Ptr<BleLinkLayer> GetLinkLayer (void) const;
  /**
   * \brief Set LinkLayer
   * \param ll Pointer to BleLinkLayer
   */
  void SetLinkLayer (Ptr<BleLinkLayer> ll);
  /**
   * \brief Change state of application
   * \param s new state of application
   */
  void ChangeState (BleApplicationState s);
  /**
   * \brief Send request packet to LinkLayer
   * \param b Whether it is first request of connection
   */
  void SendRequestPacket (bool b);
  /**
   * \brief Create response packet to LinkLayer
   * \param p input packet to create response
   *
   * This particular method will shift string packet p towards right.
   */
  Ptr<Packet> CreateResponsePacket (Ptr<Packet> p);
  /**
   * \brief Set Advertising data
   * \param data Data to transmit in each ADV packets
   */
  void SetAdvString (char data[31]);
  /**
   * \brief Set Connection data
   * \param data 100 byte data to transmit during connection
   */
  void SetConnString (char data[100]);

  // Inherited from Application class
  void SetStartTime (Time start);
//  void SetStopTime (Time stop);
  void SetNode (Ptr<Node> node);
  Ptr<Node> GetNode () const;

protected:
  /**
   * \brief Call to start application by starting a advertisement.
   */
  virtual void StartApplication (void);
private:
  /**
   * Packet to be sent or received
   */
  Ptr<Packet> m_pkt;
  /**
   * Current state of Application
   */
  BleApplicationState m_state;
  /**
   * LinkLayer connected to this application
   */
  Ptr<BleLinkLayer> m_linkLayer;
  /**
   * Connection data to be sent during connections
   */
  uint8_t m_connData[100];
  /**
   * Advertising data to be sent during advertisement
   */
  uint8_t m_advData[31];

  // Inherited from Application
  virtual void DoDispose (void);
  virtual void DoInitialize (void);

  Ptr<Node>       m_node;   //!< The node that this application is installed on
  Time m_startTime;         //!< The simulation time that the application will start
  Time m_stopTime;          //!< The simulation time that the application will end
  EventId m_startEvent;     //!< The event that will fire at m_startTime to start the application
  EventId m_stopEvent;      //!< The event that will fire at m_stopTime to end the application
};

} // namespace ns3

#endif /* BLE_APPLICATION_H */
