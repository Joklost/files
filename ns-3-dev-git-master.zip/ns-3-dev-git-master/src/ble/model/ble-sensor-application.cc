/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/ble-linklayer.h>
#include "ble-sensor-application.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleSensorApplication");

TypeId
BleSensorApplication::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BleSensorApplication")
    .SetParent<Application> ()
    .SetGroupName ("Ble")
    .AddAttribute ("AppStartTime", "Time at which the application will start",
                   TimeValue (Seconds (0.0)),
                   MakeTimeAccessor (&BleSensorApplication::m_startTime),
                   MakeTimeChecker ())
    ;
  return tid;
}

BleSensorApplication::BleSensorApplication (void)
{
  NS_LOG_FUNCTION (this);
  m_state = IDLE;
  m_isOpen = false;
  m_senseCount = 0;
  m_rxCount = 0;
  m_random = CreateObject<UniformRandomVariable> ();
}

BleSensorApplication::~BleSensorApplication (void)
{
  NS_LOG_FUNCTION (this);
}

void
BleSensorApplication::SetLinkLayer (Ptr<BleLinkLayer> ll)
{
  NS_LOG_FUNCTION (this);
  m_linkLayer = ll;
  m_linkLayer->TraceConnectWithoutContext ("LinkLayerTxToL2cap", MakeCallback (&BleSensorApplication::RxFromLinkLayer, this));
}

Ptr<BleLinkLayer>
BleSensorApplication::GetLinkLayer (void) const
{
  NS_LOG_FUNCTION (this);
  return m_linkLayer;
}

void
BleSensorApplication::ChangeState (BleSensorApplication::BleApplicationState newVal)
{
  NS_LOG_FUNCTION (this);
  m_state = newVal;
  if (m_state == ADVERTISE)
    {
      Simulator::ScheduleNow (&BleSensorApplication::SendAdvPacket, this);
    }
}

void
BleSensorApplication::SetStartTime (Time start)
{
  NS_LOG_FUNCTION (this << start);
  m_startTime = start;
  m_startEvent = Simulator::Schedule (m_startTime, &BleSensorApplication::StartApplication, this);
}

void
BleSensorApplication::RxFromLinkLayer (Ptr<Packet> p, uint8_t int1, uint8_t int2)
{
  NS_LOG_FUNCTION (this);
  if (m_state == SCANNING)
    {
      // int1 = 0 = COnnection not allowed
      // int1 = 1 = Connection Allowed
      // int1 = 2 = Connection Compulsory or simply drop
      uint8_t connectionLevel = int1;
      // int2 = 0 = Scan Req not allowed
      // int2 = 1 = Scan Req allowed
      uint8_t scanLevel = int2;

      NS_LOG_INFO (this << " " << Simulator::Now ().GetMicroSeconds () << "us" << " " << "Packet #" << p->GetUid () << " Received. With CONN Request permission = " << (int)int1 << " and SCAN Request permission = " << (int)int2);
      if (connectionLevel != 0)
        {
          // Send Connect Request
          m_state = CONNECTION_MASTER;
          NS_LOG_INFO (this<< " " << Simulator::Now ().GetMicroSeconds () << "us "<< "Application set as CONNECTION_MASTER");
          m_linkLayer -> SetAdvMode (BleLinkLayer::CONN_REQ);
          Simulator::ScheduleNow (&BleLinkLayer::CreateConnection, m_linkLayer);
          Simulator::Schedule (Time("1.25ms")+m_linkLayer->GetTxWindowOffset (), &BleSensorApplication::SendRequestPacket, this, true);
          return;
        }
      else if (scanLevel != 0)
        {
          // Send Scan Request
          // SendScanRequest ();
          m_linkLayer->SendScanRequest ();
        }
      else
        {
          AnalyseScanResponsePacket (p);
          m_linkLayer->BleLLChangeState (BleLinkLayer::LL_ADV_RX_ON);
        }
    }
  else if (m_state == ADVERTISE)
    {
      // int1 = 0 = No connection from Advertiser side
      // int2 = 0 = Connection Request received
      // int2 = 1 = Scan Request Received
      // int1 = 0 && int2 = 2 = Send Adv Packet
      uint8_t isScanRq = int2;
      if (isScanRq==1)
        {
          SendScanResponse (p);
        }
      else if (isScanRq == 0)
        {
          m_state = CONNECTION_SLAVE;
          NS_LOG_INFO (this<< " " << Simulator::Now ().GetMicroSeconds () << "us "<< "Application set as CONNECTION_SLAVE");
          m_linkLayer->SetRole (BleLinkLayer::CONN_SLAVE);
          Simulator::Schedule (Time("150us"), &BleLinkLayer::BleLLChangeState, m_linkLayer, BleLinkLayer::LL_CONN_RX_ON);
        }
      else if (isScanRq == 2 && int1 == 2)
        {
          m_state = IDLE;
        }
      return;
    }
  if (m_state == CONNECTION_MASTER)
    {
      // int1 == int2 == 1 = Connection Closed
      // int1 = 1 and int2 = 0 = ConnectionEvent Restart
      if (int1 == int2 && int1 == 1)
        {
          m_state = SCANNING;
          return;
        }

      if (int1 == 1 && int2 == 0)
        {
          SendRequestPacket (false);
          return;
        }
      NS_LOG_INFO (this << " "
                    << Simulator::Now ().GetMicroSeconds () << "us "
                    << "Data Packet #" << p->GetUid () << " Received by Master.");

      AnalyseResponsePacket (p);
    }
  if (m_state == CONNECTION_SLAVE)
    {
      // int1 == int2 == 1 = Connection Closed with no more data
      // int1 == int2 == 2 = Connection Closed with supervision timeout
      if (int1 == int2 && int1 == 1)
        {
          m_data = std::queue<std::pair<BleTimeStamp, bool> > ();
          m_state = IDLE;
          return;
        }
      if (int1 == int2 && int1 == 2)
        {
          m_state = IDLE;
          return;
        }
      NS_LOG_INFO (this << " "
                    << Simulator::Now ().GetMicroSeconds () << "us "
                    << "Data Packet #" << p->GetUid () << " Received by Slave.");
      SendResponsePacket (p);
    }
}

void
BleSensorApplication::SendScanResponse (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);
  std::pair<BleTimeStamp, bool> timeBoolData = m_data.front ();
  BleTimeStamp timeData = timeBoolData.first;
  uint8_t data[8];
  data[0] = (timeData.year >> 8) & 0xff;
  data[1] = (timeData.year) & 0xff;
  data[2] = timeData.month & 0xff;
  data[3] = timeData.day & 0xff;
  data[4] = timeData.hours & 0xff;
  data[5] = timeData.minute & 0xff;
  data[6] = timeData.second & 0xff;
  data[7] = timeBoolData.second;
  Ptr<Packet> returnPacket = Create<Packet> (data, 8);
  m_linkLayer->SetAdvMode (BleLinkLayer::SCANNER_RESP);
  m_linkLayer->RxFromL2cap (returnPacket);
  Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
}

void
BleSensorApplication::AnalyseScanResponsePacket (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);
  uint8_t data[p->GetSize ()];
  p->CopyData (data, p->GetSize ());
  NS_LOG_INFO (this << " Rx " << (int)((data[0] << 8) + data[1]) << " year "
                << (int)data[2] << " month "
                << (int)data[3] << " day "
                << (int)data[4] << " hrs "
                << (int)data[5] << " minute "
                << (int)data[6] << " second "
                << (bool) data[7] << " ON/OFF ");
  NS_LOG_DEBUG (this << " Rx " << (int)((data[0] << 8) + data[1]) << " year "
                << (int)data[2] << " month "
                << (int)data[3] << " day "
                << (int)data[4] << " hrs "
                << (int)data[5] << " minute "
                << (int)data[6] << " second "
                << (bool) data[7] << " ON/OFF ");
}

void
BleSensorApplication::SendResponsePacket (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);
  uint8_t data[3];
  p->CopyData (data, 3);
  if (data[0] == 0x0A)
    {
      std::queue<std::pair<BleTimeStamp, bool> > dataQ = m_data;
      while (!dataQ.empty ())
        {
          std::pair<BleTimeStamp, bool> timeBoolData = dataQ.front ();
          BleTimeStamp timeData = timeBoolData.first;
          uint8_t data[27];
          data[0] = (timeData.year >> 8) & 0xff;
          data[1] = (timeData.year) & 0xff;
          data[2] = timeData.month & 0xff;
          data[3] = timeData.day & 0xff;
          data[4] = timeData.hours & 0xff;
          data[5] = timeData.minute & 0xff;
          data[6] = timeData.second & 0xff;
          data[7] = timeBoolData.second;
          for (int i = 8; i < 27; i++)
            data[i] = 65+(i%26);
          Ptr<Packet> returnPacket = Create<Packet> (data, 27);
          m_linkLayer->RxFromL2cap (returnPacket);
          dataQ.pop ();
        }
    }
  Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
}

void
BleSensorApplication::AnalyseResponsePacket (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);
  std::queue<Ptr<Packet> > data = std::queue<Ptr<Packet> > ();
  uint8_t size = p->GetSize ();
  uint8_t startPoint = 0;
  while (startPoint < size)
    {
      m_rxCount++;
      Ptr<Packet> frag = p->CreateFragment (startPoint, 27);
      frag = frag->CreateFragment (0, 8);
      data.push (frag);
      uint8_t timeData[8];
      frag->CopyData (timeData, 8);
      NS_LOG_INFO (this << "Rx " << (int)((timeData[0] << 8) + timeData[1]) << " year "
                    << (int)timeData[2] << " month "
                    << (int)timeData[3] << " day "
                    << (int)timeData[4] << " hrs "
                    << (int)timeData[5] << " minute "
                    << (int)timeData[6] << " second "
                    << (bool)timeData[7] << " ON/OFF" );
      NS_LOG_DEBUG (this << "Rx " << (int)((timeData[0] << 8) + timeData[1]) << " year "
                    << (int)timeData[2] << " month "
                    << (int)timeData[3] << " day "
                    << (int)timeData[4] << " hrs "
                    << (int)timeData[5] << " minute "
                    << (int)timeData[6] << " second "
                    << (bool)timeData[7] << " ON/OFF" );
      startPoint += 27;
    }
  Ptr<Packet> returnPacket = Create<Packet> ();
  m_linkLayer->RxFromL2cap (returnPacket);
  Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
}

void
BleSensorApplication::StartApplication (void)
{
  NS_LOG_FUNCTION (this);
  if (m_linkLayer->GetDeviceType() == BleLinkLayer::PERIPHERAL)
    {
      Simulator::Schedule (m_startTime, &BleSensorApplication::SensingEvent, this);
    }
  else if (m_linkLayer->GetDeviceType() == BleLinkLayer::CENTRAL)
    {
      m_linkLayer->BleLLChangeState (BleLinkLayer::LL_ADV_RX_ON);
    }
}

void
BleSensorApplication::SendAdvPacket (void)
{
  NS_LOG_FUNCTION (this);
  if (m_data.empty ())
    {
      m_state = IDLE;
      return;
    }
  if (m_state == PAUSED)
    {
      return;
    }
  uint8_t data[31];
  // AD Struct 1
  data[0] = 26;
  data[1] = 0x09; // Device Name type
  data[2] = 'D';
  data[3] = 'e';
  data[4] = 'v';
  data[5] = 'i';
  data[6] = 'c';
  data[7] = 'e';
  data[8] = ' ';
  data[9] = 'N';
  data[10] = 'a';
  data[11] = 'm';
  data[12] = 'e';
  data[13] = (rand () % 10)+48;
  data[14] = (rand () % 10)+48;
  for (int i = 15; i < 27; i++)
    data[i] = 65+(i-15)%26;
  // AD struct 2
  data[27] = 3;
  data[28] = 0x19; // Device Appr Type
  data[29] = 0;
  data[30] = 0; // Unknown type device

  Ptr<Packet> pkt = Create<Packet> (data, 31);
  m_linkLayer->RxFromL2cap (pkt);
  m_linkLayer->SetRole (BleLinkLayer::ADVERTISER);
  Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
}

void
BleSensorApplication::DoInitialize (void)
{
  NS_LOG_FUNCTION (this);
  m_startEvent = Simulator::Schedule (m_startTime, &BleSensorApplication::StartApplication, this);
  Object::DoInitialize ();
}

void
BleSensorApplication::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG(this << " Sensed Count = " << (double)m_senseCount);
  NS_LOG_DEBUG(this << " Rx Count = " << (double)m_rxCount);
  m_node = 0;
  m_linkLayer = 0;
  m_startEvent.Cancel ();
  m_stopEvent.Cancel ();
  Object::DoDispose ();
}

void
BleSensorApplication::SendRequestPacket (bool isFirstRequest)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_state == CONNECTION_MASTER);
  uint8_t data[3];
  data[0] = 0x0A; // Read by Handle Request
  data[1] = 0x00; // Assuming data is at
  data[2] = 0x01; // 0x0001 Handle
  Ptr<Packet> pkt = Create<Packet> (data, 3);
  m_linkLayer->RxFromL2cap (pkt);
  if (isFirstRequest)
    m_linkLayer->GetPhy ()->SetChannelNo (m_linkLayer->GetInitChannelNo ());

  Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, m_linkLayer);
}

void
BleSensorApplication::SensingEvent (void)
{
  NS_LOG_FUNCTION (this);
  if (m_state == SCANNING || m_state == CONNECTION_SLAVE)
    return;
  if (m_random->GetValue (0.0, 1.0) < 0.2)
    {
      Time currentTime = Simulator::Now ();
      BleTimeStamp curTimeStamp = TimetoTimeStamp (currentTime);
      NS_LOG_DEBUG (this << " SENSE " << (int)curTimeStamp.year << " year "
                    << (int)curTimeStamp.month << " month "
                    << (int)curTimeStamp.day << " day "
                    << (int)curTimeStamp.hours << " hrs "
                    << (int)curTimeStamp.minute << " minute "
                    << (int)curTimeStamp.second << " second "
                    << (bool)!m_isOpen << " ON/OFF" );

      m_data = std::queue<std::pair <BleTimeStamp, bool> > ();
      m_data.push (std::make_pair(curTimeStamp, !m_isOpen));

      m_isOpen = !m_isOpen;
      m_senseCount++;
    }
  Simulator::Schedule (Seconds(60+m_random->GetValue (0,10)), &BleSensorApplication::SensingEvent, this);
  if (m_state == IDLE)
    {
      ChangeState (ADVERTISE);
    }
}

BleTimeStamp
BleSensorApplication::TimetoTimeStamp (Time t)
{
  BleTimeStamp ts;
  ts.year = (int)t.GetYears ();
  uint32_t noOfDays = (int)t.GetDays ();
  uint32_t days = noOfDays - ts.year*365;
  days = days - (int)(ts.year/4);
  uint8_t month = 0;
  while (days > 31)
    {
      month++;
      days = days - 31;
    }
  if (month == 0 ||
      month == 2 ||
      month == 4 ||
      month == 6 ||
      month == 7 ||
      month == 9 ||
      month == 11)
    {
      ts.month = month;
      ts.day = days;
    }
  else if (month != 1)
    {
      if (days > 30)
        {
          ts.month = month + 1;
          ts.day = days - 30;
        }
      else
        {
          ts.month = month;
          ts.day = days;
        }
    }
  else
    {
      ts.month = 1;
      if (days > 29 && (ts.year % 4) == 0)
        {
          ts.day = days - 29;
          ts.month++;
        }
      else if (ts.year % 4 == 0)
        ts.day = days;
      else if (days > 28)
        {
          ts.day = days - 28;
          ts.month++;
        }
      else
        ts.day = days;
    }
  uint64_t noOfHours = (uint64_t)t.GetHours ();
  ts.hours = (int)(noOfHours - noOfDays*24);

  uint64_t noOfMinutes = (uint64_t)t.GetMinutes ();
  ts.minute = (int)(noOfMinutes - noOfHours*60);

  uint64_t noOfSeconds = (uint64_t)t.GetSeconds ();
  ts.second = (int)(noOfSeconds - noOfMinutes*60);

  return ts;
}

void
BleSensorApplication::PauseApplication (void)
{
  // Currently thinking about battery drain on peripheral side.
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("Paused!");
  m_state = BleSensorApplication::PAUSED;
  if (m_linkLayer->GetDeviceType () == BleLinkLayer::PERIPHERAL)
    {
      m_linkLayer->BleLLChangeState (BleLinkLayer::LL_IDLE);
    }
}

void
BleSensorApplication::ResumeApplication (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("Recharged!");
  if (m_linkLayer->GetDeviceType () == BleLinkLayer::PERIPHERAL)
    m_state = IDLE;
  else
    m_state = SCANNING;
}

uint64_t
BleSensorApplication::GetSenseRxCount (void)
{
  NS_LOG_FUNCTION (this);
  if (m_linkLayer->GetDeviceType () == BleLinkLayer::PERIPHERAL)
    return m_senseCount;
  return m_rxCount;
}

} // namespace ns3
