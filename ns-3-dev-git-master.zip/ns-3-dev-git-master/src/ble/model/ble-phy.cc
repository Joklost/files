/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <ns3/log.h>
#include <ns3/simulator.h>
#include <ns3/random-variable-stream.h>

#include <ns3/spectrum-value.h>
#include <ns3/spectrum-error-model.h>

#include <ns3/ble-phy.h>
#include "ble-spectrum-value-helper.h"

namespace ns3 {

class SpectrumValue;

NS_LOG_COMPONENT_DEFINE ("BlePhy");

NS_OBJECT_ENSURE_REGISTERED (BlePhy);

TypeId
BlePhy::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BlePhy")
    .SetParent<SpectrumPhy> ()
    .SetGroupName ("Ble")
    .AddConstructor<BlePhy> ()
    .AddTraceSource ("PhyStateValue",
                     "The state of the PHY Layer",
                     MakeTraceSourceAccessor (&BlePhy::m_state),
                     "ns3::TracedValueCallback::BlePhyState")
    .AddTraceSource ("PhyTxBegin",
                     "Trace source indicating a packet has"
                     "begun transmitting over the channel medium",
                     MakeTraceSourceAccessor (&BlePhy::m_phyTxBeginTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("PhyTxEnd",
                     "Trace source indicating a packet has been"
                     "completely transmitted over the channel.",
                     MakeTraceSourceAccessor (&BlePhy::m_phyTxEndTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("PhyTxDrop",
                     "Trace source indicating a packet has been "
                     "dropped by the device during transmission",
                     MakeTraceSourceAccessor (&BlePhy::m_phyTxDropTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("PhyRxBegin",
                     "Trace source indicating packet has begun "
                     "being received from the channel medium by the device",
                     MakeTraceSourceAccessor (&BlePhy::m_phyRxBeginTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("PhyEndRx",
                     "Trace source indicating packet has been "
                     "received from the channel medium by the device",
                     MakeTraceSourceAccessor (&BlePhy::m_phyRxEndTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("PhyRxDrop",
                     "Trace source indicating a packet has been "
                     "dropped by the device during reception",
                     MakeTraceSourceAccessor (&BlePhy::m_phyRxDropTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("TxToLL",
                     "Trace source indicating a packet has"
                     "sent to LinkLayer",
                     MakeTraceSourceAccessor (&BlePhy::m_txToLLTrace),
                     "ns3::Packet::TracedCallback")
  ;
  return tid;
}

BlePhy::BlePhy (void)
{
  NS_LOG_FUNCTION (this);
  m_state = OFF;
  m_rxSensitivity = -80; // dBm
  m_txPower = 10; // dBm
  m_channelNo = 0; // Default: Must be updated at every connection

  BleSpectrumValueHelper psdHelper;
  m_noise = psdHelper.CreateNoisePowerSpectralDensity (m_channelNo);

  m_signal = Create<BleInterferenceHelper> (m_noise->GetSpectrumModel ());
  Ptr<Packet> none_packet = 0;
  Ptr<BleSpectrumSignalParameters> none_params = 0;
  m_currentTxParam = std::make_pair (none_params, true);
  m_currentRxParam = std::make_pair (none_params, true);

  m_random = CreateObject<UniformRandomVariable> ();
  m_random->SetAttribute ("Min", DoubleValue (0.0));
  m_random->SetAttribute ("Max", DoubleValue (1.0));
}

BlePhy::~BlePhy (void)
{
  NS_LOG_FUNCTION (this);
}

void
BlePhy::SetTxPower (double txPower)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT_MSG ((txPower <= 10 && txPower >= -20), "BLE specifications doesn't allow txPower out of range -20 dBm to 10 dBm");
  m_txPower = txPower;
  NS_LOG_DEBUG (this << " Tx power set to " << m_txPower << "dBm");
}

double
BlePhy::GetTxPower (void)
{
  NS_LOG_FUNCTION (this);
  return m_txPower;
}

void
BlePhy::SetChannelNo (uint32_t channel_no)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT_MSG ((channel_no < 40 && channel_no >= 0), "Invalid channel number");
  m_channelNo = channel_no;
  NS_LOG_DEBUG (this << " Channel No set to " << m_channelNo);
}

uint32_t
BlePhy::GetChannelNo (void)
{
  NS_LOG_FUNCTION (this);
  return m_channelNo;
}

void
BlePhy::SetRxSensitivity (double rxSensitivity)
{
  NS_LOG_FUNCTION (this);
  m_rxSensitivity = rxSensitivity;
  NS_LOG_DEBUG (this << " Rx Sensitivity set to " << m_rxSensitivity << "dBm");
}

double
BlePhy::GetRxSensitivity (void)
{
  NS_LOG_FUNCTION (this);
  return m_rxSensitivity;
}

void
BlePhy::SetErrorModel (Ptr<SpectrumErrorModel> e)
{
  NS_LOG_FUNCTION (this << e);
  NS_ASSERT (e);
  m_errorModel = e;
}

Ptr<SpectrumErrorModel>
BlePhy::GetErrorModel (void) const
{
  NS_LOG_FUNCTION (this);
  return m_errorModel;
}

void
BlePhy::SetDevice (Ptr<NetDevice> d)
{
  NS_LOG_FUNCTION (this);
  m_netDevice = d;
}

Ptr<NetDevice>
BlePhy::GetDevice (void) const
{
  NS_LOG_FUNCTION (this);
  return m_netDevice;
}

void
BlePhy::SetMobility (Ptr<MobilityModel> m)
{
  NS_LOG_FUNCTION (this);
  m_mobility = m;
}

Ptr<MobilityModel>
BlePhy::GetMobility (void)
{
  NS_LOG_FUNCTION (this);
  return m_mobility;
}

void
BlePhy::SetChannel (Ptr<SpectrumChannel> c)
{
  NS_LOG_FUNCTION (this);
  m_channel = c;
  c->AddRx (this);
}

Ptr<SpectrumChannel>
BlePhy::GetChannel (void)
{
  NS_LOG_FUNCTION (this);
  return m_channel;
}

Ptr<const SpectrumModel>
BlePhy::GetRxSpectrumModel (void) const
{
  NS_LOG_FUNCTION (this);
  if (m_txPsd)
    {
      return m_txPsd->GetSpectrumModel ();
    }
  return 0;
}

void
BlePhy::SetRxAntenna (Ptr<AntennaModel> a)
{
  NS_LOG_FUNCTION (this);
  m_antenna = a;
}

Ptr<AntennaModel>
BlePhy::GetRxAntenna (void)
{
  NS_LOG_FUNCTION (this);
  return m_antenna;
}

BlePhy::BlePhyState
BlePhy::GetState (void) const
{
  NS_LOG_FUNCTION (this);
  return m_state;
}

void
BlePhy::SetNextPendingState (BlePhy::BlePhyState state)
{
  NS_LOG_FUNCTION (this << state);
  m_nextPendingState = state;
//  if (m_state != BUSY_RX && m_state != BUSY_TX)
//    {
//      ChangeState ();
//    }
}

void
BlePhy::ChangeState ()
{
  NS_LOG_FUNCTION (this);
  m_state = m_nextPendingState;
  if (m_interrupt)
    {
      m_state = IDLE;
      m_interrupt = false;
    }
}

void
BlePhy::SetIdleState ()
{
  NS_LOG_FUNCTION (this);
  ChangeState (IDLE);
}

void
BlePhy::ChangeState (BlePhy::BlePhyState new_state)
{
  NS_LOG_FUNCTION (this << new_state);
  m_state = new_state;
  if (m_interrupt)
    {
      m_state = IDLE;
      m_interrupt = false;
    }
}

void
BlePhy::StartRx (Ptr<SpectrumSignalParameters> params)
{
  NS_LOG_FUNCTION (this << params);
  Ptr<BlePhy> txPhy = DynamicCast<BlePhy> (params->txPhy);
  if (m_channelNo != txPhy->GetChannelNo ())
    {
      // Device is not on the same channel
      NS_LOG_LOGIC (this << " " << Simulator::Now () << " Transmitter and receiver are not on same channel");
      return;
    }
  // Get received parameters in terms of BleParam
  // TODO: Will need else case when can not cast to Ble.
  // i.e. while considering other than BLE interference also.
  Ptr<BleSpectrumSignalParameters> bleRxParam = DynamicCast<BleSpectrumSignalParameters> (params);

  // Add the incoming packet to the current received signal
  m_signal->AddSignal (bleRxParam->psd);

  // The packet of the signal
  Ptr<Packet> p = (bleRxParam->packet); //Only one packet in line

  m_recentSignalRx = Simulator::Now(); // The most recent time when signal is added in reception

  // PHY Layer is ready to listen
  if (m_state == LISTEN)
    {
      double avgPowerdBm = 10 * log10(BleSpectrumValueHelper::TotalAvgPower (bleRxParam->psd, m_channelNo)) + 30;
      if (avgPowerdBm > 5) //For more than 5dBm, receiver will be saturated
        {
          NS_LOG_LOGIC (this << " " << Simulator::Now() << " Receiver can not detect the signal");
          m_phyRxDropTrace (p);
          return;
        }
      else if (avgPowerdBm < m_rxSensitivity)
        {
          //Drop Packet
          NS_LOG_LOGIC (this << " " << Simulator::Now() << " Receiver can not detect the signal");
          m_phyRxDropTrace (p);
          return;
        }
      else
        {
          NS_LOG_DEBUG (this << " " << Simulator::Now() << " Receiving packet with power: "
                             << avgPowerdBm << "dBm");

          ChangeState (BUSY_RX);
          m_currentRxParam = std::make_pair (bleRxParam, false);
          m_phyRxBeginTrace (p);
        }
    }
  else if (m_state == BUSY_RX)
    {
      //Drop Packet
      NS_LOG_DEBUG (this << " Packet collision");
      m_phyRxDropTrace (p);
      m_currentRxParam.second = true;
    }
  else
    {
      // Drop the packet
      NS_LOG_DEBUG (this << " Transciever not in Rx state");
      m_phyRxDropTrace (p);
      m_currentRxParam.second = true;
      return;
    }

  Simulator::Schedule (params->duration, &BlePhy::EndRx, this, params);
}

void
BlePhy::CheckInterference (void)
{
  NS_LOG_FUNCTION (this);
  if (m_state == BUSY_RX)
    {
      // Time elapsed from most recent new received signal
      Time t = Simulator::Now() - m_recentSignalRx;

      // Calculate to total PSD of received signal i.e. m_signal
      Ptr<SpectrumValue> interferenceAndNoise = m_signal->GetSignalPsd ();

      // Remove the psd of currently received signal. Becuase it is signal, not noise.
      *interferenceAndNoise -= *m_currentRxParam.first->psd;

      // Adding the noise component. Because it is not being added in m_signal
      *interferenceAndNoise += *m_noise;

      // Calculate SINR value of current reception
      double signalPower = BleSpectrumValueHelper::TotalAvgPower (m_currentRxParam.first->psd, m_channelNo);
      double noisePower = BleSpectrumValueHelper::TotalAvgPower (interferenceAndNoise, m_channelNo);
      double sinr;
      if (signalPower/noisePower > 2e9)
        {
          sinr = 2e9;
        }
      else
        {
          sinr = signalPower/noisePower;
        }

      // Convert this sinr value to SpectrumValue using CreateTxPowerSpectralDensity function
      double eqTxPower = 10*log10(sinr*2.00e6)+30;
      BleSpectrumValueHelper svh;
      Ptr<SpectrumValue> sinrValue = svh.CreateTxPowerSpectralDensity(eqTxPower, m_channelNo);

      if (m_errorModel)
        {
          // In time t, t*g_dataRate number of bits are received
          (*m_errorModel).StartRx (Create<Packet> (ceil(t.GetSeconds ()*g_dataRate/8)));
          // Number of deliverable bits at given sinr and time
          (*m_errorModel).EvaluateChunk (*sinrValue, t);
          // Check whether the signal during time t corrupted the whole signal or not
          if (!(*m_errorModel).IsRxCorrect ())
            {
              // Signal was corrupted by interference
              // Set the signal currently being received to be corrupted
              m_currentRxParam.second = true;
            }
        }
    }
}

void
BlePhy::EndRx (Ptr<SpectrumSignalParameters> param)
{
  //TODO: Add effect of BER on received packets
  NS_LOG_FUNCTION (this);
  Ptr<BleSpectrumSignalParameters> bleRxParam = DynamicCast<BleSpectrumSignalParameters> (param);

  // Check the effect of all received packet/signals on current ongoing reception
  CheckInterference ();

  // Update the interference.
  m_signal->RemoveSignal (param->psd);

  if (bleRxParam == 0)
    {
      NS_LOG_LOGIC ("Node: " << m_netDevice->GetAddress() << " Removing interferent: " << *(param->psd));
      return;
    }

  // Whether the packet is what we are actually receiving
  if (m_currentRxParam.first == param)
    {
      Ptr<Packet> currentPacket = m_currentRxParam.first->packet;
      NS_ASSERT (currentPacket != 0);

      // If the packet was not marked corrupted
      if (!m_currentRxParam.second)
        {
          // Packet successfully received
          NS_LOG_DEBUG (this << " " << Simulator::Now() << " Packet #" << currentPacket->GetUid () << " received");
          NS_LOG_DEBUG (this << " " << Simulator::Now() << " Sending the packet #" << currentPacket->GetUid () << " to Link Layer");
          // Send pkt to Link Layer
          ChangeState (IDLE);
          void (BlePhy::*fp) (void) = &BlePhy::ChangeState;
          Simulator::Schedule (Time ("150us"), fp, this);
          SendPktToLinkLayer (currentPacket, m_channelNo);
        }
      else
        {
          NS_LOG_DEBUG ("Packet #" << currentPacket->GetUid () << " was corrupted");
          //Packet was corrupted. Droping it.
          m_phyRxDropTrace (currentPacket);
          ChangeState (IDLE);
          void (BlePhy::*fp) (void) = &BlePhy::ChangeState;
          Simulator::Schedule (Time ("150us"), fp, this);
        }
      Ptr<BleSpectrumSignalParameters> none = 0;
      m_currentRxParam = std::make_pair (none, true);
      // Link Layer will tell if State should be changed or not.
    }
}

void
BlePhy::SendPktToLinkLayer (Ptr<Packet> p, uint8_t channelNo)
{
  NS_LOG_FUNCTION (this);
  m_txToLLTrace (p, channelNo);
}

void
BlePhy::RxPacketFromLinkLayer (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this << p);
  NS_LOG_DEBUG (this << " " << Simulator::Now() << " Received packet #"<< p->GetUid () << " from Link Layer.");
  Ptr<BleSpectrumSignalParameters> txParams = Create<BleSpectrumSignalParameters> ();

  txParams->duration = CalculateTxTime(p);
  txParams->txPhy = GetObject<SpectrumPhy> ();
  txParams->txAntenna = m_antenna;

  txParams->packet = p;

  m_currentTxParam.first = txParams;
  m_currentTxParam.second = false;
}

void
BlePhy::StartTx (void)
{
  NS_LOG_FUNCTION (this);
  if (m_state == TRANS)
    {
      NS_ASSERT (m_channel);

      BleSpectrumValueHelper svh;
      m_txPsd = svh.CreateTxPowerSpectralDensity (m_txPower, m_channelNo);
      m_currentTxParam.first->psd = m_txPsd;

      if (!m_currentTxParam.second)
        {
          NS_LOG_DEBUG (this << " " << Simulator::Now() << " Transmission of packet #" << m_currentTxParam.first->packet->GetUid () << " begins");

          m_channel->StartTx (m_currentTxParam.first);
          Simulator::Schedule (m_currentTxParam.first->duration, &BlePhy::EndTx, this);
          ChangeState (BUSY_TX);
          m_phyTxBeginTrace (m_currentTxParam.first->packet);
          return;
        }
      else
        {
          NS_LOG_WARN ("Nothing to transmit");
        }
    }
  else
    {
      m_phyTxDropTrace (m_currentTxParam.first->packet);
    }
}

void
BlePhy::EndTx (void)
{
  NS_LOG_FUNCTION (this);
  if (m_state == BUSY_TX)
    {
      if (m_currentTxParam.second == false)
        {
          NS_LOG_DEBUG (this << " " << Simulator::Now() << " Packet #" << m_currentTxParam.first->packet->GetUid () << " successfully transmitted");
          NS_LOG_INFO (Simulator::Now() << " Packet Size " << m_currentTxParam.first->packet->GetSize ());
          m_phyTxEndTrace (m_currentTxParam.first->packet);
        }
      else
        {
          NS_LOG_DEBUG ("Packet transmission aborted");
          m_phyTxDropTrace (m_currentTxParam.first->packet);
        }
     //  m_currentTxParam.first = 0;
     //  m_currentTxParam.second = false;
      ChangeState (IDLE);
      void (BlePhy::*fp) (void) = &BlePhy::ChangeState;
      Simulator::Schedule (Time ("150us"), fp, this);
    }
  else
    {
      NS_LOG_DEBUG ("Packet transmission aborted");
      m_currentTxParam.second = true;
      m_phyTxDropTrace (m_currentTxParam.first->packet);
    }
}

Time
BlePhy::CalculateTxTime (Ptr<const Packet> packet)
{
  NS_LOG_FUNCTION (this << packet);

  Time txTime = Seconds (packet->GetSize () * 8.0 / g_dataRate);
  return txTime;
}

void
BlePhy::SetNoisePowerSpectralDensity (Ptr<const SpectrumValue> noisePsd)
{
  NS_LOG_FUNCTION (this << noisePsd);
  NS_LOG_INFO ("\t computed noise_psd: " << *noisePsd );
  NS_ASSERT (noisePsd);
  m_noise = noisePsd;
}

Ptr<const SpectrumValue>
BlePhy::GetNoisePowerSpectralDensity (void)
{
  NS_LOG_FUNCTION (this);
  return m_noise;
}

} // namespace ns3
