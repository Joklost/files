/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <typeinfo>
#include <ns3/log.h>

#include <ns3/address-utils.h>

#include "ble-linklayer-header.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleLinkLayerHeader");

NS_OBJECT_ENSURE_REGISTERED (BleLinkLayerHeader);

TypeId
BleLinkLayerHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BleLinkLayerHeader")
    .SetParent<Header> ()
    .SetGroupName ("Ble")
    .AddConstructor<BleLinkLayerHeader> ();
  return tid;
}

TypeId
BleLinkLayerHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

void
BleLinkLayerHeader::Print (std::ostream &os) const
{
  NS_LOG_FUNCTION (this);
  os << " Preamble = 0x" << std::hex << m_preamble << std::endl;
  os << " Access Address  = " << m_accessAddr << "\n";
  if (m_type == ADV)
    {
      std::string advType = "";
      switch (m_advType)
        {
        case ADV_IND:
          advType = "ADV_IND";
          break;
        case ADV_DIRECT_IND:
          advType = "ADV_DIRECT_IND";
          break;
        case ADV_NONCONN_IND:
          advType = "ADV_NONCONN_IND";
          break;
        case ADV_SCAN_IND:
          advType = "ADV_SCAN_IND";
          break;
        case SCAN_REQ:
          advType = "SCAN_REQ";
          break;
        case SCAN_RESP:
          advType = "SCAN_RESP";
          break;
        case CONNECT_REQ:
          advType = "CONNECT_REQ";
          break;
        }
      os << " Adv Pkt Type = " << advType << "\n";
      os << " TxAddrType = " << m_txAddrType << "\n";
      os << " RxAddrType = " << m_rxAddrType << "\n";
    }
  else
    {
      std::string llid = "";
      switch (m_linkLayerId)
        {
        case LL_CONTROL_PKT:
          llid = "Link Layer Control Packet";
          break;
        case LL_START_PKT:
          llid = "Link Layer Start Packet";
          break;
        case LL_CONT_PKT:
          llid = "Link Layer Continued Packet";
          break;
        }
      os << " Link Layer Identifier = " << llid << "\n";
      os << " Next Sequence # = " << std::hex << (uint8_t) m_nextSeqNo << "\n";
      os << " Sequence # = " << std::hex << (uint8_t) m_seqNo << "\n";
    }
  os << " Length = " << (uint32_t)m_length << std::endl;
  if (m_type == ADV)
    {
      os << " MacAddress = " << m_macAddress << std::endl;
      if (m_advType == ADV_DIRECT_IND || m_advType == SCAN_REQ)
        os << " RxMacAddress= " << m_rxMacAddress << std::endl;
    }
}

uint32_t
BleLinkLayerHeader::GetSerializedSize (void) const
{
  NS_LOG_FUNCTION (this);
  /*
   * Each link layer header will have
   * Preamble         : 1 octet
   * Access Address   : 4 octet
   * Header           : 1 octet
   * Length           : 1 octet
   * Mac48Address if ADV: 6 octets
   */
  if (m_type == ADV)
    {
      if (m_advType == ADV_DIRECT_IND || m_advType == SCAN_REQ || m_advType == CONNECT_REQ || m_advType == SCAN_RESP)
        return 19;
      else
        return 13;
    }
  return 7;
}

void
BleLinkLayerHeader::Serialize (Buffer::Iterator start) const
{
  NS_LOG_FUNCTION (this);

  // Content of header
  Buffer::Iterator i = start;
  uint8_t preamble = m_preamble;
  i.WriteU8 (((int) preamble) & 0xff);
  // Write Access Address in Buffer
  uint8_t address[4];
  m_accessAddr.CopyTo (address);
  i.WriteU8 (address[0]);
  i.WriteU8 (address[1]);
  i.WriteU8 (address[2]);
  i.WriteU8 (address[3]);
  // Write Header in Buffer
  uint8_t header = 0;
  if (m_type == ADV)
    {
      header = header | m_advType;
      header = header << 3;
      header = header | m_txAddrType;
      header = header << 1;
      header = header | m_rxAddrType;
    }
  else
    {
      header = header | m_linkLayerId;
      header = header << 1;
      header = header | m_nextSeqNo;
      header = header << 1;
      header = header | m_seqNo;
      header = header << 1;
      header = header | m_moreData;
      header = header << 3;
    }
  i.WriteU8 (header);
  // Write length
  i.WriteU8 (m_length);
  // If ADV pkt, then add MAC48Address of LinkLayer also.
  // Although this is included in Payload, instead, here it is put as a header only.
  if (m_type == ADV)
    {
      uint8_t address[6];
      Mac48Address macAddr = m_macAddress;
      macAddr.CopyTo (address);
      i.WriteU8 (address[0]);
      i.WriteU8 (address[1]);
      i.WriteU8 (address[2]);
      i.WriteU8 (address[3]);
      i.WriteU8 (address[4]);
      i.WriteU8 (address[5]);
      if (m_advType == ADV_DIRECT_IND || m_advType == SCAN_REQ || m_advType == CONNECT_REQ || m_advType == SCAN_RESP)
        {
          uint8_t rxAddr[6];
          m_rxMacAddress.CopyTo (rxAddr);
          i.WriteU8 (rxAddr[0]);
          i.WriteU8 (rxAddr[1]);
          i.WriteU8 (rxAddr[2]);
          i.WriteU8 (rxAddr[3]);
          i.WriteU8 (rxAddr[4]);
          i.WriteU8 (rxAddr[5]);
        }
    }
}

uint32_t
BleLinkLayerHeader::Deserialize (Buffer::Iterator start)
{
  NS_LOG_FUNCTION (this);
  Buffer::Iterator i = start;
  m_preamble = static_cast<BlePreamble>( (uint8_t) i.ReadU8 ());
  uint8_t addr[4];
  addr[0] = i.ReadU8 ();
  addr[1] = i.ReadU8 ();
  addr[2] = i.ReadU8 ();
  addr[3] = i.ReadU8 ();
  m_accessAddr.CopyFrom (addr);
  uint8_t header = ((uint8_t) i.ReadU8 ());
  if (m_type == ADV)
    {
      m_rxAddrType = static_cast<BleLinkLayerHeader::RxAddrType> (header & 1);
      m_txAddrType = static_cast<BleLinkLayerHeader::TxAddrType> ((header >> 1) & 1);
      m_advType = static_cast<BleLinkLayerHeader::AdvPacketType> ((header >> 4) & 15);
    }
  else
    {
      m_moreData = (header >> 3) & 1;
      m_seqNo = (header >> 4) & 1;
      m_nextSeqNo = (header >> 5) & 1;
      m_linkLayerId = static_cast<BleLinkLayerHeader::LinkLayerId> ((header >> 6) & 3);
    }
  m_length = (uint32_t) i.ReadU8 ();
  if (m_type == ADV)
    {
      uint8_t macAddr[6];
      macAddr[0] = i.ReadU8 ();
      macAddr[1] = i.ReadU8 ();
      macAddr[2] = i.ReadU8 ();
      macAddr[3] = i.ReadU8 ();
      macAddr[4] = i.ReadU8 ();
      macAddr[5] = i.ReadU8 ();
      m_macAddress.CopyFrom (macAddr);
      if (m_advType == ADV_DIRECT_IND || m_advType == SCAN_REQ || m_advType == CONNECT_REQ || m_advType == SCAN_RESP)
        {
          uint8_t rxMacAddr[6];
          rxMacAddr[0] = i.ReadU8 ();
          rxMacAddr[1] = i.ReadU8 ();
          rxMacAddr[2] = i.ReadU8 ();
          rxMacAddr[3] = i.ReadU8 ();
          rxMacAddr[4] = i.ReadU8 ();
          rxMacAddr[5] = i.ReadU8 ();
          m_rxMacAddress.CopyFrom (rxMacAddr);
        }
    }

  // Return size of header
  return i.GetDistanceFrom (start);
}

BleLinkLayerHeader::BleLinkLayerHeader ()
{
  NS_LOG_FUNCTION (this);
}

BleLinkLayerHeader::~BleLinkLayerHeader ()
{
  NS_LOG_FUNCTION (this);
}

void
BleLinkLayerHeader::SetAccessAddress (BleAccessAddress addr)
{
  NS_LOG_FUNCTION (this << addr);
  m_accessAddr = addr;
  // With address, also decide preamble
  uint8_t address[4];
  m_accessAddr.CopyTo (address);
  // This means that last bit of address is 1.
  // After bit reversal, it becomes the first bit.
  // Hence, preamble must end with 0
  if (address[3]%2 == 1)
    {
      m_preamble = PREAMBLE_END_0;
    }
  else
    {
      m_preamble = PREAMBLE_END_1;
    }
}

BleAccessAddress
BleLinkLayerHeader::GetAccessAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_accessAddr;
}

void
BleLinkLayerHeader::SetRxMacAddress (Mac48Address addr)
{
  NS_LOG_FUNCTION (this << addr);
  m_rxMacAddress = addr;
}

Mac48Address
BleLinkLayerHeader::GetRxMacAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_rxMacAddress;
}

void
BleLinkLayerHeader::SetMacAddress (Mac48Address addr)
{
  NS_LOG_FUNCTION (this << addr);
  m_macAddress = addr;
}

Mac48Address
BleLinkLayerHeader::GetMacAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_macAddress;
}

void
BleLinkLayerHeader::SetType (BleLinkLayerHeader::BlePacketType t)
{
  NS_LOG_FUNCTION (this);
  if (t == ADV)
    {
      m_type = ADV;
      m_accessAddr = BleAccessAddress ("8E:89:BE:D6");
      m_preamble = PREAMBLE_END_1;
    }
  else
    {
      m_type = DATA;
    }
}

BleLinkLayerHeader::BlePacketType
BleLinkLayerHeader::GetType (void) const
{
  NS_LOG_FUNCTION (this);
  return m_type;
}

void
BleLinkLayerHeader::SetAdvPktType (BleLinkLayerHeader::AdvPacketType type)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == ADV);
  m_advType = type;
}

BleLinkLayerHeader::AdvPacketType
BleLinkLayerHeader::GetAdvPktType (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == ADV);
  return m_advType;
}

void
BleLinkLayerHeader::SetTxAddrType (BleLinkLayerHeader::TxAddrType type)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == ADV);
  m_txAddrType = type;
}

BleLinkLayerHeader::TxAddrType
BleLinkLayerHeader::GetTxAddrType (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == ADV);
  return m_txAddrType;
}

void
BleLinkLayerHeader::SetRxAddrType (BleLinkLayerHeader::RxAddrType type)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == ADV);
  m_rxAddrType = type;
}

BleLinkLayerHeader::RxAddrType
BleLinkLayerHeader::GetRxAddrType (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == ADV);
  return m_rxAddrType;
}

void
BleLinkLayerHeader::SetLinkLayerId (BleLinkLayerHeader::LinkLayerId llid)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == DATA);
  m_linkLayerId = llid;
}

BleLinkLayerHeader::LinkLayerId
BleLinkLayerHeader::GetLinkLayerId (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == DATA);
  return m_linkLayerId;
}

void
BleLinkLayerHeader::SetNextSequenceNo (bool nesn)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == DATA);
  m_nextSeqNo = nesn;
}

bool
BleLinkLayerHeader::GetNextSequenceNo (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == DATA);
  return m_nextSeqNo;
}

void
BleLinkLayerHeader::SetSequenceNo (bool sn)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == DATA);
  m_seqNo = sn;
}

bool
BleLinkLayerHeader::GetSequenceNo (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == DATA);
  return m_seqNo;
}

void
BleLinkLayerHeader::SetMoreData (bool md)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == DATA);
  m_moreData = md;
}

bool
BleLinkLayerHeader::GetMoreData (void) const
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (m_type == DATA);
  return m_moreData;
}

void
BleLinkLayerHeader::SetLength (uint8_t len)
{
  NS_LOG_FUNCTION (this);
  if (m_type == ADV)
    {
      NS_ASSERT (len <= 31);
    }
  else
    {
      NS_ASSERT (len <= 27);
    }
  m_length = len;
}

uint8_t
BleLinkLayerHeader::GetLength (void) const
{
  NS_LOG_FUNCTION (this);
  return m_length;
}

} // namespace ns3
