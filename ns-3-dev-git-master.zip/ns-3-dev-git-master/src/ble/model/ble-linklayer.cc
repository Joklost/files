/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */

#include <string>
#include <ns3/nstime.h>
#include <ns3/log.h>
#include <ns3/config.h>
#include <ns3/simulator.h>

#include "ble-linklayer.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleLinkLayer");

NS_OBJECT_ENSURE_REGISTERED (BleLinkLayer);

TypeId
BleLinkLayer::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BleLinkLayer")
    .SetParent<Object> ()
    .SetGroupName ("Ble")
    .AddAttribute ("Maximum Buffer Size", "Size of Tx and Rx buffer of LinkLayer",
                   UintegerValue (2e16),
                   MakeUintegerAccessor (&BleLinkLayer::m_maxBufferSize),
                   MakeUintegerChecker<uint32_t> ())
    .AddTraceSource ("LinkLayerRoleValue",
                     "The role of LinkLayer",
                     MakeTraceSourceAccessor (&BleLinkLayer::m_role),
                     "ns3::TracedValueCallback::BleLinkLayerRole")
    .AddTraceSource ("LinkLayerTxToPhy",
                     "Trace source indicating a packet has "
                     "been transmitted to the PHY.",
                     MakeTraceSourceAccessor (&BleLinkLayer::m_linkLayerTxToPhyTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("LinkLayerTxToL2cap",
                     "Trace Source indicating a packet has been "
                     "transmitted to the L2CAP.",
                     MakeTraceSourceAccessor (&BleLinkLayer::m_linkLayerTxToL2capTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("LinkLayerRxFromPhy",
                     "trace source indicating a packet has been "
                     "received from PHY.",
                     MakeTraceSourceAccessor (&BleLinkLayer::m_linkLayerRxFromPhyTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("LinkLayerRxFromL2cap",
                     "Trace Source indicating a packet has been "
                     "received from L2CAP.",
                     MakeTraceSourceAccessor (&BleLinkLayer::m_linkLayerRxFromL2capTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("LinkLayerRxFromPhyDrop",
                     "Trace source indicating a packet was received, "
                     "but dropped before being forwarded up the stack",
                     MakeTraceSourceAccessor (&BleLinkLayer::m_linkLayerRxFromPhyDropTrace),
                     "ns3::Packet::TracedCallback")
//    .AddTraceSource ("Sniffer",
//                     "Trace source simulating a non-promiscuous "
//                     "packet sniffer attached to the device",
//                     MakeTraceSourceAccessor (&LrWpanMac::m_snifferTrace),
//                     "ns3::Packet::TracedCallback")
    ;
    return tid;
}

BleLinkLayer::BleLinkLayer (BleLinkLayerDeviceTypes type)
  : m_deviceType (type)
{
  NS_LOG_FUNCTION (this<<type);
  m_sleepClockAcc = 7;  // Corresponding to 0-20 ppm
  m_random = CreateObject<UniformRandomVariable> ();
}

BleLinkLayer::~BleLinkLayer (void)
{
  NS_LOG_FUNCTION (this);
}

BleLinkLayer::BleLinkLayerDeviceTypes
BleLinkLayer::GetDeviceType (void) const
{
  NS_LOG_FUNCTION (this);
  return m_deviceType;
}

void
BleLinkLayer::SetMacAddress (Mac48Address addr)
{
  NS_LOG_FUNCTION (this);
  m_addr = addr;
}

Mac48Address
BleLinkLayer::GetMacAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_addr;
}

void
BleLinkLayer::SetPhy (Ptr<BlePhy> p)
{
  NS_LOG_FUNCTION (this);
  m_phy = p;
  m_phy -> TraceConnectWithoutContext ("TxToLL",
                                       MakeCallback (&BleLinkLayer::RxFromPhy,
                                                     this));
}

Ptr<BlePhy>
BleLinkLayer::GetPhy (void) const
{
  NS_LOG_FUNCTION (this);
  return m_phy;
}

void
BleLinkLayer::EnableWhiteList (void)
{
  NS_LOG_FUNCTION (this);
  m_isWhiteList = true;
}

void
BleLinkLayer::DisableWhiteList (void)
{
  NS_LOG_FUNCTION (this);
  m_isWhiteList = false;
}

void
BleLinkLayer::AddWhiteList (Mac48Address addr)
{
  NS_LOG_FUNCTION (this);
  m_whiteLists.push_back (addr);
}

bool
BleLinkLayer::RemoveWhiteList (Mac48Address addr)
{
  NS_LOG_FUNCTION (this);
  bool flag = false;
  std::vector<Mac48Address>::iterator it;
  for (it = m_whiteLists.begin();
       it != m_whiteLists.end();
       ++it)
    {
      if (*it == addr)
        {
          m_whiteLists.erase (it);
          flag = true;
        }
    }
  return flag;
}

bool
BleLinkLayer::CheckWhiteList (Mac48Address addr)
{
  NS_LOG_FUNCTION (this);
  std::vector<Mac48Address>::iterator it;
  for (it = m_whiteLists.begin();
       it != m_whiteLists.end();
       ++it)
    {
      if (*it == addr)
        {
          return true;
        }
    }
  return false;
}

bool
BleLinkLayer::IsWhiteListEnabled (void)
{
  NS_LOG_FUNCTION (this);
  return m_isWhiteList;
}

Time
BleLinkLayer::GetAdvListenWindow (void) const
{
  NS_LOG_FUNCTION (this);
  return m_advListenWindow;
}

void
BleLinkLayer::SetAdvListenWindow (Time advInt)
{
  NS_LOG_FUNCTION (this);
  m_advListenWindow = advInt;
}
Time
BleLinkLayer::GetAdvInterval (void) const
{
  NS_LOG_FUNCTION (this);
  return m_advInterval;
}

void
BleLinkLayer::SetAdvInterval (Time advInt)
{
  NS_LOG_FUNCTION (this);
  m_advInterval = advInt;
}

void
BleLinkLayer::SetAdvMode (BleAdvMode m)
{
  NS_LOG_FUNCTION (this << m);
  m_prevAdvMode = m_advMode;
  m_advMode = m;
}

BleLinkLayer::BleAdvMode
BleLinkLayer::GetAdvMode (void) const
{
  NS_LOG_FUNCTION (this);
  return m_advMode;
}

void
BleLinkLayer::SetRxDeviceAddress (Mac48Address addr)
{
  NS_LOG_FUNCTION (this);
  m_rxDeviceAddr = addr;
}

Mac48Address
BleLinkLayer::GetRxDeviceAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_rxDeviceAddr;
}

void
BleLinkLayer::SetConnAddress (Mac48Address addr)
{
  NS_LOG_FUNCTION (this);
  m_connAddr = addr;
}

Mac48Address
BleLinkLayer::GetConnAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_connAddr;
}

void
BleLinkLayer::SetAccessAddress (BleAccessAddress addr)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT_MSG (m_role != CONN_SLAVE, "Device is a Slave. It can not change Access Address");
  m_accessAddr = addr;
  if (m_role == CONN_MASTER)
    {
      CreateManagementPacket ("m_accessAddr");
    }
}

BleAccessAddress
BleLinkLayer::GetAccessAddress (void) const
{
  NS_LOG_FUNCTION (this);
  return m_accessAddr;
}

void
BleLinkLayer::SetCrcInit (uint32_t crcInit)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT_MSG (m_role != CONN_SLAVE, "Device is a Slave. It can not change CRC Init Value");
  NS_ASSERT (crcInit <= 0xFFFFFF); // Must be 24-bit value
  m_crcInitVal = crcInit;
  if (m_role == CONN_MASTER)
    {
      CreateManagementPacket ("m_crcInitVal");
    }
}

uint32_t
BleLinkLayer::GetCrcInit (void) const
{
  NS_LOG_FUNCTION (this);
  return m_crcInitVal;
}

uint8_t
BleLinkLayer::GetInitChannelNo (void) const
{
  NS_LOG_FUNCTION (this);
  return m_initChannelNo;
}

void
BleLinkLayer::SetTxWindowSize (uint8_t t)
{
  NS_LOG_FUNCTION (this);
  m_txWindowSize = Time::FromDouble (t*1.25, static_cast<Time::Unit> (5));
  if (m_role == CONN_MASTER)
    {
      CreateManagementPacket ("m_txWindowSize");
    }
}

Time
BleLinkLayer::GetTxWindowSize (void) const
{
  NS_LOG_FUNCTION (this);
  return m_txWindowSize;
}

void
BleLinkLayer::SetTxWindowOffset (uint16_t t)
{
  NS_LOG_FUNCTION (this);
  m_txWindowOffset = Time::FromDouble (t*1.25, static_cast<Time::Unit> (5));
  if (m_role == CONN_MASTER)
    {
      CreateManagementPacket ("m_txWindowOffset");
    }
}

Time
BleLinkLayer::GetTxWindowOffset (void) const
{
  NS_LOG_FUNCTION (this);
  return m_txWindowOffset;
}

void
BleLinkLayer::SetConnectionInterval (uint16_t t)
{
  NS_LOG_FUNCTION (this);
  m_connInterval = Time::FromDouble (t*1.25, static_cast<Time::Unit> (5));
  if (!m_isConnected)
    {
      m_supervisionTimeout = 6*m_connInterval;
    }
  if (m_role == CONN_MASTER)
    {
      CreateManagementPacket ("m_connInterval");
    }
}

Time
BleLinkLayer::GetConnectionInterval (void) const
{
  NS_LOG_FUNCTION (this);
  return m_connInterval;
}

void
BleLinkLayer::SetSupervisionTimeout (uint16_t t)
{
  NS_LOG_FUNCTION (this);
  m_expSupervisionTimeout = Time::FromDouble (t*10, static_cast<Time::Unit> (5));
  if (m_role == CONN_MASTER)
    {
      CreateManagementPacket ("m_supervisionTimeout");
    }
}

Time
BleLinkLayer::GetSupervisionTimeout (void) const
{
  NS_LOG_FUNCTION (this);
  return m_supervisionTimeout;
}

void
BleLinkLayer::SetSlaveLatency (uint16_t sl)
{
  NS_LOG_FUNCTION (this);
  m_slaveLatency = sl;
  if (m_role == CONN_MASTER)
    {
      CreateManagementPacket ("m_slaveLatency");
    }
}

uint32_t
BleLinkLayer::GetSlaveLatency (void) const
{
  NS_LOG_FUNCTION (this);
  return m_slaveLatency;
}

void
BleLinkLayer::SetFreqHop (uint8_t hop)
{
  NS_LOG_FUNCTION (this);
  m_freqHop = hop;
  if (m_role == CONN_MASTER)
    {
      CreateManagementPacket ("m_freqHop");
    }
}

uint8_t
BleLinkLayer::GetFreqHop (void) const
{
  NS_LOG_FUNCTION (this);
  return m_freqHop;
}

void
BleLinkLayer::SetLinkLayerId (BleLinkLayerHeader::LinkLayerId id)
{
  NS_LOG_FUNCTION (this);
  m_linkLayerId = id;
}

void
BleLinkLayer::SetNextSequenceNo (bool nesn)
{
  NS_LOG_FUNCTION (this);
  m_nextSeq = nesn;
}

bool
BleLinkLayer::GetNextSequenceNo (void) const
{
  NS_LOG_FUNCTION (this);
  return m_nextSeq;
}

void
BleLinkLayer::SetSequenceNo (bool sn)
{
  NS_LOG_FUNCTION (this);
  m_seqNo = sn;
}

bool
BleLinkLayer::GetSequenceNo (void) const
{
  NS_LOG_FUNCTION (this);
  return m_seqNo;
}

void
BleLinkLayer::SetMoreData (bool md)
{
  NS_LOG_FUNCTION (this);
  m_moreData = md;
}

bool
BleLinkLayer::GetMoreData (void) const
{
  NS_LOG_FUNCTION (this);
  return m_moreData;
}

void
BleLinkLayer::SetRole (BleLinkLayerRole r)
{
  NS_LOG_FUNCTION (this);
  m_role = r;
  m_ackPending.Cancel ();
}

void
BleLinkLayer::RxFromL2cap (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG (this << " "
                << Simulator::Now ().GetMicroSeconds () << "us" << " "
                << "Received Packet #"<< p->GetUid () << " " << "From L2CAP");
  m_linkLayerRxFromL2capTrace (p);
  // For now assume that packet is just Data/Adv Packet.
  // Not management packet.
  uint32_t p_size = p->GetSize ();
  uint32_t allowedPktSize;
  if (m_role == CONN_MASTER || m_role == CONN_SLAVE)
    {
      allowedPktSize = 27;
    }
  else
    {
      allowedPktSize = 31;
    }
  if (p_size > allowedPktSize && (m_role != ADVERTISER || m_role != SCANNER_ACT))
    {
      uint32_t startPoint = 0;
      uint32_t endPoint = allowedPktSize;
      while (startPoint < p_size)
        {
          if (endPoint > p_size)
            endPoint = p_size;

          Ptr<Packet> frag =  p->CreateFragment (startPoint, endPoint-startPoint);
          m_txPktBuffer.push (frag);
          m_txPktBuffer_tmp.push (frag);
          startPoint = endPoint;
          endPoint = startPoint + allowedPktSize;
        }
    }
  else
    {
      m_txPktBuffer.push (p);
      m_txPktBuffer_tmp.push (p);
    }
  m_linkLayerRxFromL2capTrace (p);
}

void
BleLinkLayer::CreateManagementPacket (std::string param)
{
  NS_LOG_FUNCTION (this);
}

void
BleLinkLayer::TxToPhy (void)
{
  NS_LOG_FUNCTION (this);
  BleLinkLayerHeader hdr;
  if (m_role == ADVERTISER || m_role == SCANNER_ACT || m_role == SCANNER_PASS)
    {
      Ptr<Packet> finalPkt;
      bool flag = false;
      hdr.SetType (BleLinkLayerHeader::ADV);
      if (m_advMode != DIRECT_ADV)
        {
          m_txPkt = m_txPktBuffer.front ();
          hdr.SetLength (m_txPkt->GetSize ());
        }
      if (m_role == ADVERTISER)
        {
          hdr.SetMacAddress (GetMacAddress ());
          if (m_advMode == GENERAL_ADV)
              hdr.SetAdvPktType (BleLinkLayerHeader::ADV_IND);
          else if (m_advMode == DIRECT_ADV)
            {
              finalPkt = Create<Packet> ();
              hdr.SetAdvPktType (BleLinkLayerHeader::ADV_DIRECT_IND);
              hdr.SetRxMacAddress (m_rxDeviceAddr);
              hdr.SetLength (0);
              flag = true;
            }
          else if (m_advMode == NON_CONN_ADV)
              hdr.SetAdvPktType (BleLinkLayerHeader::ADV_NONCONN_IND);
          else if (m_advMode == DISC_ADV)
              hdr.SetAdvPktType (BleLinkLayerHeader::ADV_SCAN_IND);
          else if (m_advMode == SCANNER_RESP)
            {
              hdr.SetAdvPktType (BleLinkLayerHeader::SCAN_RESP);
              hdr.SetRxMacAddress (m_connAddr);
            }
          else  // Default General Adv
            {
              hdr.SetAdvPktType (BleLinkLayerHeader::ADV_IND);
              m_advMode = GENERAL_ADV;
            }
        }
      else if (m_role == SCANNER_ACT && m_advMode == SCANNER_REQ)
        {
          hdr.SetAdvPktType (BleLinkLayerHeader::SCAN_REQ);
          hdr.SetMacAddress (GetMacAddress ());
          hdr.SetRxMacAddress (m_connAddr);
        }
      else if (m_role == SCANNER_ACT || m_role == SCANNER_PASS)
        {
          if (m_advMode == CONN_REQ)
            {
              hdr.SetAdvPktType (BleLinkLayerHeader::CONNECT_REQ);
              hdr.SetRxMacAddress (m_connAddr);
              hdr.SetAccessAddress (m_accessAddr);
            }
        }
      // Constant for now. Not considering Security/Privacy at present
      // TODO: Update for Privacy/Security
      hdr.SetTxAddrType (BleLinkLayerHeader::TX_ADDR_PUBLIC);
      hdr.SetRxAddrType (BleLinkLayerHeader::RX_ADDR_PUBLIC);

      if (!(hdr.GetAdvPktType () == BleLinkLayerHeader::CONNECT_REQ ||
          hdr.GetAdvPktType () == BleLinkLayerHeader::SCAN_REQ    ||
          hdr.GetAdvPktType () == BleLinkLayerHeader::SCAN_RESP))
        {
          m_phy -> SetChannelNo ((int)(m_random->GetValue (37, 40)));
          NS_LOG_DEBUG (this << " "
                        << Simulator::Now().GetMicroSeconds () << "us "
                        << "Transmission at Channel " << (int)m_phy->GetChannelNo ());
        }

      BleLinkLayerTrailer tlr;
      if (flag)
        {
          finalPkt->AddHeader (hdr);
          tlr.SetCrc24 (finalPkt);
          finalPkt->AddTrailer (tlr);
          m_phy -> RxPacketFromLinkLayer (finalPkt);
          m_linkLayerTxToPhyTrace (finalPkt);
        }
      else
        {
          m_txPkt -> AddHeader (hdr);
          tlr.SetCrc24 (m_txPkt);
          m_txPkt -> AddTrailer (tlr);
          m_phy -> RxPacketFromLinkLayer (m_txPkt);
          m_linkLayerTxToPhyTrace (m_txPkt);
          m_txPktBuffer.pop ();
        }
        Simulator::Schedule (Time("150us"),
                             &BleLinkLayer::BleLLChangeState,
                             this, LL_ADV_TX_ON);
    }
  else
    {
      if (m_txPktBuffer.empty())
        {
          NS_LOG_ERROR ("Nothing to Transmit");
          return;
        }
      m_txPkt = m_txPktBuffer.front ();
      m_txPktBuffer.pop ();

      if (m_linkLayerId != BleLinkLayerHeader::LL_CONTROL_PKT)
        {
          if (m_txPktBuffer.front () == m_txPktBuffer_tmp.front ())
            m_linkLayerId = BleLinkLayerHeader::LL_START_PKT;
          else
            m_linkLayerId = BleLinkLayerHeader::LL_CONT_PKT;
        }
      hdr.SetType (BleLinkLayerHeader::DATA);
      hdr.SetAccessAddress (m_accessAddr);
      hdr.SetLinkLayerId (m_linkLayerId);
      hdr.SetNextSequenceNo (m_nextSeq);
      hdr.SetSequenceNo (m_seqNo);
      hdr.SetMoreData (!m_txPktBuffer.empty ());
      if (!m_txPktBuffer.empty ())
        NS_LOG_DEBUG (this << " "
                      << Simulator::Now ().GetMicroSeconds () << "us "
                      << "Sending DATA packet with MoreData");
      else
        NS_LOG_DEBUG (this << " "
                      << Simulator::Now ().GetMicroSeconds () << "us "
                      << "Sending last or only DATA packet");
      hdr.SetLength (m_txPkt->GetSize ());
      m_txPkt->AddHeader (hdr);
      BleLinkLayerTrailer tlr;
      tlr.SetCrcInit (m_crcInitVal);
      tlr.SetCrc24 (m_txPkt);
      m_txPkt->AddTrailer (tlr);
      m_phy->RxPacketFromLinkLayer (m_txPkt);
      Simulator::Schedule (Time("150us"),
                           &BleLinkLayer::BleLLChangeState,
                           this, LL_CONN_TX_ON);
      m_linkLayerTxToPhyTrace (m_txPkt);
    }
}

void
BleLinkLayer::BleLLChangeState (BleLLState s)
{
  NS_LOG_FUNCTION (this);

  if (s == LL_ADV_TX_ON)
    {
      NS_ASSERT (m_role == ADVERTISER ||
                 m_role == SCANNER_ACT ||
                 m_role == SCANNER_PASS);
      NS_ASSERT (m_phy -> GetState () != BlePhy::BUSY_TX
                 || m_phy -> GetState () != BlePhy::BUSY_RX);
      m_phy -> TraceDisconnectWithoutContext ("PhyTxEnd",
                                              MakeCallback (&BleLinkLayer::SetAdvChannelNo, this));
      m_phy -> ChangeState (BlePhy::TRANS); // Can call Energy Depletion Callback
      if (m_phy->GetState () == BlePhy::IDLE)
        {
          m_phy->m_interrupt = false;
          m_txPktBuffer = std::queue<Ptr<Packet> > ();
          m_txPktBuffer_tmp = std::queue<Ptr<Packet> > ();
          Ptr<Packet> ind = Create<Packet> ();
          TxToL2cap(ind, 2, 2); // Indication to Application that Packet was not sent
          return;
        }
      m_phy->StartTx ();
      // Special cases
      if (m_advMode == CONN_REQ)
        {
          NS_LOG_DEBUG (this << " "
                        << Simulator::Now ().GetMicroSeconds () << "us "
                        << "Transmission of CONN_REQ packet has begun");
          m_role = CONN_MASTER;

          NS_LOG_DEBUG (this << " "
                        << Simulator::Now ().GetMicroSeconds () << "us "
                        << "Changed to CONN_MASTER mode");
          m_connEvent = Simulator::Schedule (m_connInterval,
                                             &BleLinkLayer::StartConnectionEvent,
                                             this);

          m_closeConnectionEvent = Simulator::Schedule (m_supervisionTimeout,
                                                        &BleLinkLayer::CloseConnection,
                                                        this, true, true);
        }
      else
        {
          NS_LOG_DEBUG (this << " "
                        << Simulator::Now ().GetMicroSeconds () << "us "
                        << "Transmission of ADV packet has begun");
          if (m_advMode != SCANNER_RESP && m_advMode != SCANNER_REQ)
            {
              // 10 ms random time
              uint8_t random = (int)(m_random->GetValue (0, 10));
              m_advEvent = Simulator::Schedule (m_advInterval + Time::FromInteger (random, static_cast<Time::Unit> (5)),
                                                &BleLinkLayer::BleConnReqTimeout,
                                                this);
            }
          if (m_advMode == NON_CONN_ADV || m_advMode == SCANNER_RESP)
            {
              m_phy->SetNextPendingState (BlePhy::IDLE);
              if (m_advMode == SCANNER_RESP)
                m_advMode = m_prevAdvMode;
            }
          else
            {
              m_phy->SetNextPendingState(BlePhy::LISTEN);
              if (m_advMode == DISC_ADV)
                NS_LOG_DEBUG (this << " "
                              << Simulator::Now ().GetMicroSeconds () << "us "
                              << "LinkLayer in Listening for SCANNER_REQ");
              else if (m_advMode == SCANNER_REQ)
                NS_LOG_DEBUG (this << " "
                              << Simulator::Now ().GetMicroSeconds () << "us "
                              << "LinkLayer in Listening for SCANNER_RESP");
              else if (m_advMode == DIRECT_ADV)
                NS_LOG_DEBUG (this << " "
                              << Simulator::Now ().GetMicroSeconds () << "us "
                              << "LinkLayer in Listening for CONN_REQ");
              else
                NS_LOG_DEBUG (this << " "
                              << Simulator::Now ().GetMicroSeconds () << "us "
                              << "LinkLayer in Listening for SCANNER_REQ or CONN_REQ");
            }
        }
    }
  else if (s == LL_ADV_RX_ON)
    {
      NS_ASSERT (m_role == SCANNER_ACT ||
                 m_role == SCANNER_PASS);
      if (m_linkLayerId == BleLinkLayerHeader::LL_CONTROL_PKT)
        m_linkLayerId = BleLinkLayerHeader::LL_START_PKT;

      m_phy -> TraceDisconnectWithoutContext ("PhyTxEnd",
                                              MakeCallback (&BleLinkLayer::SetAdvChannelNo, this));
      m_phy->ChangeState (BlePhy::LISTEN);
      if (m_phy->GetState () == BlePhy::IDLE)
        {
          m_phy->m_interrupt = false;
          return;
        }
      Simulator::Schedule (m_advListenWindow,
                           &BlePhy::SetNextPendingState,
                           m_phy, BlePhy::IDLE);

      void (BlePhy::*fp) (BlePhy::BlePhyState) = &BlePhy::ChangeState;
      Simulator::Schedule (m_advListenWindow, fp, m_phy, BlePhy::IDLE);

      m_advListenEvent = Simulator::Schedule (m_advInterval,
                                              &BleLinkLayer::BleNoPacketTimeout,
                                              this);
    }
  else if (s == LL_CONN_RX_ON)
    {
      NS_ASSERT (m_role == CONN_SLAVE ||
                 m_role == CONN_MASTER);

      m_phy->ChangeState (BlePhy::LISTEN);
      if (m_phy->GetState () == BlePhy::IDLE)
        {
          m_phy->m_interrupt = false;
          return;
        }
      m_connEvent = Simulator::Schedule (m_connInterval,
                                         &BleLinkLayer::StartConnectionEvent,
                                         this);
    }
  else if (s == LL_CONN_TX_ON)
    {
      NS_ASSERT (m_role == CONN_SLAVE ||
                 m_role == CONN_MASTER);

      m_phy->ChangeState (BlePhy::TRANS);
      if (m_phy->GetState () == BlePhy::IDLE)
        {
          m_phy->m_interrupt = false;
          m_txPktBuffer = std::queue<Ptr<Packet> > ();
          m_txPktBuffer_tmp = std::queue<Ptr<Packet> > ();
          Ptr<Packet> ind = Create<Packet> ();
          TxToL2cap(ind, 2, 2); // Indication to Application that Packet was not sent
          return;
        }

      NS_LOG_DEBUG (this << " "
                    << Simulator::Now ().GetMicroSeconds () << "us "
                    << "Transmission has begun at Channel No "
                    << m_phy->GetChannelNo ());
      m_phy->StartTx ();

      // XXX: Each Piconet slot is of 625us. So, at the end of the 1.25 ms, retransmission occurs.
      // TODO: Make arrangements to avoid using blank ACKs
      m_ackPending = Simulator::Schedule (Time ("1.25ms"),
                                          &BleLinkLayer::BleNoAckTimeout,
                                          this);
      m_phy->SetNextPendingState (BlePhy::LISTEN);
    }
  else if (s == LL_IDLE)
    {
      m_phy->SetNextPendingState (BlePhy::IDLE);
      m_phy->ChangeState (BlePhy::IDLE);
      m_phy->m_interrupt = true;
      m_advEvent.Cancel ();
      m_advListenEvent.Cancel ();
      m_connEvent.Cancel ();
      m_stopConnEvent.Cancel ();
      m_ackPending.Cancel ();
      m_connStopListenEvent.Cancel ();
      m_closeConnectionEvent.Cancel ();
    }
}

void
BleLinkLayer::SetAdvChannelNo (Ptr<Packet const> p)
{
  NS_LOG_FUNCTION (this);
  m_phy->SetChannelNo ((int)(m_random->GetValue (37, 40)));
}

void
BleLinkLayer::StartConnectionEvent (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG (this << " "
                << Simulator::Now ().GetMicroSeconds () << "us "
                << "Start Connection Event");

  m_phy->SetChannelNo ((m_phy->GetChannelNo ()+m_freqHop) % 37);

  if (m_role == CONN_SLAVE)
    {
      // TODO: Make arrangements to avoid using blank ACKs

      // If unlistenedEvents are less then SlaveLatency,
      // then LL may choose not to start reception.
      if (m_unlistenedConnEvent < m_slaveLatency)
        {
            // XXX Assuming No connections between these will be listened
            //            BleLLChangeState (LL_CONN_RX_ON);
        }
      else
        {
          // Must listen if unlistenedEvents exceeds to m_slaveLatency
          BleLLChangeState (LL_CONN_RX_ON);
        }
      // If no packet received in txWindowSize,
      // stop that particular event and try again in another connection event
      m_connStopListenEvent = Simulator::Schedule (m_txWindowSize,
                                                   &BleLinkLayer::StopConnectionEvent,
                                                   this);
    }
  else if (m_role == CONN_MASTER)
    {
      // Dummy packet to notify upper layer
      Ptr<Packet> dummy = Create<Packet> ();
      m_linkLayerTxToL2capTrace (dummy, 1, 0);
      m_connEvent = Simulator::Schedule (m_connInterval,
                                         &BleLinkLayer::StartConnectionEvent,
                                         this);
    }
}

void
BleLinkLayer::StopConnectionEvent (void)
{
  // According to current system model, connection event is stopped
  // only if other device stop responding.
  // So, at every connection event, if an ACK or response is received,
  // counter of unlistenedConnEvent will be set to 0.
  // At every stop connection event, it will be incremented.
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG (this << " "
                << Simulator::Now ().GetMicroSeconds () << "us "
                << "Stopping Connection Event");

  m_reTxInConnEvent = 0;
  m_phy->ChangeState (BlePhy::IDLE);
  m_nextSeq = 0;
  m_linkLayerId = BleLinkLayerHeader::LL_START_PKT;
  m_seqNo = 0;
  m_unlistenedConnEvent++;
  m_txPktBuffer = std::queue<Ptr<Packet> > ();
  m_rxPktBuffer = std::queue<Ptr<Packet> > ();
}

void
BleLinkLayer::BleNoAckTimeout (void)
{
  NS_LOG_FUNCTION (this);
  m_reTxInConnEvent++;
  if (m_reTxInConnEvent == 2)
    {
      StopConnectionEvent ();
      return;
    }
  Simulator::ScheduleNow (&BleLinkLayer::BleLLChangeState, this, LL_CONN_TX_ON);
}

void
BleLinkLayer::BleNoPacketTimeout (void)
{
  NS_LOG_FUNCTION (this);
  if (m_role != SCANNER_PASS)
    NS_LOG_DEBUG (this << " "
                  << Simulator::Now ().GetMicroSeconds () << "us "
                  << "No packet received yet");

  m_phy->SetChannelNo ((int)m_random->GetValue (37,40));
  NS_LOG_DEBUG (this << " "
                << Simulator::Now ().GetMicroSeconds () << "us"
                << " Now Listening at " << m_phy->GetChannelNo ());

  Simulator::ScheduleNow (&BleLinkLayer::BleLLChangeState, this, LL_ADV_RX_ON);
}

void
BleLinkLayer::BleConnReqTimeout (void)
{
  NS_LOG_FUNCTION (this);

  if (m_advMode != NON_CONN_ADV && m_advMode != DISC_ADV)
    NS_LOG_DEBUG (this << " "
                  << Simulator::Now ().GetMicroSeconds () << "us "
                  << "Connection not received yet");
  else if (m_advMode == DISC_ADV)
    NS_LOG_DEBUG (this << " "
                  << Simulator::Now ().GetMicroSeconds () << "us "
                  << "SCAN Request not received yet");

  m_phy->SetChannelNo ((int)m_random->GetValue (37,40));
  NS_LOG_DEBUG (this << " "
                << Simulator::Now ().GetMicroSeconds () << "us "
                << "Now Transmitting at " << m_phy->GetChannelNo ());
  Simulator::ScheduleNow (&BleLinkLayer::BleLLChangeState, this, LL_ADV_TX_ON);
}

void
BleLinkLayer::ParseConnectionRequestPkt (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);
  uint8_t data[22];
  p->CopyData (data, 22);

  uint8_t accAddr[4];
  accAddr[0] = data[0];
  accAddr[1] = data[1];
  accAddr[2] = data[2];
  accAddr[3] = data[3];
  m_accessAddr.CopyFrom (accAddr);

  m_crcInitVal = (data[4] << 16) +
                 (data[5] << 8) +
                 (data[6]);

  SetTxWindowSize (data[7]);

  uint16_t timeInt = 0;

  timeInt = (data[8] << 8) + (data[9]);
  SetTxWindowOffset (timeInt);

  timeInt = (data[10] << 8) + (data[11]);
  SetConnectionInterval (timeInt);

  m_slaveLatency = (data[12] << 9) +
                    data[13];

  timeInt = (data[14] << 8) +
            (data[15]);
  SetSupervisionTimeout (timeInt);

  //Not using ChannelMap
  m_freqHop = (data[21] >> 3 & 0x1f);
  m_sleepClockAcc = data[21] & 0x8;

  NS_LOG_DEBUG (this << " "
                << Simulator::Now ().GetMicroSeconds () << "us "
                << "Settled Connection with "
                << " \n Access Address " << m_accessAddr
                << " \n InitCRCValue = " << m_crcInitVal
                << " \n TxWindowSize = " << m_txWindowSize.GetMilliSeconds ()
                << " \n TxWindowOffset = " << m_txWindowOffset.GetMilliSeconds ()
                << " \n ConnectionInterval = " << m_connInterval.GetMilliSeconds ()
                << " \n SlaveLatency = " << m_slaveLatency
                << " \n SupervisionTimout = " << m_expSupervisionTimeout.GetMilliSeconds ()
                << " \n Frequency Hop = " << (int)m_freqHop
               );

  // Since this device is sure about connection,
  // It will settle with the given supervision timeout
  m_supervisionTimeout = m_expSupervisionTimeout;
  m_isConnected = true;
  // TODO: Check Init channel
  m_initChannelNo = 0;
  m_nextSeq = 0;
  m_seqNo = 0;
  m_linkLayerId = BleLinkLayerHeader::LL_START_PKT;
}

void
BleLinkLayer::CreateConnection (void)
{
  NS_LOG_FUNCTION (this);
  m_accessAddr = m_accessAddr.Allocate ();
  m_crcInitVal = (uint32_t)m_random->GetValue (0,2^24);
  m_freqHop = m_random->GetValue (5, 16);
  // TODO: Check Init channel
  m_initChannelNo = 0;

  NS_LOG_DEBUG (this << " "
                   << Simulator::Now ().GetMicroSeconds () << "us "
                   << "Creating Connection with "
                   << " \n Access Address " << m_accessAddr
                   << " \n InitCRCValue = " << m_crcInitVal
                   << " \n TxWindowSize = " << m_txWindowSize.GetMilliSeconds ()
                   << " \n TxWindowOffset = " << m_txWindowOffset.GetMilliSeconds ()
                   << " \n ConnectionInterval = " << m_connInterval.GetMilliSeconds ()
                   << " \n SlaveLatency = " << m_slaveLatency
                   << " \n SupervisionTimout = " << m_expSupervisionTimeout.GetMilliSeconds ()
                   << " \n Frequency Hop = " << (int)m_freqHop
              );

  uint8_t data[22];

  uint8_t accAddr[4];
  m_accessAddr.CopyTo (accAddr);
  data[0] = accAddr[0];
  data[1] = accAddr[1];
  data[2] = accAddr[2];
  data[3] = accAddr[3];

  data[4] = (m_crcInitVal >> 16) & 0xff;
  data[5] = (m_crcInitVal >> 8) & 0xff;
  data[6] = m_crcInitVal & 0xff;

  data[7] = ((int)(m_txWindowSize.GetMilliSeconds ()/1.25)) & 0xff;

  data[8] = ((int)(m_txWindowOffset.GetMilliSeconds ()/1.25) >> 8) & (0xff);
  data[9] = ((int)(m_txWindowOffset.GetMilliSeconds ()/1.25)) & 0xff;

  data[10] = ((int)(m_connInterval.GetMilliSeconds ()/1.25) >> 8) & (0xff);
  data[11] = ((int)(m_connInterval.GetMilliSeconds ()/1.25)) & (0xff);

  data[12] = (m_slaveLatency >> 8) & 0xff;
  data[13] = (m_slaveLatency) & 0xff;

  data[14] = ((int)(m_expSupervisionTimeout.GetMilliSeconds ()/10) >> 8) & 0xff;
  data[15] = ((int)m_expSupervisionTimeout.GetMilliSeconds ()/10) & 0xff;
  // Not using ChannelMap. Assigning all channels to be unused
  data[16] = 0;
  data[17] = 0;
  data[18] = 0;
  data[19] = 0;
  data[20] = 0;

  data[21] = ((m_freqHop & 0x1f) << 3) + (m_sleepClockAcc & 0x8);
  // Not using Channel Map and Sleep Clock Accuracy

  Ptr<Packet> connect_req_pkt = Create<Packet> (data, 22);

  m_advListenEvent.Cancel ();
  m_txPktBuffer = std::queue<Ptr<Packet> > ();
  m_rxPktBuffer = std::queue<Ptr<Packet> > ();
  m_txPktBuffer.push (connect_req_pkt);
  m_advMode = CONN_REQ;
  m_nextSeq = 0;
  m_seqNo = 0;
  m_linkLayerId = BleLinkLayerHeader::LL_START_PKT;
  Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, this);
}

void
BleLinkLayer::RxFromPhy (Ptr<Packet> p, uint8_t channelNo)
{
  NS_LOG_FUNCTION (this << p->GetUid ()<<Simulator::Now().GetMicroSeconds ());
  m_rxPkt = p;

  BleLinkLayerTrailer tlr;
  p->RemoveTrailer (tlr);

  // Check CRC
  if (!tlr.CheckCrc24 (p))
    {
      // Packet corrupted
      m_linkLayerRxFromPhyDropTrace (p);
      return;
    }

  // Packet received on ADV Channel
  if (channelNo >= 37 && channelNo <= 39)
    {
      BleLinkLayerHeader hdr;
      hdr.SetType (BleLinkLayerHeader::ADV);
      p->RemoveHeader (hdr);
      if (IsWhiteListEnabled ()
          && hdr.GetAdvPktType () != BleLinkLayerHeader::ADV_DIRECT_IND)
        {
          if (! CheckWhiteList (hdr.GetMacAddress ()))
              // Transmitter not in WhiteList
              m_linkLayerRxFromPhyDropTrace (p);
              return;
        }
      m_linkLayerTxToPhyTrace (p);
      BleLinkLayerHeader::AdvPacketType t = hdr.GetAdvPktType ();
      if (m_role == SCANNER_ACT || m_role == SCANNER_PASS)
        {
          if (t == BleLinkLayerHeader::ADV_DIRECT_IND)
            {
              if (IsWhiteListEnabled ())
                  // Assuming direct contact means important
                  AddWhiteList (hdr.GetMacAddress ());
              if (hdr.GetRxMacAddress () != GetMacAddress ())
                {
                  //Simple drop the packet. It was not meant for this device
                  //Do nothing
                  m_linkLayerRxFromPhyDropTrace (p);
                  return;
                }

              NS_LOG_DEBUG (this << " "
                            << Simulator::Now ().GetMicroSeconds () << "us "
                            << "Sending DIRECT Packet to L2CAP.");
              m_connAddr = hdr.GetMacAddress ();
              TxToL2cap (p, 2, 0);
              return;
            }
          else if (t == BleLinkLayerHeader::ADV_NONCONN_IND)
            {
              NS_LOG_DEBUG (this << " "
                            << Simulator::Now ().GetMicroSeconds () << "us "
                            << "Sending Non Connectable Packet to L2CAP");
              TxToL2cap (p, 0, 0);
              return;
            }
          else if (t == BleLinkLayerHeader::SCAN_RESP)
            {
              NS_LOG_DEBUG (this << " "
                            << Simulator::Now ().GetMicroSeconds () << "us "
                            << "Scan Response to L2CAP");
              // No further SCAN Request
              // At present assuming only one scan request per advertisement
              // TODO: Enable this

              if (hdr.GetRxMacAddress () != GetMacAddress ())
                {
                  //Simple drop the packet. It was not meant for this device
                  //Do nothing
                  return;
                }

              m_connAddr = hdr.GetMacAddress ();
              TxToL2cap (p, 0, 0);
              return;
            }
          else if (t == BleLinkLayerHeader::ADV_SCAN_IND)
            {
              NS_LOG_DEBUG (this << " "
                            << Simulator::Now ().GetMicroSeconds () << "us "
                            << "Scannable Adv Pkt to L2CAP");
              m_connAddr = hdr.GetMacAddress ();
              TxToL2cap (p, 0, 1);
              return;
            }
          else if (t == BleLinkLayerHeader::ADV_IND)
            {
              NS_LOG_DEBUG (this << " "
                            << Simulator::Now ().GetMicroSeconds () << "us "
                            << "Sending General Adv Pkt to L2CAP");
              m_connAddr = hdr.GetMacAddress ();
              TxToL2cap (p, 1, 1);
              return;
            }
        }
      else if (m_role == ADVERTISER)
        {
          if (t == BleLinkLayerHeader::SCAN_REQ)
            {
              // Remove header from packet and transmit to L2CAP
              if (hdr.GetRxMacAddress () != GetMacAddress ())
                {
                  //Simple drop the packet. It was not meant for this device
                  //Do nothing
                  m_linkLayerRxFromPhyDropTrace (p);
                  return;
                }

              NS_LOG_DEBUG (this << " "
                            << Simulator::Now ().GetMicroSeconds () << "us "
                            << "Sending Scan Request to L2CAP");
              m_connAddr = hdr.GetMacAddress ();
              TxToL2cap (p, 0, 1);
              return;
            }
          else if (t == BleLinkLayerHeader::CONNECT_REQ)
            {
              if (hdr.GetRxMacAddress () != GetMacAddress ())
                {
                  //Simple drop the packet. It was not meant for this device
                  //Do nothing
                  m_linkLayerRxFromPhyDropTrace (p);
                  return;
                }

              m_connAddr = hdr.GetMacAddress ();
              m_advEvent.Cancel ();
              TxToL2cap (p, 0, 0);
              ParseConnectionRequestPkt (p);
              m_txPktBuffer = std::queue<Ptr<Packet> > ();
              m_rxPktBuffer = std::queue<Ptr<Packet> > ();
              m_role = CONN_SLAVE;
              m_phy->SetChannelNo (m_initChannelNo);
              NS_LOG_DEBUG (this << " "
                            << Simulator::Now ().GetMicroSeconds () << "us "
                            << "Changed to CONN_SLAVE mode");
              return;
            }
        }
      else
          // Not in ADV/SCANNER Mode.
          // Drop the packet
          return;
    } // ADV done
  else
    {
      // Data Packets
      BleLinkLayerHeader hdr;
      hdr.SetType (BleLinkLayerHeader::DATA);
      p->RemoveHeader (hdr);

      if (hdr.GetAccessAddress () != m_accessAddr)
        {
          // Not for this connection
          m_linkLayerRxFromPhyDropTrace (p);
          return;
        }
      m_linkLayerRxFromPhyTrace (p);
      // Event cancellations and counter resets
      //When a packet from other device is received.
      m_ackPending.Cancel ();
      m_reTxInConnEvent = 0;
      m_unlistenedConnEvent = 0;
      if (!m_connStopListenEvent.IsExpired ())
        m_connStopListenEvent.Cancel ();
      // At every packet recieved,
      // Reschedule the CloseConnection after SupervisionTimeout.
      if (!m_closeConnectionEvent.IsExpired ())
        m_closeConnectionEvent.Cancel ();
      m_closeConnectionEvent = Simulator::Schedule (m_supervisionTimeout,
                                                    &BleLinkLayer::CloseConnection,
                                                    this, true, true);
      // Event cancellations and counter resets done.

      if (hdr.GetSequenceNo () != m_nextSeq)
        {
          // Invaluid ACK sequence
          // Retransmission of packet
          Simulator::Schedule (Time("150us"),
                               &BleLinkLayer::BleLLChangeState,
                               this, LL_CONN_TX_ON);
          return;
        }
      if (!m_isConnected)
        {
          m_isConnected = true;
          m_supervisionTimeout = m_expSupervisionTimeout;
        }
      m_nextSeq = !hdr.GetSequenceNo ();
      m_seqNo = hdr.GetNextSequenceNo ();
      // Whether a control packet is recieved
      if (hdr.GetLinkLayerId () == BleLinkLayerHeader::LL_CONTROL_PKT)
        {
          uint8_t data[p->GetSize ()];
          p->CopyData (data, p->GetSize ());
          if (data[0] == LL_TERMINATE_IND)
            {
              if (p->GetSize () == 2)
                {
                  // Connection Close is recevied
                  NS_LOG_DEBUG (this << " "
                                << Simulator::Now ().GetMicroSeconds () << "us "
                                << "Other device want to close connection. Sending ACK");
                  CloseConnection (false, (bool) data[1]);
                  return;
                }
              else if (p->GetSize () == 1)
                {
                  // LL_ACK
                  NS_LOG_DEBUG (this << " "
                                << Simulator::Now ().GetMicroSeconds () << "us "
                                << "ACK recieved. Closing the connection");
                  CloseConnectionAck (m_closeConnectionReason);
                  return;
                }
            }
          else
            {
              // TODO: Add LL Control Packet tasks
              return;
            }
        }
      else if (hdr.GetMoreData () == 1)
        {
          m_rxPktBuffer.push (p);
          if (!m_txPktBuffer.empty ())
            {
              TxToPhy ();
            }
          else
            {
              // Send ACK if the packet is not ACK
              NS_LOG_DEBUG (this << " "
                            << Simulator::Now ().GetMicroSeconds () << "us "
                            << "Sending ACK packet" << hdr.GetAccessAddress ());
              m_txPktBuffer.push (Create<Packet> ());
              TxToPhy ();
            }
        }
      else if (p->GetSize ()==0 &&
               m_txPktBuffer.empty ())
        {
          NS_LOG_DEBUG (this << " "
                        << Simulator::Now ().GetMicroSeconds () << "us "
                        << "Nothing to transmit, Nothing to receive. "
                        << "Closing Connection");
          CloseConnection (true, false);
        }
      else if (p->GetSize () == 0)
        // Implies blank ACK pkt. Send another packet to PHY
        {
          Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, this);
        }
      else if (p->GetSize () != 0 )
        {
          TxToL2cap (p, 0, 0);
        }
    }
//    m_linkLayerRxFromPhyTrace (p);
}

void
BleLinkLayer::TxToL2cap (Ptr<Packet> p, uint8_t int1, uint8_t int2)
{
  NS_LOG_FUNCTION (this);
  // For ADV Mode
  if (m_role == ADVERTISER || m_role == SCANNER_ACT || m_role == SCANNER_PASS)
    {
      m_linkLayerTxToL2capTrace (p, int1, int2);
      if (int1 != int2 || int1 != 0)
        m_advListenEvent.Cancel ();
    }
  else
  // For DATA Mode
    {
      Ptr<Packet> pkt;
      if (!m_rxPktBuffer.empty ())
        {
          pkt = m_rxPktBuffer.front ();
          m_rxPktBuffer.pop ();
          while (!m_rxPktBuffer.empty ())
            {
              pkt->AddAtEnd (m_rxPktBuffer.front ());
              m_rxPktBuffer.pop ();
            }
          pkt->AddAtEnd (p);
        }
      else
        {
          pkt = p;
        }
      m_linkLayerTxToL2capTrace (pkt, int1, int2);
    }
}

void
BleLinkLayer::CloseConnection (bool init, bool reason)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG (this
                << " " << Simulator::Now ().GetMicroSeconds () << "us "
                << "Close Connection");
  // Reason = true => SupervisionTimeout
  // Reason = false => No more data

  // To notify about Management packet.
  // Assume that only close connection packets are Management packets
  m_linkLayerId = BleLinkLayerHeader::LL_CONTROL_PKT;

  if (init)
    {
      uint8_t data[2];
      data[0] = LL_TERMINATE_IND;
      data[1] = (int)reason;  //TODO: Error Code
      Ptr<Packet> pkt = Create<Packet> (data,2);
      m_txPktBuffer.push (pkt);
      TxToPhy ();
      m_closeConnectionReason = reason;
    }
  else
    {
      uint8_t data[1];
      data[0] = LL_TERMINATE_IND;
      Ptr<Packet> pkt = Create<Packet> (data,1);
      m_txPktBuffer.push (pkt);
      TxToPhy ();
      CloseConnectionAck (reason);
    }
}
void
BleLinkLayer::CloseConnectionAck (bool reason)
{
  NS_LOG_FUNCTION (this);
  Ptr<Packet> pkt = Create<Packet> (); // Dummy Packet to Application
  if (reason)
    m_linkLayerTxToL2capTrace (pkt, 2, 2);
  else
    m_linkLayerTxToL2capTrace (pkt, 1, 1);
  m_connEvent.Cancel ();
  m_stopConnEvent.Cancel ();
  m_connStopListenEvent.Cancel ();
  m_closeConnectionEvent.Cancel ();

  if (m_role == CONN_SLAVE)
    {
      Simulator::Schedule (Time("150us"),
                           &BleLinkLayer::SetRole,
                           this, ADVERTISER);
    }
  else
    {
      Simulator::Schedule (Time("150us"),
                           &BleLinkLayer::SetRole,
                           this, SCANNER_PASS);
      Simulator::Schedule (Time("150us"),
                           &BleLinkLayer::BleLLChangeState,
                           this, LL_ADV_RX_ON);
    }
  m_txPktBuffer = std::queue<Ptr<Packet> > ();
  m_txPktBuffer_tmp = std::queue<Ptr<Packet> > ();
  m_rxPktBuffer = std::queue<Ptr<Packet> > ();

  m_linkLayerId = BleLinkLayerHeader::LL_START_PKT;
  m_phy -> TraceConnectWithoutContext ("PhyTxEnd",
                                       MakeCallback (&BleLinkLayer::SetAdvChannelNo, this));
}

void
BleLinkLayer::SendScanRequest (void)
{
  NS_LOG_FUNCTION (this);
  Ptr<Packet> pkt = Create<Packet> ();
  SetAdvMode (BleLinkLayer::SCANNER_REQ);
  RxFromL2cap (pkt);
  Simulator::ScheduleNow (&BleLinkLayer::TxToPhy, this);
  Simulator::Schedule (Time("150us"), &BleLinkLayer::BleLLChangeState, this, BleLinkLayer::LL_ADV_RX_ON);
}

} // namespace ns3
