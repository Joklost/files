/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 Next Generation Wireless Systems Lab,
 * Indian Institute of Science, Banglore, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Kartik Patel <kartikpatel1995@gmail.com>
 *
 * This work was carried out in the Next Generation Wireless Systems lab
 * (ECE department, Indian Institute of Science, Bangalore) of Prof. Neelesh B. Mehta,
 * and was partially supported by Aerospace Network Research Consortium (ANRC).
 *
 */
#include <ns3/log.h>
#include <ns3/double.h>
#include <ns3/simulator.h>
#include <ns3/trace-source-accessor.h>
#include <ns3/pointer.h>
#include <ns3/energy-source.h>
#include "ble-radio-energy-model.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("BleRadioEnergyModel");

NS_OBJECT_ENSURE_REGISTERED (BleRadioEnergyModel);

TypeId
BleRadioEnergyModel::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BleRadioEnergyModel")
    .SetParent<DeviceEnergyModel> ()
    .SetGroupName ("Energy")
    .AddConstructor<BleRadioEnergyModel> ()
    .AddAttribute ("OffCurrentA",
                   "The default radio Off Current in Amp.",
                   DoubleValue (1e-7), // TODO: Check
                   MakeDoubleAccessor (&BleRadioEnergyModel::SetOffCurrentA,
                                       &BleRadioEnergyModel::GetOffCurrentA),
                   MakeDoubleChecker<double> ())
    .AddAttribute ("IdleCurrentA",
                   "The default radio Idle Current in Amp.",
                   DoubleValue (1e-6), // TODO: Check
                   MakeDoubleAccessor (&BleRadioEnergyModel::SetIdleCurrentA,
                                       &BleRadioEnergyModel::GetIdleCurrentA),
                   MakeDoubleChecker<double> ())
    .AddAttribute ("TxCurrentA",
                   "The default radio Tx Current in Amp.",
                   DoubleValue (0.0061),
                   MakeDoubleAccessor (&BleRadioEnergyModel::SetTxCurrentA,
                                       &BleRadioEnergyModel::GetTxCurrentA),
                   MakeDoubleChecker<double> ())
    .AddAttribute ("RxCurrentA",
                   "The default radio Rx Current in Amp.",
                   DoubleValue (0.0059),
                   MakeDoubleAccessor (&BleRadioEnergyModel::SetRxCurrentA,
                                       &BleRadioEnergyModel::GetRxCurrentA),
                   MakeDoubleChecker<double> ())

    .AddTraceSource ("TotalEnergyConsumption",
                     "Total energy consumption of the radio device.",
                     MakeTraceSourceAccessor (&BleRadioEnergyModel::m_totalEnergyConsumption),
                     "ns3::TraceValueCallback::Double")
    ;
  return tid;
}

BleRadioEnergyModel::BleRadioEnergyModel ()
{
  NS_LOG_FUNCTION (this);
  m_currentState = BlePhy::IDLE;
  m_lastUpdateTime = Seconds (0.0);
  m_nPendingChangeState = 0;
  m_isSupersededChangeState = false;
  m_energyDepletionCallback.Nullify ();
  m_source = NULL;
}

BleRadioEnergyModel::~BleRadioEnergyModel ()
{
  NS_LOG_FUNCTION (this);
}

void
BleRadioEnergyModel::SetPhy (Ptr<BlePhy> phy)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (phy!= NULL);
  m_phy = phy;
}
void
BleRadioEnergyModel::SetEnergySource (Ptr<EnergySource> source)
{
  NS_LOG_FUNCTION (this << source);
  NS_ASSERT (source != NULL);
  m_source = source;
}

double
BleRadioEnergyModel::GetTotalEnergyConsumption (void) const
{
  NS_LOG_FUNCTION (this);
  return m_totalEnergyConsumption;
}

double
BleRadioEnergyModel::GetOffCurrentA (void) const
{
  NS_LOG_FUNCTION (this);
  return m_offCurrentA;
}
void
BleRadioEnergyModel::SetOffCurrentA (double offCurrentA)
{
  NS_LOG_FUNCTION (this << offCurrentA);
  m_offCurrentA = offCurrentA;
}

double
BleRadioEnergyModel::GetIdleCurrentA (void) const
{
  NS_LOG_FUNCTION (this);
  return m_idleCurrentA;
}
void
BleRadioEnergyModel::SetIdleCurrentA (double idleCurrentA)
{
  NS_LOG_FUNCTION (this << idleCurrentA);
  m_idleCurrentA = idleCurrentA;
}

double
BleRadioEnergyModel::GetTxCurrentA (void) const
{
  NS_LOG_FUNCTION (this);
  return m_txCurrentA;
}

void
BleRadioEnergyModel::SetTxCurrentA (double txCurrentA)
{
  NS_LOG_FUNCTION (this << txCurrentA);
  m_txCurrentA = txCurrentA;
}

double
BleRadioEnergyModel::GetRxCurrentA (void) const
{
  NS_LOG_FUNCTION (this);
  return m_rxCurrentA;
}

void
BleRadioEnergyModel::SetRxCurrentA (double rxCurrentA)
{
  NS_LOG_FUNCTION (this << rxCurrentA);
  m_rxCurrentA = rxCurrentA;
}

BlePhy::BlePhyState
BleRadioEnergyModel::GetCurrentState (void) const
{
  NS_LOG_FUNCTION (this);
  return m_currentState;
}

void
BleRadioEnergyModel::SetEnergyDepletionCallback (
  BleRadioEnergyDepletionCallback callback)
{
  NS_LOG_FUNCTION (this);
  if (callback.IsNull ())
    {
      NS_LOG_DEBUG ("BleRadioEnergyModel:Setting NULL energy depletion callback!");
    }
  m_energyDepletionCallback = callback;
}

void
BleRadioEnergyModel::SetEnergyRechargedCallback (
  BleRadioEnergyRechargedCallback callback)
{
  NS_LOG_FUNCTION (this);
  if (callback.IsNull ())
    {
      NS_LOG_DEBUG ("BleRadioEnergyModel:Setting NULL energy recharged callback!");
    }
  m_energyRechargedCallback = callback;
}

void
BleRadioEnergyModel::ChangeState (BlePhy::BlePhyState old, BlePhy::BlePhyState newState)
{
  NS_LOG_FUNCTION (this);
  ChangeState (newState);
}

void
BleRadioEnergyModel::ChangeState (int newState)
{
  NS_LOG_FUNCTION (this << newState);

  Time duration = Simulator::Now () - m_lastUpdateTime;
  NS_ASSERT (duration.GetNanoSeconds () >= 0); // check if duration is valid

  // energy to decrease = current * voltage * time
  double energyToDecrease = 0.0;
  double supplyVoltage = m_source->GetSupplyVoltage ();
  switch (m_currentState)
    {
    case BlePhy::OFF:
      energyToDecrease = duration.GetSeconds () * m_offCurrentA * supplyVoltage;
      break;
    case BlePhy::IDLE:
    case BlePhy::TRANS:
    case BlePhy::LISTEN:
      energyToDecrease = duration.GetSeconds () * m_idleCurrentA * supplyVoltage;
      break;
    case BlePhy::BUSY_TX:
      energyToDecrease = duration.GetSeconds () * m_txCurrentA * supplyVoltage;
      break;
    case BlePhy::BUSY_RX:
      energyToDecrease = duration.GetSeconds () * m_rxCurrentA * supplyVoltage;
      break;
    default:
      NS_FATAL_ERROR ("BleRadioEnergyModel:Undefined radio state: " << m_currentState);
    }

  // update total energy consumption
  m_totalEnergyConsumption += energyToDecrease;

  // update last update time stamp
  m_lastUpdateTime = Simulator::Now ();

  m_nPendingChangeState++;

  // notify energy source
  m_source->UpdateEnergySource ();

  // in case the energy source is found to be depleted during the last update, a callback might be
  // invoked that might cause a change in the BLE PHY state (e.g., the PHY is put into IDLE mode).
  // This in turn causes a new call to this member function, with the consequence that the previous
  // instance is resumed after the termination of the new instance. In particular, the state set
  // by the previous instance is erroneously the final state stored in m_currentState. The check below
  // ensures that previous instances do not change m_currentState.

  if (!m_isSupersededChangeState)
    {
      // update current state & last update time stamp
      SetBleRadioState ((BlePhy::BlePhyState) newState);

      // some debug message
      NS_LOG_DEBUG ("BleRadioEnergyModel:Total energy consumption is " <<
                    m_totalEnergyConsumption << "J");
    }

  m_isSupersededChangeState = (m_nPendingChangeState > 1);

  m_nPendingChangeState--;
}

void
BleRadioEnergyModel::HandleEnergyDepletion (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("BleRadioEnergyModel:Energy is depleted!");
  // invoke energy depletion callback, if set.
  if (!m_energyDepletionCallback.IsNull ())
    {
      m_energyDepletionCallback ();
    }
}

void
BleRadioEnergyModel::HandleEnergyRecharged (void)
{
  NS_LOG_FUNCTION (this);
  NS_LOG_DEBUG ("BleRadioEnergyModel:Energy is recharged!");
  // invoke energy recharged callback, if set.
  if (!m_energyRechargedCallback.IsNull ())
    {
      m_energyRechargedCallback ();
    }
}

/*
 * Private functions start here.
 */

void
BleRadioEnergyModel::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  m_source = NULL;
  m_energyDepletionCallback.Nullify ();
}

double
BleRadioEnergyModel::DoGetCurrentA (void) const
{
  NS_LOG_FUNCTION (this);
  switch (m_currentState)
    {
    case BlePhy::OFF:
      return m_offCurrentA;
    case BlePhy::IDLE:
    case BlePhy::TRANS:
    case BlePhy::LISTEN:
      return m_idleCurrentA;
    case BlePhy::BUSY_TX:
      return m_txCurrentA;
    case BlePhy::BUSY_RX:
      return m_rxCurrentA;
    default:
      NS_FATAL_ERROR ("BleRadioEnergyModel:Undefined radio state:" << m_currentState);
    }
}

void
BleRadioEnergyModel::SetBleRadioState (const BlePhy::BlePhyState state)
{
  NS_LOG_FUNCTION (this << state);
  m_currentState = state;
  std::string stateName;
  switch (state)
    {
    case BlePhy::IDLE:
      stateName = "IDLE";
      break;
    case BlePhy::TRANS:
      stateName = "TRANS";
      break;
    case BlePhy::LISTEN:
      stateName = "LISTEN";
      break;
    case BlePhy::BUSY_TX:
      stateName = "BUSY_TX";
      break;
    case BlePhy::BUSY_RX:
      stateName = "BUSY_RX";
      break;
    case BlePhy::OFF:
      stateName = "OFF";
      break;
    }
  NS_LOG_DEBUG ("BleRadioEnergyModel:Switching to state: " << stateName <<
                " at time = " << Simulator::Now ());
}

} // namespace ns3
